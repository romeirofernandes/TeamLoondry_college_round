(() => {
  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/dashboard-redirect.ts
  void chrome.runtime.sendMessage({ type: "OPEN_DASHBOARD", hash: location.hash || "#overview" }).then(() => window.close());
})();
