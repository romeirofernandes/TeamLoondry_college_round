(() => {
  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/content/dom.ts
  var interactiveSelector = 'a[href],button,input:not([type="hidden"]),textarea,select,[contenteditable="true"],[contenteditable=""],[role="button"],[role="link"],[role="checkbox"],[role="radio"],[role="switch"],[tabindex]:not([tabindex="-1"])';
  var overlayId = "handsfree-assist-overlay";
  var privateTextSelector = 'input,textarea,[contenteditable]:not([contenteditable="false"]),[role="textbox"],script,style,noscript,template,[data-private],[data-handsfree-ignore],#handsfree-assist-overlay';
  function publicText(element) {
    if (element.closest(privateTextSelector + ',[hidden],[inert],[aria-hidden="true"]')) return false;
    for (let ancestor = element; ancestor; ancestor = ancestor.parentElement) {
      const style = getComputedStyle(ancestor);
      if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse" || Number(style.opacity || "1") <= 0) return false;
      if (ancestor instanceof HTMLElement && sensitive(ancestor)) return false;
    }
    return true;
  }
  function staticText(element) {
    if (!element || element.closest(privateTextSelector)) return "";
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
    const pieces = [];
    let node;
    while (node = walker.nextNode()) {
      if (node.parentElement && publicText(node.parentElement))
        pieces.push(node.textContent ?? "");
    }
    return pieces.join(" ");
  }
  function pageContext() {
    const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
    let text = "";
    let node;
    while (text.length < 12e3 && (node = walker.nextNode())) {
      if (!node.parentElement || !publicText(node.parentElement)) continue;
      const piece = (node.textContent || "").replace(/\s+/g, " ").trim();
      if (piece) text += (text ? " " : "") + piece.slice(0, 12e3 - text.length - (text ? 1 : 0));
    }
    return { title: document.title.slice(0, 500), url: location.href.slice(0, 2e3), text };
  }
  function usable(element) {
    if (!(element instanceof HTMLElement) || element.closest(`#${overlayId}`))
      return false;
    if (
      // aria-hidden removes duplicate thumbnails from assistive technology,
      // but does not hide their native pointer hit area. Public text filtering
      // independently excludes aria-hidden content above.
      element.closest("[hidden],[inert]") || element.matches(':disabled,[aria-disabled="true"]')
    )
      return false;
    const style = getComputedStyle(element);
    const box = element.getBoundingClientRect();
    if (style.pointerEvents === "none" || box.width <= 0 || box.height <= 0)
      return false;
    for (let ancestor = element; ancestor; ancestor = ancestor.parentElement) {
      const ancestorStyle = ancestor === element ? style : getComputedStyle(ancestor);
      if (ancestorStyle.display === "none" || ancestorStyle.visibility === "hidden" || ancestorStyle.visibility === "collapse" || Number(ancestorStyle.opacity || "1") <= 0)
        return false;
    }
    return true;
  }
  function targetLabel(element) {
    const labelIds = element.getAttribute("aria-labelledby")?.split(/\s+/) ?? [];
    const labelled = labelIds.map((id) => staticText(document.getElementById(id))).join(" ");
    const labels = "labels" in element ? Array.from(element.labels ?? []).map((label2) => staticText(label2)).join(" ") : "";
    const isEditableContent = element instanceof HTMLTextAreaElement || element.isContentEditable || element.closest('[contenteditable="true"],[contenteditable=""]') !== null || element.getAttribute("role") === "textbox";
    const text = element instanceof HTMLInputElement ? element.type === "submit" || element.type === "button" ? element.value : "" : isEditableContent ? "" : staticText(element);
    return (element.getAttribute("aria-label") || labelled || labels || text || element.getAttribute("title") || element.getAttribute("placeholder") || element.getAttribute("name") || element.tagName.toLowerCase()).replace(/\s+/g, " ").trim().slice(0, 180);
  }
  function sensitive(element) {
    const descriptor = [
      element.getAttribute("type"),
      element.getAttribute("autocomplete"),
      element.getAttribute("name"),
      element.id,
      element.getAttribute("aria-label")
    ].join(" ");
    return /password|passwd|credit|debit|payment|card.?number|card.?holder|card.?expiry|cvv|cvc|cc-|one-time-code/i.test(
      descriptor
    );
  }
  function editable(element) {
    if (!element || !usable(element) || sensitive(element) || element.matches('[readonly],[aria-readonly="true"]'))
      return false;
    if (element instanceof HTMLTextAreaElement) return true;
    if (element instanceof HTMLInputElement)
      return ["text", "search", "email", "tel", "url"].includes(element.type);
    return element.isContentEditable || element.getAttribute("contenteditable") === "true" || element.getAttribute("contenteditable") === "";
  }
  function voiceUsable(element) {
    return usable(element) && !sensitive(element) && !element.closest('[aria-hidden="true"],[data-private],[data-handsfree-ignore]');
  }
  function voiceExposed(element) {
    if (!element.isConnected || !voiceUsable(element)) return false;
    let checked = 0;
    for (const box of element.getClientRects()) {
      const left = Math.max(0, box.left), right = Math.min(innerWidth, box.right);
      const top = Math.max(0, box.top), bottom = Math.min(innerHeight, box.bottom);
      if (right <= left || bottom <= top) continue;
      const hit = document.elementFromPoint((left + right) / 2, (top + bottom) / 2);
      if (hit && (hit === element || element.contains(hit))) return true;
      if (++checked >= 32) break;
    }
    return false;
  }
  function linkUrl(element) {
    const raw = element.getAttribute("href");
    if (!raw) return null;
    try {
      const url = new URL(raw, document.baseURI);
      return /^https?:$/.test(url.protocol) && !url.username && !url.password ? url.href : null;
    } catch {
      return null;
    }
  }
  function submitControl(element) {
    return element instanceof HTMLButtonElement && element.type === "submit" && !!element.form || element instanceof HTMLInputElement && ["submit", "image"].includes(element.type) && !!element.form;
  }
  function formFor(element) {
    if (!element) return null;
    return ("form" in element ? element.form : null) || element.closest("form");
  }
  function insertText(element, text) {
    if (!editable(element)) return false;
    element.focus({ preventScroll: true });
    if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
      const current = element.value;
      const start = element.selectionStart ?? current.length;
      const end = element.selectionEnd ?? start;
      const previous = current.slice(0, start);
      const prefix = previous && !/\s$/.test(previous) && text && !/^[\s.,!?;:]/.test(text) ? " " : "";
      const value2 = previous + prefix + text + current.slice(end);
      const prototype = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(prototype, "value")?.set?.call(
        element,
        value2
      );
      const caret = start + prefix.length + text.length;
      try {
        element.setSelectionRange(caret, caret);
      } catch {
      }
    } else {
      const selection = window.getSelection();
      const range = selection?.rangeCount ? selection.getRangeAt(0) : null;
      if (range && element.contains(range.commonAncestorContainer)) {
        range.deleteContents();
        const node = document.createTextNode(text);
        range.insertNode(node);
        range.setStartAfter(node);
        range.collapse(true);
        selection?.removeAllRanges();
        selection?.addRange(range);
      } else {
        const previous = element.textContent ?? "";
        element.append(
          document.createTextNode(
            (previous && !/\s$/.test(previous) ? " " : "") + text
          )
        );
      }
    }
    element.dispatchEvent(
      new InputEvent("input", {
        bubbles: true,
        composed: true,
        inputType: "insertText",
        data: text
      })
    );
    element.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  var PageTargets = class {
    ids = /* @__PURE__ */ new WeakMap();
    elements = /* @__PURE__ */ new Map();
    sequence = 0;
    candidates = [];
    refreshedAt = -Infinity;
    visible = /* @__PURE__ */ new Set();
    intersection = null;
    mutations = null;
    dirty = true;
    constructor() {
      if (typeof IntersectionObserver !== "undefined") {
        this.intersection = new IntersectionObserver((entries) => {
          for (const entry of entries) {
            if (entry.isIntersecting) this.visible.add(entry.target);
            else this.visible.delete(entry.target);
          }
        }, { rootMargin: "48px" });
        this.mutations = new MutationObserver((records) => {
          if (records.some((record) => !(record.target instanceof Element && record.target.closest(`#${overlayId}`)))) this.dirty = true;
        });
        this.mutations.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["role", "tabindex", "href", "type", "contenteditable"] });
      }
    }
    id(element) {
      let id = this.ids.get(element);
      if (!id) {
        id = `hf-${++this.sequence}`;
        this.ids.set(element, id);
      }
      this.elements.set(id, element);
      return id;
    }
    get(id) {
      const element = this.elements.get(id);
      return element && element.isConnected && usable(element) ? element : null;
    }
    scan() {
      this.elements.clear();
      return Array.from(document.querySelectorAll(interactiveSelector)).filter(usable).filter((element) => !sensitive(element) && !element.closest("[data-private],[data-handsfree-ignore]")).slice(0, 1500).map((element) => ({
        id: this.id(element),
        text: targetLabel(element),
        role: element.getAttribute("role") || element.tagName.toLowerCase()
      }));
    }
    /** Fresh top-document voice candidates; pointer indexing is intentionally independent. */
    links() {
      const links = Array.from(document.querySelectorAll('a[href],[role="link"]')).filter(voiceUsable).slice(0, 1500);
      const outsideNavigation = (element) => !element.closest('nav,header,footer,[role="navigation"],[role="menu"],[role="menubar"],[role="contentinfo"],[role="banner"]');
      const headings = links.filter((element) => outsideNavigation(element) && (element.querySelector('h1,h2,h3,h4,h5,h6,[role="heading"]') || element.closest('h1,h2,h3,h4,h5,h6,[role="heading"]')));
      const mainHeadings = headings.filter((element) => element.closest('main,[role="main"]'));
      const ranked = mainHeadings.length ? mainHeadings : headings.length ? headings : links;
      const seen = /* @__PURE__ */ new Set();
      return ranked.filter((element) => {
        const href = linkUrl(element);
        if (!href) return true;
        if (seen.has(href)) return false;
        seen.add(href);
        return true;
      }).map((element) => this.id(element));
    }
    fields(query) {
      const candidates = Array.from(document.querySelectorAll(interactiveSelector)).filter(voiceUsable).filter(editable);
      const needle = query.normalize("NFKC").toLowerCase().trim();
      const exact = candidates.filter((element) => targetLabel(element).toLowerCase() === needle);
      const matches = exact.length ? exact : needle === "search" ? candidates.filter((element) => element.matches('input[type="search"],[role="searchbox"]') || /\bsearch\b/i.test(targetLabel(element))) : candidates.filter((element) => targetLabel(element).toLowerCase().includes(needle));
      return needle ? matches.slice(0, 10).map((element) => this.id(element)) : [];
    }
    named(query) {
      const literal = this.matchName(query);
      if (literal.length) return literal;
      const stripped = query.replace(/^the\s+/i, "").replace(/\s+(?:link|button|control)$/i, "");
      return stripped === query ? [] : this.matchName(stripped);
    }
    matchName(query) {
      const normalize = (text) => text.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
      const needle = normalize(query);
      if (!needle || needle.length > 500) return [];
      const ranked = this.scan().filter((target) => {
        const element = this.get(target.id);
        return !!element && voiceUsable(element);
      }).map((target) => {
        const label2 = normalize(target.text);
        const offset = label2.indexOf(needle);
        if (offset < 0) return { id: target.id, score: 0 };
        const word = (character) => !!character && /[\p{L}\p{N}_]/u.test(character);
        let whole = false;
        for (let match = offset; match >= 0; match = label2.indexOf(needle, match + 1)) {
          if (!word(label2[match - 1]) && !word(label2[match + needle.length])) {
            whole = true;
            break;
          }
        }
        return { id: target.id, score: label2 === needle ? 3 : whole ? 2 : 1 };
      });
      const best = Math.max(0, ...ranked.map((target) => target.score));
      return best ? ranked.filter((target) => target.score === best).map((target) => target.id).slice(0, 10) : [];
    }
    // Only semantically bounded cards share target identity; channel links and
    // buttons inside the same card retain their own activation target.
    stable(candidate, previous) {
      const cardSelector = "ytd-rich-item-renderer,ytd-video-renderer,ytd-grid-video-renderer,ytd-compact-video-renderer,article,li,[role=article]";
      if (candidate instanceof HTMLAnchorElement && previous instanceof HTMLAnchorElement && candidate.href === previous.href && previous.isConnected && usable(previous)) {
        const card = candidate.closest(cardSelector);
        if (card && card === previous.closest(cardSelector)) {
          const box = previous.getBoundingClientRect();
          const x2 = Math.max(0, box.left) + (Math.min(innerWidth, box.right) - Math.max(0, box.left)) / 2;
          const y = Math.max(0, box.top) + (Math.min(innerHeight, box.bottom) - Math.max(0, box.top)) / 2;
          const hit = document.elementFromPoint(x2, y);
          if (box.right > 0 && box.left < innerWidth && box.bottom > 0 && box.top < innerHeight && hit && (previous.contains(hit) || this.thumbnailContains(hit, previous))) return previous;
        }
      }
      return candidate;
    }
    thumbnailContains(hit, link) {
      return hit.matches("ytd-thumbnail,figure,[data-thumbnail]") && hit.contains(link);
    }
    snap(x2, y, previous = null) {
      const hit = document.elementFromPoint(x2, y);
      const direct = hit?.closest(interactiveSelector);
      if (direct && usable(direct)) return this.stable(direct, previous);
      if (hit?.matches("ytd-thumbnail,figure,[data-thumbnail]")) {
        for (const link of hit.querySelectorAll("a[href]")) {
          if (!usable(link)) continue;
          const box = link.getBoundingClientRect();
          if (x2 >= box.left && x2 <= box.right && y >= box.top && y <= box.bottom)
            return this.stable(link, previous);
        }
      }
      if (hit && document.elementsFromPoint?.(x2, y).some((layer) => {
        const candidate = layer.closest(interactiveSelector);
        if (!candidate || !usable(candidate) || candidate.contains(hit)) return false;
        const box = candidate.getBoundingClientRect();
        return x2 >= box.left && x2 <= box.right && y >= box.top && y <= box.bottom;
      })) return null;
      let winner = null;
      let distance = 42;
      if ((this.intersection ? this.dirty : true) && performance.now() - this.refreshedAt > 250) {
        this.candidates = Array.from(
          document.querySelectorAll(interactiveSelector)
        ).filter((element) => !element.closest(`#${overlayId}`));
        this.refreshedAt = performance.now();
        this.dirty = false;
        if (this.intersection) {
          this.intersection.disconnect();
          this.visible.clear();
          for (const candidate of this.candidates) this.intersection.observe(candidate);
        }
      }
      const nearby = new Set(this.visible);
      if (this.intersection) {
        for (const radius of [14, 28, 42]) {
          for (let index = 0; index < 8; index++) {
            const angle = index * Math.PI / 4;
            const candidate = document.elementFromPoint(x2 + Math.cos(angle) * radius, y + Math.sin(angle) * radius)?.closest(interactiveSelector);
            if (candidate) nearby.add(candidate);
          }
        }
      }
      for (const candidate of this.intersection ? nearby : this.candidates) {
        if (!candidate.isConnected) continue;
        const box = candidate.getBoundingClientRect();
        if (box.bottom < 0 || box.top > innerHeight || box.right < 0 || box.left > innerWidth)
          continue;
        const dx = Math.max(box.left - x2, 0, x2 - box.right);
        const dy = Math.max(box.top - y, 0, y - box.bottom);
        const gap = Math.hypot(dx, dy);
        if (gap < distance && usable(candidate)) {
          const left = Math.max(0, box.left);
          const right = Math.min(innerWidth, box.right);
          const top = Math.max(0, box.top);
          const bottom = Math.min(innerHeight, box.bottom);
          if (right <= left || bottom <= top) continue;
          const insetX = Math.min(1, (right - left) / 2);
          const insetY = Math.min(1, (bottom - top) / 2);
          const hitX = Math.max(left + insetX, Math.min(right - insetX, x2));
          const hitY = Math.max(top + insetY, Math.min(bottom - insetY, y));
          const hit2 = document.elementFromPoint(hitX, hitY);
          if (!hit2 || hit2 !== candidate && !candidate.contains(hit2)) {
            if (gap === 0) return null;
            continue;
          }
          winner = candidate;
          distance = gap;
        }
      }
      return winner ? this.stable(winner, previous) : null;
    }
    destroy() {
      this.intersection?.disconnect();
      this.mutations?.disconnect();
      this.visible.clear();
      this.candidates = [];
    }
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/resolver.ts
  function visible(element) {
    if (!usable(element) || element.closest('[aria-hidden="true"], [data-handsfree-ignore]') || sensitive(element))
      return false;
    const dialogs = [
      ...document.querySelectorAll(
        'dialog[open],[role="dialog"][aria-modal="true"]'
      )
    ].filter((e) => usable(e));
    return !dialogs.length || dialogs.some((d) => d.contains(element));
  }
  function elements(selector, scope = document) {
    const found = [...scope.querySelectorAll(selector)];
    for (const host of scope.querySelectorAll("*"))
      if (host.shadowRoot) found.push(...elements(selector, host.shadowRoot));
    return [...new Set(found)].filter(visible);
  }
  function label(element) {
    return targetLabel(element).replace(/\s+/g, " ").trim().slice(0, 180);
  }
  function norm(value2) {
    return value2.normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
  }
  function controls(names, scope = document) {
    const candidates = elements(
      'button,[role="button"],a[href],input:not([type="hidden"]),textarea,[contenteditable="true"],[role="tab"],[role="option"],[role="checkbox"],[role="radio"]',
      scope
    );
    return candidates.filter(
      (e) => names.some((name) => norm(label(e)) === norm(name))
    );
  }
  function stateOf(element, opposite, inactive = []) {
    const explicit = element.getAttribute("aria-pressed") ?? element.getAttribute("aria-checked") ?? element.getAttribute("aria-selected");
    if (explicit === "true" || explicit === "false") return explicit === "true";
    if (element instanceof HTMLInputElement && ["checkbox", "radio"].includes(element.type))
      return element.checked;
    if (opposite.some((name) => norm(name) === norm(label(element)))) return true;
    if (inactive.some((name) => norm(name) === norm(label(element))))
      return false;
    return null;
  }
  function setInput(element, value2) {
    const prototype = element instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(prototype, "value")?.set?.call(
      element,
      value2
    );
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
  }
  async function until(check, valid, ms = 1600) {
    const deadline = performance.now() + ms;
    do {
      if (!valid()) return false;
      if (check()) return true;
      await new Promise((resolve) => setTimeout(resolve, 40));
    } while (performance.now() < deadline);
    return false;
  }

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/group-b.ts
  var outcome = (state, feedback, rest = {}) => ({ state, feedback, ...rest });
  var one = (selector, scope = document) => {
    const found = elements(selector, scope);
    return found.length === 1 ? found[0] : void 0;
  };
  var value = (node) => node instanceof HTMLInputElement || node instanceof HTMLTextAreaElement ? node.value : node.textContent || "";
  var field = (names, scope = document) => {
    const found = elements(
      'input,textarea,[contenteditable="true"]',
      scope
    ).filter((e) => editable(e) && names.some((n) => norm(label(e)) === norm(n)));
    return found.length === 1 ? found[0] : void 0;
  };
  var chatEditor = (scope) => one('footer [contenteditable="true"][role="textbox"],footer textarea', scope);
  var mailBody = (scope) => field(["Message Body", "Message body", "Body"], scope);
  var meetingCode = (s) => /^\/([a-z]{3}-[a-z]{4}-[a-z]{3})\/?$/.exec(new URL(s.url).pathname)?.[1];
  var meetChatEditor = (scope) => field(["Send a message", "Send a message to everyone", "Message"], scope);
  var groupBSends = /* @__PURE__ */ new Set(["WA06", "GM05", "ME08"]);
  function recipients(s, scope) {
    if (s.site === "whatsapp")
      return s.current?.kind === "chat" && s.current.identity ? [s.current.identity] : [];
    if (s.site === "meet") return meetingCode(s) ? [meetingCode(s)] : [];
    if (s.site !== "gmail") return [];
    const chips = elements("[email],[data-email]", scope).filter(
      (e) => !e.closest('[role="listbox"]')
    );
    const addresses = [
      ...new Set(
        chips.map(
          (e) => (e.getAttribute("email") || e.getAttribute("data-email") || "").toLowerCase()
        )
      )
    ];
    if (addresses.some((a) => !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(a))) return [];
    const pending = elements(
      'input[name="to"],input[name="cc"],input[name="bcc"]',
      scope
    ).some((e) => value(e).trim());
    return pending ? [] : addresses;
  }
  function sendParts(s, scope) {
    if (s.site === "whatsapp")
      return {
        editor: chatEditor(scope),
        names: ["Send"],
        selector: ".message-out",
        destination: recipients(s, scope)
      };
    if (s.site === "gmail")
      return {
        editor: mailBody(scope),
        names: ["Send", "Send \u202A(Ctrl-Enter)\u202C"],
        selector: '[role="alert"]',
        destination: recipients(s, scope)
      };
    return {
      editor: meetChatEditor(scope),
      names: ["Send a message", "Send"],
      selector: '[data-message-id],[data-is-self="true"]',
      destination: recipients(s, scope)
    };
  }
  function dateValue(raw, today) {
    const months = [
      "january",
      "february",
      "march",
      "april",
      "may",
      "june",
      "july",
      "august",
      "september",
      "october",
      "november",
      "december"
    ];
    const iso = /^(\d{4})-(\d{2})-(\d{2})$/.exec(raw);
    const named = /^(\d{1,2}) ([a-z]+) (\d{4})$/.exec(norm(raw));
    const slash = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(raw);
    const year = iso ? Number(iso[1]) : named ? Number(named[3]) : slash ? Number(slash[3]) : NaN;
    const month = iso ? Number(iso[2]) - 1 : named ? months.indexOf(named[2]) : slash ? Number(slash[2]) - 1 : -1;
    const day = iso ? Number(iso[3]) : named ? Number(named[1]) : slash ? Number(slash[1]) : NaN;
    const date = new Date(year, month, day);
    const start = new Date(
      today.getFullYear(),
      today.getMonth(),
      today.getDate()
    );
    if (year < 2e3 || month < 0 || month > 11 || date.getFullYear() !== year || date.getMonth() !== month || date.getDate() !== day || date < start)
      return null;
    return `${String(day).padStart(2, "0")}/${String(month + 1).padStart(2, "0")}/${year}`;
  }
  var stationCode = (input) => input && /(?:^|[-(\s])([A-Z]{2,5})\)?$/.exec(value(input).trim())?.[1];
  var origin = () => one('#origin input,input[aria-label="From"],input[placeholder="From*"]');
  var destination = () => one('#destination input,input[aria-label="To"],input[placeholder="To*"]');
  var journeyDay = () => one(
    '#jDate input,input[aria-label="Journey date"],input[placeholder="Journey Date(dd/mm/yyyy)*"]'
  );
  function journeySummary() {
    const from = origin(), to = destination(), day = journeyDay();
    const codeFrom = stationCode(from), codeTo = stationCode(to);
    if (!from || !to || !day || !codeFrom || !codeTo || codeFrom === codeTo || !dateValue(value(day), /* @__PURE__ */ new Date()))
      return null;
    const klass = one("#journeyClass"), quota = one("#journeyQuota");
    const selectedLabel = (node) => node instanceof HTMLSelectElement ? node.selectedOptions[0]?.text || "" : label(node);
    if (!klass || !quota || !label(klass).trim() || !label(quota).trim())
      return null;
    return {
      fromCode: codeFrom,
      toCode: codeTo,
      from: value(from),
      to: value(to),
      date: value(day),
      className: selectedLabel(klass),
      quota: selectedLabel(quota)
    };
  }
  var meetingState = (id, args) => {
    switch (id) {
      case "ME02":
        return {
          on: ["Turn off microphone", "Turn off microphone (ctrl + d)"],
          off: ["Turn on microphone", "Turn on microphone (ctrl + d)"],
          desired: !!args.mode?.startsWith("unmute")
        };
      case "ME03":
        return {
          on: ["Turn off camera", "Turn off camera (ctrl + e)"],
          off: ["Turn on camera", "Turn on camera (ctrl + e)"],
          desired: args.mode === "on"
        };
      case "ME04":
        return {
          on: ["Turn off captions"],
          off: ["Turn on captions"],
          desired: args.mode === "on"
        };
      case "ME05":
        return {
          on: ["Lower hand"],
          off: ["Raise hand"],
          desired: args.mode === "raise"
        };
      default:
        return null;
    }
  };
  function prepareGroupB(spec, request, s, scope, allow) {
    const id = spec.id;
    if (groupBSends.has(id)) {
      const parts = sendParts(s, scope), buttons = controls(spec.guardNames || parts.names, scope);
      if (!parts.editor || !value(parts.editor).trim())
        return {
          result: outcome(
            "unavailable",
            "The selected draft is empty or unavailable."
          )
        };
      if (!parts.destination.length || !allow(s.site, parts.destination))
        return {
          result: outcome(
            "not-implemented",
            "Sending is enabled only for exact owned test recipients configured in the dashboard. No message was sent."
          )
        };
      if (buttons.length !== 1)
        return {
          result: outcome("unavailable", "A unique Send control is unavailable.")
        };
      const subject = s.site === "gmail" ? one('input[name="subjectbox"]', scope) : void 0;
      return {
        target: buttons[0],
        preview: `Send to ${s.current?.label || parts.destination.join(", ")} [${parts.destination.join(", ")}]${subject ? ", subject " + value(subject).slice(0, 100) : ""}. Draft: ${value(parts.editor).slice(0, 160)}.`
      };
    }
    if (id === "IR05") {
      const summary = journeySummary(), buttons = controls(["Search", "Search trains"]);
      if (!summary || buttons.length !== 1)
        return {
          result: outcome(
            "unavailable",
            "Choose different exact station codes, a valid full future date, class and quota before searching."
          )
        };
      return {
        target: buttons[0],
        preview: `Search ${summary.from} to ${summary.to} on ${summary.date}, ${summary.className}, ${summary.quota}.`
      };
    }
    if (id === "MAP04") {
      if (request.args.mode === "review") {
        const inputs = elements(
          "#directions-searchbox-0 input,#directions-searchbox-1 input"
        );
        const routes = elements("[data-trip-index],[data-route-index]");
        const selectedMode = controls([
          "Driving",
          "Walking",
          "Transit",
          "Cycling",
          "Bicycling"
        ]).filter((e) => stateOf(e, []) === true);
        if (inputs.length !== 2 || inputs.some((e) => !value(e).trim()) || !routes.length || selectedMode.length !== 1)
          return {
            result: outcome(
              "unavailable",
              "Resolve both directions fields and a route mode before reviewing directions."
            )
          };
        request.args = {
          query: value(inputs[0]),
          mode: value(inputs[1]),
          index: 1
        };
        return {
          preview: `Confirm displayed directions from ${value(inputs[0])} to ${value(inputs[1])}, ${label(selectedMode[0])}. ${label(routes[0])}.`
        };
      }
      if (!request.args.query?.trim() || !request.args.mode?.trim())
        return {
          result: outcome(
            "needs-choice",
            "Say directions from an exact starting place to an exact destination."
          )
        };
      if (/^(?:home|work|here|my location|current location)$/.test(
        norm(request.args.query)
      ) || /^(?:home|work|here|my location)$/.test(norm(request.args.mode)))
        return {
          result: outcome(
            "needs-choice",
            "Use exact place names or addresses. Saved places and current location are not inferred."
          )
        };
      if (request.args.index === 1)
        return {
          preview: `Confirm displayed directions from ${request.args.query} to ${request.args.mode}.`
        };
      const url = new URL("https://www.google.com/maps/dir/");
      url.search = new URLSearchParams({
        api: "1",
        origin: request.args.query,
        destination: request.args.mode,
        travelmode: "driving"
      }).toString();
      return {
        result: outcome(
          "available",
          "Opening a route lookup. After Maps resolves both places, say review directions to hear and confirm the displayed endpoints and route mode.",
          { navigate: { url: url.href, newTab: false } }
        )
      };
    }
    if (id === "LI06") {
      if (s.current?.kind !== "job")
        return {
          result: outcome(
            "needs-choice",
            "Open a specific job before changing its saved state."
          )
        };
      const buttons = controls(spec.guardNames || [], scope);
      if (buttons.length !== 1)
        return {
          result: outcome(
            "unavailable",
            "A unique job Save control is unavailable."
          )
        };
      const desired = request.args.mode !== "unsave", state = stateOf(buttons[0], ["Saved", "Unsave"], ["Save"]);
      if (state === desired)
        return {
          result: outcome(
            "already-satisfied",
            `This job is already ${desired ? "saved" : "unsaved"}.`
          )
        };
      if (state === null)
        return {
          result: outcome("unavailable", "The job's saved state is not exposed.")
        };
      return {
        target: buttons[0],
        preview: `${desired ? "Save" : "Unsave"} ${s.current.label}. ${s.current.detail}`
      };
    }
    if (id === "ME01" || id === "ME10") {
      const code = meetingCode(s), buttons = controls(
        id === "ME01" ? ["Join now", "Ask to join"] : ["Leave call"]
      );
      if (!code || buttons.length !== 1)
        return {
          result: outcome(
            "unavailable",
            "Open the exact meeting and its unique join or leave control."
          )
        };
      return {
        target: buttons[0],
        preview: `${id === "ME01" ? "Join" : "Leave"} meeting ${code}. Only your own participation changes.`
      };
    }
    if (id === "GM07" || id === "GM08") {
      if (!s.current)
        return {
          result: outcome("needs-choice", "Open a specific conversation first.")
        };
      const name = id === "GM07" ? request.args.mode?.startsWith("restore") ? "Move to Inbox" : "Archive" : request.args.mode === "read" ? "Mark as read" : "Mark as unread";
      const buttons = controls([name], scope);
      if (buttons.length !== 1)
        return {
          result: outcome(
            "unavailable",
            `The ${name} control is unavailable. Open its menu if needed.`
          )
        };
      return { target: buttons[0], preview: `${name}: ${s.current.label}.` };
    }
    if (id === "WA07" && request.args.mode === "cancel sending")
      return {
        result: outcome(
          "available",
          "Cancelled sending. The draft remains unchanged."
        )
      };
    if (id === "WA07" || id === "GM10") {
      if (id === "WA07" && !s.current)
        return {
          result: outcome(
            "needs-choice",
            "Open a specific chat before clearing its draft."
          )
        };
      const draft = id === "WA07" ? chatEditor(scope) : mailBody(scope);
      if (!draft)
        return {
          result: outcome("unavailable", "A unique draft is unavailable.")
        };
      const buttons = id === "GM10" ? controls(["Discard draft", "Discard"], scope) : [];
      if (id === "GM10" && buttons.length !== 1)
        return {
          result: outcome("unavailable", "The discard control is unavailable.")
        };
      return {
        target: buttons[0] || draft,
        preview: `Discard the selected ${s.site} draft. ${recipients(s, scope).join(", ")}`
      };
    }
    return {};
  }
  async function executeGroupB(spec, request, s, scope, target, valid, context) {
    const id = spec.id, args = request.args;
    const verified = async (check, feedback) => await until(check, valid) ? outcome("available", feedback, { evidence: "observed-postcondition" }) : outcome(
      "failed",
      "The action's result could not be verified. No automatic retry."
    );
    const focus = (node) => {
      if (!node)
        return outcome(
          "unavailable",
          "A unique editable field is unavailable. Select the intended editor first."
        );
      node.focus();
      return document.activeElement === node ? outcome(
        "available",
        `Dictating into ${label(node) || "the selected draft"}. Say finish dictation to exit.`,
        { focusField: true, evidence: "focused-editor" }
      ) : outcome("failed", "The editor did not accept focus.");
    };
    const selectControl = async (names, root = scope) => {
      const nodes = controls(names, root);
      if (nodes.length !== 1)
        return outcome(
          "unavailable",
          "That semantic control is unavailable or ambiguous. Open its panel or menu first."
        );
      const node = nodes[0];
      if (stateOf(node, []) === true)
        return outcome(
          "already-satisfied",
          `${label(node)} is already selected.`
        );
      node.click();
      return verified(
        () => stateOf(node, []) === true,
        `Selected ${label(node)}.`
      );
    };
    if (groupBSends.has(id)) {
      if (!target || !visible(target))
        return outcome("unavailable", "The Send control changed.");
      const parts = sendParts(s, scope);
      if (!parts.editor)
        return outcome("unavailable", "The draft editor changed.");
      const text = value(parts.editor).trim(), before = new Set(
        elements(parts.selector, s.site === "gmail" ? document : scope)
      );
      target.click();
      const result2 = await verified(
        () => {
          if (s.site === "gmail")
            return elements('[role="alert"]').filter((e) => !before.has(e)).some((e) => /\bmessage sent\b/i.test(label(e))) && (!parts.editor.isConnected || !value(parts.editor).trim());
          const after = elements(parts.selector, scope).filter(
            (e) => !before.has(e)
          );
          return after.length === 1 && norm(after[0].textContent || "").includes(norm(text)) && !value(parts.editor).trim();
        },
        s.site === "gmail" ? "Gmail reports Message sent. Sent-folder and recipient-inbox verification still require live account qualification." : "Exactly one outgoing message with the drafted text is visible in the bound conversation."
      );
      return result2;
    }
    if (["ME02", "ME03", "ME04", "ME05"].includes(id)) {
      const change = meetingState(id, args);
      if (!meetingCode(s))
        return outcome("unavailable", "Open an exact Meet meeting first.");
      const buttons = controls([...change.on, ...change.off]);
      if (buttons.length !== 1)
        return outcome(
          "unavailable",
          "The requested meeting control is unavailable or ambiguous."
        );
      const state = stateOf(buttons[0], change.on, change.off);
      if (state === change.desired)
        return outcome(
          "already-satisfied",
          "The meeting control already has the requested state."
        );
      if (state === null)
        return outcome("unavailable", "The meeting control's state is unknown.");
      buttons[0].click();
      return verified(() => {
        const changed = controls([...change.on, ...change.off]);
        return changed.length === 1 && stateOf(changed[0], change.on, change.off) === change.desired;
      }, "Verified the requested Meet state. Handsfree capture is separate.");
    }
    if (id === "ME01" || id === "ME10") {
      if (!target || !visible(target))
        return outcome("unavailable", "The meeting control changed.");
      target.click();
      return verified(
        () => id === "ME01" ? controls(["Leave call"]).length === 1 : !controls(["Leave call"]).length && !!elements('[data-call-ended],[aria-label="You left the meeting"]').length,
        id === "ME01" ? "Joined the selected meeting." : "Left the selected meeting."
      );
    }
    if (id === "ME06") {
      const names = args.mode === "participants" ? ["Show everyone", "People"] : ["Chat with everyone", "Chat"];
      const buttons = controls(names);
      if (buttons.length !== 1)
        return outcome(
          "unavailable",
          "The meeting panel control is unavailable."
        );
      const selector = args.mode === "participants" ? '[aria-label="People"],[data-panel-id="people"]' : '[aria-label="In-call messages"],[data-panel-id="chat"]';
      if (elements(selector).length)
        return outcome(
          "already-satisfied",
          "That meeting panel is already open."
        );
      buttons[0].click();
      return verified(
        () => !!elements(selector).length,
        "Opened the requested meeting panel."
      );
    }
    if (id === "ME07") return focus(meetChatEditor(scope));
    if (id === "WA05")
      return s.current ? focus(chatEditor(scope)) : outcome("needs-choice", "Open a named chat first.");
    if (id === "WA03") {
      if (!s.current)
        return outcome("needs-choice", "Open a specific chat first.");
      const messages = elements(".message-in,.message-out", scope);
      const node = messages[messages.length - (args.mode === "previous" ? 2 : 1)];
      if (!node)
        return outcome(
          "unavailable",
          "That message is not rendered in this chat."
        );
      return outcome(
        "available",
        (node.textContent || "").trim().slice(0, 1500),
        { evidence: "scoped-message" }
      );
    }
    if (id === "WA04") {
      if (!s.current) return outcome("needs-choice", "Open a chat first.");
      const pane = one(
        '[data-testid="conversation-panel-messages"],[role="log"]',
        scope
      );
      if (!pane)
        return outcome(
          "unavailable",
          "The conversation's scroll pane is not exposed."
        );
      const before = pane.scrollTop;
      const newest = args.mode?.startsWith("go to") || args.mode === "newer";
      const desired = newest ? Math.min(
        pane.scrollHeight - pane.clientHeight,
        before + pane.clientHeight
      ) : Math.max(0, before - pane.clientHeight);
      if (desired === before)
        return outcome(
          "already-satisfied",
          "The message pane is already at that boundary."
        );
      pane.scrollTop = args.mode?.startsWith("go to") ? pane.scrollHeight : desired;
      return verified(
        () => pane.scrollTop !== before,
        "Scrolled the selected conversation's messages."
      );
    }
    if (id === "WA02") {
      if (args.mode === "show unread chats")
        return selectControl(["Unread"], elements("#pane-side")[0] || document);
      const chats = s.entities.filter((e) => e.kind === "chat"), at = chats.findIndex(
        (e) => norm(e.label) === norm(s.current?.label || "")
      );
      const next = at >= 0 ? chats[at + 1] : void 0;
      if (!next)
        return outcome(
          "unavailable",
          "The next chat is not available in the rendered list."
        );
      const node = context.node(next.id);
      if (!node) return outcome("unavailable", "The chat list changed.");
      node.click();
      return verified(
        () => norm(context.inspect()?.current?.label || "") === norm(next.label),
        `Opened ${next.label}.`
      );
    }
    if (id === "WA08") {
      const buttons = controls(["Search", "Search messages"], scope);
      if (buttons.length !== 1)
        return outcome(
          "unavailable",
          "The current chat's search control is unavailable."
        );
      buttons[0].click();
      await until(() => !!field(["Search messages"], scope), valid);
      if (!valid()) return outcome("unavailable", "The request was cancelled.");
      const input = field(["Search messages"], scope);
      if (!(input instanceof HTMLInputElement) || !args.query)
        return outcome(
          "unavailable",
          "A unique chat-search field is unavailable."
        );
      setInput(input, args.query);
      return verified(
        () => elements('[data-testid="search-message"]', scope).length > 0 && input.value === args.query,
        "Chat search results are visible for the requested query."
      );
    }
    if (id === "WA09") {
      const name = args.mode === "close" ? ["Close"] : ["Contact info", "Chat info"];
      const buttons = controls(name, args.mode === "close" ? document : scope);
      if (buttons.length !== 1)
        return outcome("unavailable", "The chat info control is unavailable.");
      buttons[0].click();
      return verified(
        () => !!elements('[data-testid="chat-info-drawer"]').length === (args.mode !== "close"),
        "Verified the chat-info panel state."
      );
    }
    if (id === "WA07") {
      if (!target || !editable(target))
        return outcome("unavailable", "The draft changed.");
      target.focus();
      const selection = getSelection(), range = document.createRange();
      range.selectNodeContents(target);
      selection?.removeAllRanges();
      selection?.addRange(range);
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement)
        target.select();
      insertText(target, "");
      return verified(() => !value(target), "Cleared the selected chat draft.");
    }
    if (id === "GM01") {
      const url = new URL(s.url);
      url.hash = "search/" + encodeURIComponent(args.query || "");
      return args.query ? outcome("available", "Opening Gmail search for the requested query.", {
        navigate: { url: url.href, newTab: false }
      }) : outcome("unavailable", "Say a search query.");
    }
    if (id === "GM03") {
      if (args.mode?.startsWith("go back")) {
        const url = new URL(s.url);
        url.hash = "inbox";
        return outcome("available", "Opening the inbox.", {
          navigate: { url: url.href, newTab: false }
        });
      }
      const buttons = controls(
        ["Expand all"],
        elements('[role="main"]')[0] || document
      );
      if (buttons.length !== 1)
        return outcome(
          "unavailable",
          "The thread expansion control is unavailable."
        );
      buttons[0].click();
      return verified(
        () => !!elements(".a3s", scope).length,
        "Message content is expanded."
      );
    }
    if (id === "GM04") {
      if (args.mode?.startsWith("compose")) {
        const buttons = controls(["Compose"]);
        if (buttons.length !== 1)
          return outcome(
            "unavailable",
            "Gmail's Compose control is unavailable."
          );
        const before = new Set(elements('[role="dialog"]'));
        buttons[0].click();
        return verified(
          () => elements('[role="dialog"]').filter((e) => !before.has(e)).length === 1,
          "Opened one compose window. Say write recipient, write subject, or write body."
        );
      }
      const selectedDraft = s.selected?.kind === "draft" ? context.node(s.selected.id) : void 0;
      const dialogs = selectedDraft ? [selectedDraft] : elements('[role="dialog"]');
      if (dialogs.length !== 1)
        return outcome(
          "needs-choice",
          "Select a specific compose window. Close unused compose windows before dictating."
        );
      const node = args.mode === "subject" ? one('input[name="subjectbox"]', dialogs[0]) : args.mode === "recipient" ? one('input[name="to"]', dialogs[0]) : mailBody(dialogs[0]);
      return focus(node);
    }
    if (id === "GM06") {
      const buttons = controls(["Reply"], scope);
      if (buttons.length !== 1)
        return outcome(
          "needs-choice",
          "Select a single message to reply to. Reply all is not inferred."
        );
      buttons[0].click();
      await until(() => !!mailBody(scope), valid);
      if (!valid()) return outcome("unavailable", "The request was cancelled.");
      return focus(mailBody(scope));
    }
    if (id === "GM07" || id === "GM08" || id === "GM10") {
      if (!target || !visible(target))
        return outcome("unavailable", "The account control changed.");
      const actionLabel = label(target), before = s.current?.id;
      target.click();
      if (id === "GM10")
        return verified(
          () => !visible(scope),
          "Discarded the selected compose window."
        );
      if (id === "GM08")
        return verified(
          () => controls(
            [args.mode === "read" ? "Mark as unread" : "Mark as read"],
            scope
          ).length === 1,
          "Verified the requested message read state."
        );
      return verified(
        () => context.inspect()?.current?.id !== before || elements('[role="alert"]').some(
          (e) => norm(label(e)).includes(norm(actionLabel))
        ),
        "Gmail reports the requested archive or restore change. Verify the destination folder before live qualification."
      );
    }
    if (id === "LI02")
      return await autocomplete(
        field(["City, state, or zip code", "Search location"], document),
        args.query,
        valid,
        context,
        request
      );
    if (id === "LI03") {
      const filterName = /time/.test(args.query || "") ? "Job type" : "On-site/Remote";
      const exact = {
        "remote jobs": "Remote",
        "hybrid jobs": "Hybrid",
        "on site jobs": "On-site",
        "full time": "Full-time",
        "part time": "Part-time"
      }[args.query || ""] || "";
      if (!controls([exact]).length) {
        const openers = controls([filterName]);
        if (openers.length !== 1)
          return outcome(
            "unavailable",
            "The requested filter menu is unavailable."
          );
        openers[0].click();
        await until(() => controls([exact]).length === 1, valid);
      }
      if (!valid()) return outcome("unavailable", "The request was cancelled.");
      return selectControl([
        {
          "remote jobs": "Remote",
          "hybrid jobs": "Hybrid",
          "on site jobs": "On-site",
          "full time": "Full-time",
          "part time": "Part-time"
        }[args.query || ""] || ""
      ]);
    }
    if (id === "LI05") {
      if (args.mode === "return to results")
        return outcome("available", "Returning to job results.", {
          navigate: {
            url: "https://www.linkedin.com/jobs/search/",
            newTab: false
          }
        });
      const details = one(".jobs-description__content,.jobs-box__html-content");
      return details && s.current ? outcome(
        "available",
        `${s.current.label}. ${(details.textContent || "").trim().slice(0, 1500)}`,
        { evidence: s.current.id }
      ) : outcome(
        "unavailable",
        "Open a specific job with rendered details first."
      );
    }
    if (id === "LI06") {
      if (!target || !visible(target))
        return outcome("unavailable", "The job Save control changed.");
      target.click();
      return verified(() => {
        const buttons = controls(spec.guardNames || [], scope);
        return buttons.length === 1 && stateOf(buttons[0], ["Saved", "Unsave"], ["Save"]) === (args.mode !== "unsave");
      }, "Verified the selected job's saved state.");
    }
    if (id === "LI07") {
      const link = one(
        ".job-details-jobs-unified-top-card__company-name a,.jobs-unified-top-card__company-name a"
      );
      if (!(link instanceof HTMLAnchorElement))
        return outcome(
          "unavailable",
          "The current job's company link is unavailable."
        );
      const url = new URL(link.getAttribute("href"), s.url);
      return url.hostname === new URL(s.url).hostname && /^\/company\//.test(url.pathname) ? outcome("available", "Opening the job's company profile.", {
        navigate: { url: url.href, newTab: false }
      }) : outcome("unavailable", "The company link leaves the supported domain.");
    }
    if (id === "IR01" || id === "IR02") {
      const input = id === "IR01" ? origin() : destination();
      if (request.entityId) {
        const option = context.node(request.entityId);
        if (!option || !option.matches('[role="option"],.ui-autocomplete-list-item'))
          return outcome("unavailable", "The station choice expired.");
        option.click();
        return verified(
          () => stationCode(input) !== void 0 && norm(value(input)).includes(norm(label(option))),
          "Selected the exact station name and code."
        );
      }
      return await autocomplete(input, args.query, valid, context, request);
    }
    if (id === "IR03") {
      const formatted = args.query ? dateValue(args.query, /* @__PURE__ */ new Date()) : null, input = journeyDay();
      if (!formatted || !(input instanceof HTMLInputElement) || input.readOnly)
        return outcome(
          "unavailable",
          "Say a valid future date with day, month and year. The date field must be available."
        );
      const formattedInput = input.type === "date" ? formatted.split("/").reverse().join("-") : formatted;
      setInput(input, formattedInput);
      return verified(
        () => input.value === formattedInput,
        "Set the full journey date."
      );
    }
    if (id === "IR04") {
      const query = norm(args.query || ""), selects = elements("#journeyClass,#journeyQuota").filter(
        (e) => e instanceof HTMLSelectElement
      );
      const alias = {
        "ac three tier": "AC 3 Tier (3A)",
        "ac two tier": "AC 2 Tier (2A)",
        sleeper: "Sleeper (SL)",
        general: "GENERAL",
        tatkal: "TATKAL"
      };
      const expected = alias[query] || args.query || "";
      const options = selects.flatMap(
        (select) => [...select.options].filter((o) => !o.disabled && norm(o.text) === norm(expected)).map((option) => ({ select, option }))
      );
      if (options.length === 1) {
        setInput(options[0].select, options[0].option.value);
        return verified(
          () => options[0].select.value === options[0].option.value,
          `Selected ${options[0].option.text}.`
        );
      }
      const menus = elements("#journeyClass,#journeyQuota");
      if (menus.length !== 2)
        return outcome(
          "unavailable",
          "The journey class and quota controls are unavailable."
        );
      const quota = [
        "general",
        "tatkal",
        "premium tatkal",
        "ladies",
        "lower berth/sr. citizen"
      ].includes(query);
      const menu = menus.find(
        (e) => e.id === (quota ? "journeyQuota" : "journeyClass")
      );
      if (!menu)
        return outcome(
          "unavailable",
          "The intended journey-options menu is unavailable."
        );
      const opener = elements('[role="combobox"],[role="button"]', menu)[0] || menu;
      if (!controls([expected]).length) opener.click();
      await until(() => controls([expected]).length === 1, valid);
      if (!valid()) return outcome("unavailable", "The request was cancelled.");
      const available = controls([expected]);
      if (available.length === 1) {
        available[0].click();
        return verified(
          () => norm(label(menu)).includes(norm(expected)),
          `Selected ${expected}.`
        );
      }
      return outcome(
        "unavailable",
        "Open the class or quota menu, then choose an exact displayed option."
      );
    }
    if (id === "IR05") {
      const summary = journeySummary();
      if (!summary || !target || !visible(target))
        return outcome("unavailable", "The journey fields changed.");
      const before = new Set(
        elements(
          "app-train-list [data-train-number],app-train-list .train-heading"
        )
      );
      target.click();
      return verified(() => {
        const displayed = one(
          "[data-journey-summary],app-train-list .journey-info,app-train-list .journey-details"
        );
        return !!displayed && [
          summary.fromCode,
          summary.toCode,
          summary.date,
          summary.className,
          summary.quota
        ].every((v) => !!v && norm(label(displayed)).includes(norm(v))) && elements(
          "app-train-list [data-train-number],app-train-list .train-heading"
        ).some((e) => !before.has(e));
      }, "Train results match the selected station codes, date, class and quota. Booking remains excluded.");
    }
    if (id === "IR07") {
      const selected = request.entityId ? context.node(request.entityId) : s.selected ? context.node(s.selected.id) : s.current ? context.node(s.current.id) : void 0;
      const card = selected?.closest("[data-train-number],.train-list-container");
      const details = card ? elements("[data-availability],.availability,.fare", card) : [];
      return details.length ? outcome(
        "available",
        `Displayed at ${(/* @__PURE__ */ new Date()).toISOString()}: ${details.map(label).join(". ")}. Availability and fares may change.`,
        { evidence: s.current?.id }
      ) : outcome(
        "unavailable",
        "Select a specific train with displayed availability or fare first."
      );
    }
    if (id === "IR08") {
      const from = origin(), to = destination();
      if (!(from instanceof HTMLInputElement) || !(to instanceof HTMLInputElement) || !stationCode(from) || !stationCode(to))
        return outcome("unavailable", "Set both exact stations before swapping.");
      const beforeFrom = from.value, beforeTo = to.value, buttons = controls(["Swap", "Swap stations"]);
      if (buttons.length !== 1)
        return outcome(
          "unavailable",
          "The semantic station-swap control is unavailable."
        );
      buttons[0].click();
      return verified(
        () => from.value === beforeTo && to.value === beforeFrom,
        "Swapped and verified both stations."
      );
    }
    if (id === "IR09") return selectControl(["Departure time"], document);
    if (id === "MAP03") {
      if (!s.current)
        return outcome("needs-choice", "Open an exact place first.");
      const nodes = elements(
        args.mode?.includes("hours") ? '[data-item-id="oh"],[aria-label^="Hours"]' : '[data-item-id="address"]'
      );
      return nodes.length === 1 ? outcome("available", `${s.current.label}. ${label(nodes[0])}`, {
        evidence: s.current.id
      }) : outcome(
        "unavailable",
        "That place detail is unavailable or ambiguous."
      );
    }
    if (id === "MAP04") {
      const inputs = elements(
        "#directions-searchbox-0 input,#directions-searchbox-1 input"
      );
      const routes = elements("[data-trip-index],[data-route-index]");
      return args.index === 1 && inputs.length === 2 && value(inputs[0]) === args.query && value(inputs[1]) === args.mode && routes.length > 0 ? outcome(
        "available",
        `Confirmed the displayed route from ${args.query} to ${args.mode}. ${label(routes[0])}`,
        { evidence: "resolved-route-endpoints" }
      ) : outcome(
        "unavailable",
        "The resolved endpoints or route changed. Say review directions again."
      );
    }
    if (id === "MAP05") {
      const names = {
        walking: ["Walking"],
        driving: ["Driving"],
        "public transit": ["Transit"],
        "public transport": ["Transit"],
        transit: ["Transit"],
        cycling: ["Cycling", "Bicycling"],
        bicycling: ["Cycling", "Bicycling"]
      };
      const inputs = elements(
        "#directions-searchbox-0 input,#directions-searchbox-1 input"
      );
      if (inputs.length !== 2 || inputs.some((e) => !value(e).trim()))
        return outcome("unavailable", "Resolve both route endpoints first.");
      const endpoints = inputs.map(value);
      const buttons = controls(names[args.mode || ""] || []);
      if (buttons.length !== 1)
        return outcome("unavailable", "That route mode is unavailable.");
      if (stateOf(buttons[0], []) === true)
        return outcome(
          "already-satisfied",
          "That route mode is already selected."
        );
      const routes = elements("[data-trip-index],[data-route-index]").map(
        (e) => e.textContent
      ), button = buttons[0];
      button.click();
      return verified(
        () => controls(names[args.mode || ""] || []).some(
          (e) => stateOf(e, []) === true
        ) && inputs.every((e, i) => value(e) === endpoints[i]) && elements("[data-trip-index],[data-route-index]").some(
          (e) => !routes.includes(e.textContent)
        ),
        "Verified the route mode, endpoints and refreshed route summary."
      );
    }
    if (id === "MAP07") {
      const buttons = controls([args.mode === "in" ? "Zoom in" : "Zoom out"]), map = one('[data-map-zoom],[aria-label="Map"]');
      if (buttons.length !== 1 || !map)
        return outcome(
          "unavailable",
          "The map's semantic zoom control or scale evidence is unavailable."
        );
      const before = map.getAttribute("data-map-zoom") || map.getAttribute("aria-label");
      buttons[0].click();
      return verified(
        () => (map.getAttribute("data-map-zoom") || map.getAttribute("aria-label")) !== before,
        "Verified the map scale changed. Browser zoom is unchanged."
      );
    }
    if (id === "MAP09") {
      if (!s.current || !args.query)
        return outcome(
          "needs-choice",
          "Open an exact place before searching nearby."
        );
      const url = new URL("https://www.google.com/maps/search/");
      url.search = new URLSearchParams({
        api: "1",
        query: `${args.query} near ${s.current.label}`
      }).toString();
      return outcome(
        "available",
        "Opening nearby place search. Check the results' location.",
        { navigate: { url: url.href, newTab: false } }
      );
    }
    if (id === "MAP10")
      return selectControl(
        [args.mode === "highways" ? "Avoid highways" : "Avoid tolls"],
        document
      );
    return outcome(
      "not-implemented",
      "That workflow is outside this adapter's supported controls."
    );
  }
  async function autocomplete(input, query, valid, context, request) {
    if (!(input instanceof HTMLInputElement) || !editable(input) || !query)
      return outcome(
        "unavailable",
        "A unique search field and exact name are required."
      );
    input.focus();
    setInput(input, query);
    const listId = input.getAttribute("aria-controls");
    const optionRoot = () => listId ? document.getElementById(listId) : input.closest('p-autocomplete,[role="combobox"]') || document;
    await until(() => {
      const root2 = optionRoot();
      return !!root2 && elements('[role="option"],.ui-autocomplete-list-item', root2).length > 0;
    }, valid);
    if (!valid()) return outcome("unavailable", "The request was cancelled.");
    const root = optionRoot(), options = root ? elements('[role="option"],.ui-autocomplete-list-item', root).filter(
      (e) => norm(label(e)).includes(norm(query))
    ) : [];
    if (options.length !== 1) {
      const snapshot = context.inspect();
      const choices = snapshot?.entities.filter(
        (e) => options.includes(context.node(e.id))
      );
      if (choices?.length)
        return outcome(
          "needs-choice",
          "Several exact suggestions match. Say choose a number, or cancel.",
          { choices }
        );
      return outcome(
        "unavailable",
        options.length ? "Several suggestions match. Say the full station name and code." : "No exact suggestion is available. Say a displayed name and code."
      );
    }
    const chosen = label(options[0]);
    options[0].click();
    return await until(() => norm(input.value).includes(norm(chosen)), valid) ? outcome("available", `Selected ${chosen}.`, {
      evidence: "selected-suggestion"
    }) : outcome(
      "failed",
      "The suggestion did not commit a verifiable field value."
    );
  }

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/catalogue.ts
  var catalogue = [
    {
      id: "W01",
      site: "wikipedia",
      priority: "P0",
      examples: ["Search Wikipedia for India", "look up India"],
      description: "Extract query and verify search/article destination"
    },
    {
      id: "W02",
      site: "wikipedia",
      priority: "P0",
      examples: ["Open the first search result", "choose result two"],
      description: "Resolve announced search candidate and article identity"
    },
    {
      id: "W03",
      site: "wikipedia",
      priority: "P0",
      examples: ["Choose the planet", "I mean Mercury the element"],
      description: "Choose a grounded disambiguation entry"
    },
    {
      id: "W04",
      site: "wikipedia",
      priority: "P0",
      examples: ["Open the History section", "take me to Geography"],
      description: "Match current article heading and verify viewport"
    },
    {
      id: "W05",
      site: "wikipedia",
      priority: "P0",
      examples: ["List the sections", "what headings are here?"],
      description: "Announce a bounded ordered section list"
    },
    {
      id: "W06",
      site: "wikipedia",
      priority: "P0",
      examples: ["Next section", "previous heading"],
      description: "Move relative to current section, report its title"
    },
    {
      id: "W07",
      site: "wikipedia",
      priority: "P0",
      examples: ["Go to the introduction", "start of the article"],
      description: "Navigate to article introduction"
    },
    {
      id: "W08",
      site: "wikipedia",
      priority: "P0",
      examples: ["Open the link called Solar System"],
      description: "Resolve an article-body link, clarify duplicate destinations"
    },
    {
      id: "W09",
      site: "wikipedia",
      priority: "P0",
      examples: ["Open that link in a new tab"],
      description: "Use the voice-selected link and verify new tab identity"
    },
    {
      id: "W10",
      site: "wikipedia",
      priority: "P0",
      examples: ["Show reference five", "open citation number five"],
      description: "Resolve citation number in the current article"
    },
    {
      id: "W11",
      site: "wikipedia",
      priority: "P0",
      examples: ["Back to the sentence", "return from the reference"],
      description: "Return to the tracked citation origin"
    },
    {
      id: "W12",
      site: "wikipedia",
      priority: "P0",
      examples: ["Find climate in this article"],
      description: "Locate text locally and announce match count"
    },
    {
      id: "W13",
      site: "wikipedia",
      priority: "P0",
      examples: ["Next match", "previous occurrence"],
      description: "Move within the current find query"
    },
    {
      id: "W14",
      site: "wikipedia",
      priority: "P0",
      examples: ["Show the contents", "expand the table of contents"],
      description: "Use an available contents control or announce sections"
    },
    {
      id: "W15",
      site: "wikipedia",
      priority: "P1",
      examples: ["Expand this section", "collapse the History section"],
      description: "Change supported collapsible heading state"
    },
    {
      id: "W16",
      site: "wikipedia",
      priority: "P1",
      examples: ["Show the infobox", "go to the facts box"],
      description: "Navigate to the current article's infobox"
    },
    {
      id: "W17",
      site: "wikipedia",
      priority: "P1",
      examples: ["Open the image", "show the second article image"],
      description: "Resolve article image excluding icons and decorations"
    },
    {
      id: "W18",
      site: "wikipedia",
      priority: "P1",
      examples: ["Close the image viewer"],
      description: "Close active media modal and restore article context"
    },
    {
      id: "W19",
      site: "wikipedia",
      priority: "P1",
      examples: ["Show references", "go to external links"],
      description: "Match actual section, report absent sections"
    },
    {
      id: "W20",
      site: "wikipedia",
      priority: "P1",
      examples: ["Switch this article to Hindi"],
      description: "Follow an available language link, invalidate English-only assumptions"
    },
    {
      id: "W21",
      site: "wikipedia",
      priority: "P1",
      examples: ["Read this paragraph", "read from this heading"],
      description: "Requires new TTS and resolved visible article text"
    },
    {
      id: "W22",
      site: "wikipedia",
      priority: "P1",
      examples: ["Stop reading", "continue reading"],
      description: "Control reader independently of Handsfree listening"
    },
    {
      id: "W23",
      site: "wikipedia",
      priority: "P2",
      examples: ["Hey Handsfree, summarize this section"],
      description: "Grounded broader answer using selected section, never Jev text generation"
    },
    {
      id: "W24",
      site: "wikipedia",
      priority: "P2",
      examples: ["Hey Handsfree, explain this sentence"],
      description: "Explicitly selected text and bounded grounded response"
    },
    {
      id: "G01",
      site: "github",
      priority: "P0",
      examples: ["Search GitHub for accessible browser extensions"],
      description: "Verify site search query and result category"
    },
    {
      id: "G02",
      site: "github",
      priority: "P0",
      examples: ["Show repository results", "search only issues"],
      description: "Set available result type and verify selected category"
    },
    {
      id: "G03",
      site: "github",
      priority: "P0",
      examples: ["Open owner slash repository", "open the second repository"],
      description: "Resolve exact repository identity"
    },
    {
      id: "G04",
      site: "github",
      priority: "P0",
      examples: ["Show the README", "go to repository overview"],
      description: "Open repository main view/README"
    },
    {
      id: "G05",
      site: "github",
      priority: "P0",
      examples: ["Open the src folder"],
      description: "Resolve directory within current branch/path"
    },
    {
      id: "G06",
      site: "github",
      priority: "P0",
      examples: ["Open package dot json", "open src slash index dot ts"],
      description: "Match full file path; clarify repeated filenames"
    },
    {
      id: "G07",
      site: "github",
      priority: "P0",
      examples: ["Go up one folder"],
      description: "Navigate repository path parent, not browser history"
    },
    {
      id: "G08",
      site: "github",
      priority: "P0",
      examples: ["Find a file named parser"],
      description: "Use supported file finder and announce candidates"
    },
    {
      id: "G09",
      site: "github",
      priority: "P0",
      examples: ["Switch to the main branch"],
      description: "Resolve actual branch and verify displayed branch"
    },
    {
      id: "G10",
      site: "github",
      priority: "P0",
      examples: ["Open Issues", "show pull requests"],
      description: "Scoped repository navigation"
    },
    {
      id: "G11",
      site: "github",
      priority: "P0",
      examples: ["Search issues for voice", "show open issues"],
      description: "Apply query/status and verify results"
    },
    {
      id: "G12",
      site: "github",
      priority: "P0",
      examples: ["Open issue forty-two"],
      description: "Resolve issue number in current repository"
    },
    {
      id: "G13",
      site: "github",
      priority: "P0",
      examples: ["Open pull request twelve"],
      description: "Resolve PR identity; no merge action"
    },
    {
      id: "G14",
      site: "github",
      priority: "P0",
      examples: ["Show the changed files", "open the conversation"],
      description: "Navigate current PR tabs"
    },
    {
      id: "G15",
      site: "github",
      priority: "P0",
      examples: ["Star this repository", "like this repo"],
      description: "Confirm desired starred state of current repository"
    },
    {
      id: "G16",
      site: "github",
      priority: "P0",
      examples: ["Remove my star", "unstar this repository"],
      description: "Confirm desired unstarred state"
    },
    {
      id: "G17",
      site: "github",
      priority: "P1",
      examples: ["Show commits", "open the latest commit"],
      description: "Resolve commit list and selected commit"
    },
    {
      id: "G18",
      site: "github",
      priority: "P1",
      examples: ["Show releases", "open the latest release"],
      description: "Resolve release identity; downloads separate"
    },
    {
      id: "G19",
      site: "github",
      priority: "P1",
      examples: ["Go to line forty", "show line one hundred"],
      description: "Parse bounded line number and verify available file line"
    },
    {
      id: "G20",
      site: "github",
      priority: "P1",
      examples: ["Expand this diff", "show more context"],
      description: "Resolve file/hunk when supported; clarify multiple hunks"
    },
    {
      id: "G21",
      site: "github",
      priority: "P1",
      examples: ["Create a new issue draft"],
      description: "Open new issue form, handle templates by spoken choice"
    },
    {
      id: "G22",
      site: "github",
      priority: "P1",
      examples: ["Write the issue title", "write the issue body"],
      description: "Select scoped field and begin literal dictation"
    },
    {
      id: "G23",
      site: "github",
      priority: "P1",
      examples: ["Preview the issue", "show edit mode"],
      description: "Switch available editor mode"
    },
    {
      id: "G24",
      site: "github",
      priority: "P1",
      examples: ["Submit this issue"],
      description: "Confirm destination and draft; verify one created test issue"
    },
    {
      id: "G25",
      site: "github",
      priority: "P1",
      examples: ["Reply to this issue", "write a comment"],
      description: "Resolve current issue's editor, preserve text literally"
    },
    {
      id: "G26",
      site: "github",
      priority: "P1",
      examples: ["Post the comment"],
      description: "Confirm and verify exactly one owned test comment"
    },
    {
      id: "G27",
      site: "github",
      priority: "P1",
      examples: ["Give this comment a thumbs up"],
      description: "Resolve selected comment reaction, not repository star"
    },
    {
      id: "G28",
      site: "github",
      priority: "P1",
      examples: ["Close my test issue", "reopen this issue"],
      description: "Confirm permission-bound issue state change"
    },
    {
      id: "G29",
      site: "github",
      priority: "P2",
      examples: ["Watch this repository", "stop watching it"],
      description: "Confirm subscription choice and verify actual state"
    },
    {
      id: "G30",
      site: "github",
      priority: "P2",
      examples: ["Copy the file path"],
      description: "Clipboard action only where permission/activation works; report limitation"
    },
    {
      id: "R01",
      site: "reddit",
      priority: "P0",
      examples: ["Search Reddit for mechanical keyboards"],
      description: "Verify query and search page"
    },
    {
      id: "R02",
      site: "reddit",
      priority: "P0",
      examples: ["Search within this community for voice control"],
      description: "Scope query to current community"
    },
    {
      id: "R03",
      site: "reddit",
      priority: "P0",
      examples: ["Open r slash accessibility"],
      description: "Resolve community destination"
    },
    {
      id: "R04",
      site: "reddit",
      priority: "P0",
      examples: ["Open the second post", "open the post about keyboards"],
      description: "Announced feed entity and destination"
    },
    {
      id: "R05",
      site: "reddit",
      priority: "P0",
      examples: ["Next post", "previous post"],
      description: "Change voice-selected feed entity; announce title before reactions"
    },
    {
      id: "R06",
      site: "reddit",
      priority: "P0",
      examples: ["Show comments", "open the discussion"],
      description: "Open comments for selected/current post"
    },
    {
      id: "R07",
      site: "reddit",
      priority: "P0",
      examples: ["Sort posts by new", "show top posts this week"],
      description: "Verify sort and available time range"
    },
    {
      id: "R08",
      site: "reddit",
      priority: "P0",
      examples: ["Sort comments by best", "show newest comments"],
      description: "Verify comment-specific sorting"
    },
    {
      id: "R09",
      site: "reddit",
      priority: "P0",
      examples: ["Expand this thread", "show the replies to comment two"],
      description: "Resolve comment and expanded child state"
    },
    {
      id: "R10",
      site: "reddit",
      priority: "P0",
      examples: ["Collapse this comment thread"],
      description: "Collapse selected thread only"
    },
    {
      id: "R11",
      site: "reddit",
      priority: "P0",
      examples: ["Next comment", "go to the parent comment"],
      description: "Update comment context and announce excerpt"
    },
    {
      id: "R12",
      site: "reddit",
      priority: "P0",
      examples: ["Like this post", "upvote the video"],
      description: "Confirm upvoted state of selected post"
    },
    {
      id: "R13",
      site: "reddit",
      priority: "P0",
      examples: ["Downvote this post", "give it a downvote"],
      description: "Confirm desired vote; distinguish from remove upvote"
    },
    {
      id: "R14",
      site: "reddit",
      priority: "P0",
      examples: ["Remove my vote", "undo that upvote"],
      description: "Confirm neutral vote state or tracked inverse"
    },
    {
      id: "R15",
      site: "reddit",
      priority: "P0",
      examples: ["Upvote this comment"],
      description: "Confirm vote on selected comment, never adjacent post"
    },
    {
      id: "R16",
      site: "reddit",
      priority: "P0",
      examples: ["Close this post", "return to the feed"],
      description: "Close active overlay or navigate to tracked feed"
    },
    {
      id: "R17",
      site: "reddit",
      priority: "P1",
      examples: ["Save this post", "unsave it"],
      description: "Confirm desired account save state"
    },
    {
      id: "R18",
      site: "reddit",
      priority: "P1",
      examples: ["Hide this post"],
      description: "Confirm hide action; report effects on current context"
    },
    {
      id: "R19",
      site: "reddit",
      priority: "P1",
      examples: ["Join this community", "leave this community"],
      description: "Confirm membership change"
    },
    {
      id: "R20",
      site: "reddit",
      priority: "P1",
      examples: ["Reply to comment two", "write a reply to this post"],
      description: "Resolve correct editor and recipient/thread"
    },
    {
      id: "R21",
      site: "reddit",
      priority: "P1",
      examples: ["Write the reply", "finish dictation"],
      description: "Scoped literal editor workflow"
    },
    {
      id: "R22",
      site: "reddit",
      priority: "P1",
      examples: ["Post this reply"],
      description: "Confirm target/content; verify one owned test reply"
    },
    {
      id: "R23",
      site: "reddit",
      priority: "P1",
      examples: ["Discard this reply"],
      description: "Confirm removal of current draft"
    },
    {
      id: "R24",
      site: "reddit",
      priority: "P1",
      examples: ["Play this post's video", "pause the video"],
      description: "Resolve selected post's player and actual playback"
    },
    {
      id: "R25",
      site: "reddit",
      priority: "P1",
      examples: ["Mute this video", "unmute it"],
      description: "Desired state on scoped video player"
    },
    {
      id: "R26",
      site: "reddit",
      priority: "P1",
      examples: ["Show spoiler text"],
      description: "Reveal specifically selected spoiler where supported"
    },
    {
      id: "R27",
      site: "reddit",
      priority: "P2",
      examples: ["Edit my comment"],
      description: "Ownership check, select editor, confirm eventual publication"
    },
    {
      id: "R28",
      site: "reddit",
      priority: "P2",
      examples: ["Hey Handsfree, summarize these comments"],
      description: "Bounded visible thread context, no invented unseen replies"
    },
    {
      id: "A01",
      site: "amazon",
      priority: "P0",
      examples: ["Search Amazon for wireless headphones"],
      description: "Query and results destination"
    },
    {
      id: "A02",
      site: "amazon",
      priority: "P0",
      examples: ["Show the second product", "open the Sony headphones"],
      description: "Resolve announced product identity and seller context"
    },
    {
      id: "A03",
      site: "amazon",
      priority: "P0",
      examples: ["Only show items under two thousand rupees"],
      description: "Parse INR bound and verify available price filter"
    },
    {
      id: "A04",
      site: "amazon",
      priority: "P0",
      examples: ["Between one thousand and three thousand"],
      description: "Validate lower/upper range before applying"
    },
    {
      id: "A05",
      site: "amazon",
      priority: "P0",
      examples: ["Filter by Logitech", "show the Samsung brand"],
      description: "Match available brand filter"
    },
    {
      id: "A06",
      site: "amazon",
      priority: "P0",
      examples: ["Sort by lowest price", "sort by customer rating"],
      description: "Match actual sort option and verify selection"
    },
    {
      id: "A07",
      site: "amazon",
      priority: "P0",
      examples: ["Clear the price filter", "remove all filters"],
      description: "Clear specified supported filters and refresh context"
    },
    {
      id: "A08",
      site: "amazon",
      priority: "P0",
      examples: ["Choose black", "select size medium"],
      description: "Resolve product-specific variant and updated identity"
    },
    {
      id: "A09",
      site: "amazon",
      priority: "P0",
      examples: ["Choose the 128 GB version"],
      description: "Resolve capacity option without guessing equivalents"
    },
    {
      id: "A10",
      site: "amazon",
      priority: "P0",
      examples: ["What variant is selected?"],
      description: "Report selected visible variant, availability and current displayed price"
    },
    {
      id: "A11",
      site: "amazon",
      priority: "P0",
      examples: ["Show product details", "go to specifications"],
      description: "Navigate actual section"
    },
    {
      id: "A12",
      site: "amazon",
      priority: "P0",
      examples: ["Show customer reviews"],
      description: "Open current product reviews section/page"
    },
    {
      id: "A13",
      site: "amazon",
      priority: "P0",
      examples: ["Show one-star reviews", "sort reviews by recent"],
      description: "Apply available review filters and verify state"
    },
    {
      id: "A14",
      site: "amazon",
      priority: "P0",
      examples: ["Show the next product image"],
      description: "Advance current product gallery, exclude ad images"
    },
    {
      id: "A15",
      site: "amazon",
      priority: "P0",
      examples: ["Close image zoom"],
      description: "Close active product media overlay"
    },
    {
      id: "A16",
      site: "amazon",
      priority: "P0",
      examples: ["Go back to search results"],
      description: "Restore tracked results context and rebuild candidates"
    },
    {
      id: "A17",
      site: "amazon",
      priority: "P1",
      examples: ["Add one of these to my cart"],
      description: "Confirm product, variant, seller, quantity and displayed price; verify cart"
    },
    {
      id: "A18",
      site: "amazon",
      priority: "P1",
      examples: ["Open my cart"],
      description: "Navigate cart without checkout"
    },
    {
      id: "A19",
      site: "amazon",
      priority: "P1",
      examples: ["Set this item's quantity to two"],
      description: "Confirm exact cart row and desired quantity"
    },
    {
      id: "A20",
      site: "amazon",
      priority: "P1",
      examples: ["Remove the headphones from my cart"],
      description: "Clarify duplicates, confirm and verify exact row removal"
    },
    {
      id: "A21",
      site: "amazon",
      priority: "P1",
      examples: ["Save this cart item for later"],
      description: "Confirm desired cart/save-for-later state"
    },
    {
      id: "A22",
      site: "amazon",
      priority: "P1",
      examples: ["Add this to my wishlist", "like this product"],
      description: "Confirm list/item where wishlist UI exists"
    },
    {
      id: "A23",
      site: "amazon",
      priority: "P1",
      examples: ["Remove this from my wishlist"],
      description: "Confirm exact list entry and final state"
    },
    {
      id: "A24",
      site: "amazon",
      priority: "P1",
      examples: ["Show delivery information"],
      description: "Read displayed information only; no invented delivery promise"
    },
    {
      id: "A25",
      site: "amazon",
      priority: "P1",
      examples: ["Show other sellers"],
      description: "Open available seller choices and announce identities"
    },
    {
      id: "A26",
      site: "amazon",
      priority: "P2",
      examples: ["Hey Handsfree, compare these two products"],
      description: "Compare selected visible product facts, disclose missing facts"
    },
    {
      id: "A27",
      site: "amazon",
      priority: "P2",
      examples: ["Show questions about battery life"],
      description: "Only if the current site exposes a supported question/search control"
    },
    {
      id: "A28",
      site: "amazon",
      priority: "P2",
      examples: ["Read this review"],
      description: "Requires TTS; scope to selected review"
    },
    {
      id: "S01",
      site: "spotify",
      priority: "P0",
      examples: ["Search Spotify for Radiohead"],
      description: "Verify query and result view"
    },
    {
      id: "S02",
      site: "spotify",
      priority: "P0",
      examples: ["Show songs", "show albums", "show playlists"],
      description: "Set available result type"
    },
    {
      id: "S03",
      site: "spotify",
      priority: "P0",
      examples: ["Play Creep by Radiohead"],
      description: "Match track and artist; verify actual track/player state"
    },
    {
      id: "S04",
      site: "spotify",
      priority: "P0",
      examples: ["Open the album OK Computer"],
      description: "Resolve album, clarify artist if necessary"
    },
    {
      id: "S05",
      site: "spotify",
      priority: "P0",
      examples: ["Play this playlist", "start the album"],
      description: "Resolve current entity and account-supported playback"
    },
    {
      id: "S06",
      site: "spotify",
      priority: "P0",
      examples: ["Pause the song", "hold the music"],
      description: "Pause actual player, keep Handsfree active"
    },
    {
      id: "S07",
      site: "spotify",
      priority: "P0",
      examples: ["Resume the music", "continue playing"],
      description: "Resume player if available"
    },
    {
      id: "S08",
      site: "spotify",
      priority: "P0",
      examples: ["Next track", "skip this song"],
      description: "Verify changed track or announce restriction"
    },
    {
      id: "S09",
      site: "spotify",
      priority: "P0",
      examples: ["Previous track", "restart this song"],
      description: "Distinguish previous from restart using supported player behavior"
    },
    {
      id: "S10",
      site: "spotify",
      priority: "P0",
      examples: ["Mute Spotify", "unmute the player"],
      description: "Desired player mute state"
    },
    {
      id: "S11",
      site: "spotify",
      priority: "P0",
      examples: ["Set volume to forty percent"],
      description: "Parse and verify player volume; not OS volume"
    },
    {
      id: "S12",
      site: "spotify",
      priority: "P0",
      examples: ["Turn it up a little", "lower volume ten percent"],
      description: "Document step size and clamp bounds"
    },
    {
      id: "S13",
      site: "spotify",
      priority: "P0",
      examples: ["Go forward thirty seconds"],
      description: "Seek relative to current position if available"
    },
    {
      id: "S14",
      site: "spotify",
      priority: "P0",
      examples: ["Jump to two minutes ten"],
      description: "Parse absolute time, validate duration and verify position"
    },
    {
      id: "S15",
      site: "spotify",
      priority: "P0",
      examples: ["What song is playing?"],
      description: "Read current track and artist from player"
    },
    {
      id: "S16",
      site: "spotify",
      priority: "P0",
      examples: ["Like this song", "save the current track"],
      description: "Confirm desired saved state through current UI"
    },
    {
      id: "S17",
      site: "spotify",
      priority: "P0",
      examples: ["Remove this from liked songs"],
      description: "Confirm desired unsaved state"
    },
    {
      id: "S18",
      site: "spotify",
      priority: "P1",
      examples: ["Show my library", "open liked songs"],
      description: "Navigate available library destination"
    },
    {
      id: "S19",
      site: "spotify",
      priority: "P1",
      examples: ["Show the queue"],
      description: "Open queue panel and establish numbered candidates"
    },
    {
      id: "S20",
      site: "spotify",
      priority: "P1",
      examples: ["Add this song to the queue"],
      description: "Confirm entity and queue action; verify once"
    },
    {
      id: "S21",
      site: "spotify",
      priority: "P1",
      examples: ["Remove the second queued song"],
      description: "Confirm queue-entry identity, not duplicate track elsewhere"
    },
    {
      id: "S22",
      site: "spotify",
      priority: "P1",
      examples: ["Turn shuffle on", "turn shuffle off"],
      description: "Desired shuffle state, reject unavailable tier control"
    },
    {
      id: "S23",
      site: "spotify",
      priority: "P1",
      examples: ["Repeat this track", "repeat this playlist", "turn repeat off"],
      description: "Resolve supported repeat state explicitly"
    },
    {
      id: "S24",
      site: "spotify",
      priority: "P1",
      examples: ["Follow this artist", "unfollow this artist"],
      description: "Confirm desired account follow state"
    },
    {
      id: "S25",
      site: "spotify",
      priority: "P1",
      examples: ["Save this album", "save this playlist"],
      description: "Use available library semantics and verify"
    },
    {
      id: "S26",
      site: "spotify",
      priority: "P1",
      examples: ["Add this track to my Study playlist"],
      description: "Resolve owned playlist, confirm and verify membership"
    },
    {
      id: "S27",
      site: "spotify",
      priority: "P1",
      examples: ["Show lyrics", "close lyrics"],
      description: "Navigate available lyrics panel; missing lyrics explained"
    },
    {
      id: "S28",
      site: "spotify",
      priority: "P2",
      examples: ["Create a playlist called Study"],
      description: "Confirm title and owned new playlist; no duplicate retry"
    },
    {
      id: "S29",
      site: "spotify",
      priority: "P2",
      examples: ["Play the latest episode of this podcast"],
      description: "Grounded podcast/episode identity and account support"
    },
    {
      id: "S30",
      site: "spotify",
      priority: "P2",
      examples: ["Change playback speed to one point five"],
      description: "Podcast-specific supported speed, unavailable for music explained"
    },
    {
      id: "N01",
      site: "netflix",
      priority: "P0",
      examples: ["Open the profile named Test"],
      description: "Select explicit available profile; ask if ambiguous"
    },
    {
      id: "N02",
      site: "netflix",
      priority: "P0",
      examples: ["Search Netflix for Stranger Things"],
      description: "Verify query and actual results"
    },
    {
      id: "N03",
      site: "netflix",
      priority: "P0",
      examples: ["Open the second title", "show this film's details"],
      description: "Resolve title identity and details panel"
    },
    {
      id: "N04",
      site: "netflix",
      priority: "P0",
      examples: ["Play this title", "start the episode"],
      description: "Verify title/episode and actual playback"
    },
    {
      id: "N05",
      site: "netflix",
      priority: "P0",
      examples: ["Continue watching this show"],
      description: "Resolve matching Continue Watching item"
    },
    {
      id: "N06",
      site: "netflix",
      priority: "P0",
      examples: ["Pause the video", "pause this episode"],
      description: "Pause player, keep Handsfree listening"
    },
    {
      id: "N07",
      site: "netflix",
      priority: "P0",
      examples: ["Resume the episode", "continue playing"],
      description: "Verify player resumes"
    },
    {
      id: "N08",
      site: "netflix",
      priority: "P0",
      examples: ["Go forward ten seconds", "rewind thirty seconds"],
      description: "Verify bounded relative seek"
    },
    {
      id: "N09",
      site: "netflix",
      priority: "P0",
      examples: ["Go to five minutes"],
      description: "Absolute seek only if a reliable supported path exists"
    },
    {
      id: "N10",
      site: "netflix",
      priority: "P0",
      examples: ["Mute Netflix", "unmute this video"],
      description: "Desired player mute state"
    },
    {
      id: "N11",
      site: "netflix",
      priority: "P0",
      examples: ["Set player volume to fifty percent"],
      description: "Set supported player volume, not system volume"
    },
    {
      id: "N12",
      site: "netflix",
      priority: "P0",
      examples: ["What am I watching?"],
      description: "Announce visible title/episode context"
    },
    {
      id: "N13",
      site: "netflix",
      priority: "P0",
      examples: ["Like this video", "give this title a thumbs up"],
      description: "Confirm current profile's positive title rating"
    },
    {
      id: "N14",
      site: "netflix",
      priority: "P0",
      examples: ["Remove my rating"],
      description: "Confirm removal only where actual UI supports it"
    },
    {
      id: "N15",
      site: "netflix",
      priority: "P0",
      examples: ["Close the details", "back to browsing"],
      description: "Close relevant panel or leave player through supported control"
    },
    {
      id: "N16",
      site: "netflix",
      priority: "P1",
      examples: ["Show episodes", "open the episode list"],
      description: "Open current series episode list"
    },
    {
      id: "N17",
      site: "netflix",
      priority: "P1",
      examples: ["Choose season two"],
      description: "Match available season and refresh episode choices"
    },
    {
      id: "N18",
      site: "netflix",
      priority: "P1",
      examples: ["Play episode three"],
      description: "Resolve series/season/episode identity before play"
    },
    {
      id: "N19",
      site: "netflix",
      priority: "P1",
      examples: ["Next episode"],
      description: "Use available episode control; distinguish from title carousel"
    },
    {
      id: "N20",
      site: "netflix",
      priority: "P1",
      examples: ["Skip intro"],
      description: "Use currently available control, otherwise explain absence"
    },
    {
      id: "N21",
      site: "netflix",
      priority: "P1",
      examples: ["Skip recap"],
      description: "Use available recap control without arbitrary seeking"
    },
    {
      id: "N22",
      site: "netflix",
      priority: "P1",
      examples: ["Turn on English subtitles"],
      description: "Match actual subtitle option and verify selection"
    },
    {
      id: "N23",
      site: "netflix",
      priority: "P1",
      examples: ["Turn subtitles off"],
      description: "Desired off state"
    },
    {
      id: "N24",
      site: "netflix",
      priority: "P1",
      examples: ["Switch audio to Hindi"],
      description: "Select available audio track; do not substitute subtitles"
    },
    {
      id: "N25",
      site: "netflix",
      priority: "P1",
      examples: ["Show audio and subtitles"],
      description: "Open player menu and announce actual options"
    },
    {
      id: "N26",
      site: "netflix",
      priority: "P1",
      examples: ["Go fullscreen", "leave fullscreen"],
      description: "Claim only after real voice-only browser verification"
    },
    {
      id: "N27",
      site: "netflix",
      priority: "P1",
      examples: ["Add this to My List", "remove it from My List"],
      description: "Confirm desired profile list state"
    },
    {
      id: "N28",
      site: "netflix",
      priority: "P1",
      examples: ["Give this two thumbs up"],
      description: "Confirm only if the exact rating control exists"
    },
    {
      id: "N29",
      site: "netflix",
      priority: "P1",
      examples: ["Dislike this title", "give it a thumbs down"],
      description: "Confirm profile-specific negative rating"
    },
    {
      id: "N30",
      site: "netflix",
      priority: "P2",
      examples: ["Change playback speed"],
      description: "Offer only currently available speed choices"
    },
    {
      id: "X01",
      site: "x",
      priority: "P0",
      examples: ["Search X for browser accessibility"],
      description: "Search posts using a bounded query"
    },
    {
      id: "X02",
      site: "x",
      priority: "P0",
      examples: ["Open the second post"],
      description: "Open an announced post identity"
    },
    {
      id: "X03",
      site: "x",
      priority: "P0",
      examples: ["Open the profile named handsfree"],
      description: "Open a grounded profile"
    },
    {
      id: "X04",
      site: "x",
      priority: "P0",
      examples: ["Show replies"],
      description: "Open replies on the current post"
    },
    {
      id: "X05",
      site: "x",
      priority: "P0",
      examples: ["Next post"],
      description: "Select and announce next post"
    },
    {
      id: "X06",
      site: "x",
      priority: "P0",
      examples: ["Previous post"],
      description: "Select and announce previous post"
    },
    {
      id: "X07",
      site: "x",
      priority: "P0",
      examples: ["Like this post"],
      description: "Confirm desired liked state on selected post"
    },
    {
      id: "X08",
      site: "x",
      priority: "P0",
      examples: ["Unlike this post"],
      description: "Confirm desired unliked state on selected post"
    },
    {
      id: "X09",
      site: "x",
      priority: "P0",
      examples: ["Bookmark this post"],
      description: "Confirm desired bookmarked state"
    },
    {
      id: "X10",
      site: "x",
      priority: "P0",
      examples: ["Remove this bookmark"],
      description: "Confirm desired unbookmarked state"
    },
    {
      id: "X11",
      site: "x",
      priority: "P0",
      examples: ["Show my bookmarks"],
      description: "Open bookmarks without changing account data"
    },
    {
      id: "X12",
      site: "x",
      priority: "P0",
      examples: ["Back to the feed"],
      description: "Return to home feed"
    },
    {
      id: "X13",
      site: "x",
      priority: "P1",
      examples: ["Reply to this post"],
      description: "Open editor bound to selected post"
    },
    {
      id: "X14",
      site: "x",
      priority: "P1",
      examples: ["Write the reply"],
      description: "Select scoped reply field for literal dictation"
    },
    {
      id: "X15",
      site: "x",
      priority: "P1",
      examples: ["Post this reply"],
      description: "Confirm destination and publish once"
    },
    {
      id: "X16",
      site: "x",
      priority: "P1",
      examples: ["Discard this reply"],
      description: "Confirm clearing the current draft"
    },
    {
      id: "X17",
      site: "x",
      priority: "P1",
      examples: ["Repost this post"],
      description: "Not implemented; do not activate repost menu"
    },
    {
      id: "X18",
      site: "x",
      priority: "P1",
      examples: ["Follow this account"],
      description: "Not implemented until account-state verification is qualified"
    },
    {
      id: "WA01",
      site: "whatsapp",
      priority: "P0",
      examples: ["open my chat with Mira"],
      description: "Resolve chat by exact header/account identity; duplicate names require spoken choice."
    },
    {
      id: "WA02",
      site: "whatsapp",
      priority: "P0",
      examples: ["show unread chats"],
      description: "Announce bounded candidates and verify selected chat header."
    },
    {
      id: "WA03",
      site: "whatsapp",
      priority: "P0",
      examples: ["read the latest message"],
      description: "Read only the selected conversation and message; redact content from diagnostics."
    },
    {
      id: "WA04",
      site: "whatsapp",
      priority: "P0",
      examples: ["scroll older messages"],
      description: "Scroll the message pane, not the chat list; re-resolve after incoming messages."
    },
    {
      id: "WA05",
      site: "whatsapp",
      priority: "P0",
      examples: ["write a message"],
      description: "Focus the selected chat composer and preserve literal command words."
    },
    {
      id: "WA06",
      site: "whatsapp",
      priority: "P0",
      examples: ["send this message"],
      description: "Preview recipient and content summary; confirm once; verify exactly one message."
    },
    {
      id: "WA07",
      site: "whatsapp",
      priority: "P0",
      examples: ["clear this draft"],
      description: "Cancel pending send or confirm clearing only the bound draft."
    },
    {
      id: "WA08",
      site: "whatsapp",
      priority: "P1",
      examples: ["search this chat for invoice"],
      description: "Use in-chat search and verify search scope/results."
    },
    {
      id: "WA09",
      site: "whatsapp",
      priority: "P1",
      examples: ["open chat info"],
      description: "Operate the current chat panel and restore prior context."
    },
    {
      id: "WA10",
      site: "whatsapp",
      priority: "P1",
      examples: ["reply to that message"],
      description: "Resolve the selected message and verify quoted reply target."
    },
    {
      id: "WA11",
      site: "whatsapp",
      priority: "P2",
      examples: ["call this contact"],
      description: "Unavailable in initial release; no call without separately qualified flow."
    },
    {
      id: "GM01",
      site: "gmail",
      priority: "P0",
      examples: ["search Gmail for project update"],
      description: "Submit query deliberately and verify exact conversation and subject."
    },
    {
      id: "GM02",
      site: "gmail",
      priority: "P0",
      examples: ["open the second result"],
      description: "Resolve candidate by sender, subject and date; ask when ambiguous."
    },
    {
      id: "GM03",
      site: "gmail",
      priority: "P0",
      examples: ["go back to inbox"],
      description: "Control thread expansion and inbox navigation independently."
    },
    {
      id: "GM04",
      site: "gmail",
      priority: "P0",
      examples: ["compose an email"],
      description: "Select the intended compose window and semantic recipient/subject/body fields."
    },
    {
      id: "GM05",
      site: "gmail",
      priority: "P0",
      examples: ["send this email"],
      description: "Read back recipient and subject; require explicit confirmation and verify Sent plus recipient inbox."
    },
    {
      id: "GM06",
      site: "gmail",
      priority: "P0",
      examples: ["reply to this email"],
      description: "Bind reply to selected message; distinguish Reply from Reply all."
    },
    {
      id: "GM07",
      site: "gmail",
      priority: "P0",
      examples: ["archive this conversation"],
      description: "Resolve exact thread and verify archive state/reversal."
    },
    {
      id: "GM08",
      site: "gmail",
      priority: "P0",
      examples: ["mark as unread"],
      description: "Set desired state on the selected conversation, not an adjacent row."
    },
    {
      id: "GM09",
      site: "gmail",
      priority: "P1",
      examples: ["switch to the other draft"],
      description: "Select draft by recipient/subject and bind dictation to that editor."
    },
    {
      id: "GM10",
      site: "gmail",
      priority: "P1",
      examples: ["discard this draft"],
      description: "Confirm exact draft identity before deletion."
    },
    {
      id: "GM11",
      site: "gmail",
      priority: "P2",
      examples: ["attach the report"],
      description: "Unavailable until file selection and attachment verification receive separate safety qualification."
    },
    {
      id: "ME01",
      site: "meet",
      priority: "P0",
      examples: ["join this meeting"],
      description: "Resolve meeting identity; joining requires preview and explicit confirmation."
    },
    {
      id: "ME02",
      site: "meet",
      priority: "P0",
      examples: ["mute my meeting microphone"],
      description: "Set Meet mic state and verify it; Handsfree listening remains a separate state."
    },
    {
      id: "ME03",
      site: "meet",
      priority: "P0",
      examples: ["turn my Meet camera off"],
      description: "Verify outgoing Meet camera while independently observing Handsfree tracking."
    },
    {
      id: "ME04",
      site: "meet",
      priority: "P0",
      examples: ["turn captions on"],
      description: "Set caption state when available and report restrictions."
    },
    {
      id: "ME05",
      site: "meet",
      priority: "P0",
      examples: ["raise my hand"],
      description: "Verify hand state for this meeting."
    },
    {
      id: "ME06",
      site: "meet",
      priority: "P0",
      examples: ["open participants"],
      description: "Open scoped panels and avoid controls behind overlays."
    },
    {
      id: "ME07",
      site: "meet",
      priority: "P0",
      examples: ["write a chat message"],
      description: "Dictate to the current meeting chat; preview destination and content summary."
    },
    {
      id: "ME08",
      site: "meet",
      priority: "P0",
      examples: ["send this to the meeting"],
      description: "Explicit confirmation; verify exactly one message in the current meeting."
    },
    {
      id: "ME09",
      site: "meet",
      priority: "P1",
      examples: ["present this tab"],
      description: "Not supported until browser-owned picker/permission boundaries are qualified."
    },
    {
      id: "ME10",
      site: "meet",
      priority: "P1",
      examples: ["leave the meeting"],
      description: "Preview meeting identity and require confirmation; verify own departure only."
    },
    {
      id: "LI01",
      site: "linkedin",
      priority: "P0",
      examples: ["search LinkedIn jobs for data analyst"],
      description: "Enter query and verify job result context."
    },
    {
      id: "LI02",
      site: "linkedin",
      priority: "P0",
      examples: ["set location to Bengaluru"],
      description: "Use the correct location suggestion and verify selected location."
    },
    {
      id: "LI03",
      site: "linkedin",
      priority: "P0",
      examples: ["filter for remote jobs"],
      description: "Set only available filters and verify active chips/results."
    },
    {
      id: "LI04",
      site: "linkedin",
      priority: "P0",
      examples: ["open the second job"],
      description: "Announce title, company and location; clarify duplicates."
    },
    {
      id: "LI05",
      site: "linkedin",
      priority: "P0",
      examples: ["read job details"],
      description: "Inspect selected role and preserve result context."
    },
    {
      id: "LI06",
      site: "linkedin",
      priority: "P0",
      examples: ["save this job"],
      description: "Use desired state, confirm mutation and verify same job identity."
    },
    {
      id: "LI07",
      site: "linkedin",
      priority: "P1",
      examples: ["show the company profile"],
      description: "Open scoped company link and return to selected job."
    },
    {
      id: "LI08",
      site: "linkedin",
      priority: "P1",
      examples: ["draft a message to my test contact"],
      description: "Only if owned/consenting test contact; dictate without sending."
    },
    {
      id: "LI09",
      site: "linkedin",
      priority: "P1",
      examples: ["apply for this role"],
      description: "Stop at employer redirect; no submission in initial scope."
    },
    {
      id: "LI10",
      site: "linkedin",
      priority: "P2",
      examples: ["send this connection request"],
      description: "Not supported until recipient identity, note and confirmation flow are qualified."
    },
    {
      id: "IR01",
      site: "irctc",
      priority: "P0",
      examples: ["set origin to Chennai Central"],
      description: "Choose exact station suggestion and verify station name/code."
    },
    {
      id: "IR02",
      site: "irctc",
      priority: "P0",
      examples: ["set destination to Bengaluru City"],
      description: "Resolve exact destination separately; similar names require clarification."
    },
    {
      id: "IR03",
      site: "irctc",
      priority: "P0",
      examples: ["travel on 18 November 2026"],
      description: "Set and verify full date including year; reject past/invalid dates."
    },
    {
      id: "IR04",
      site: "irctc",
      priority: "P0",
      examples: ["choose AC three tier"],
      description: "Set only visible options and announce final values."
    },
    {
      id: "IR05",
      site: "irctc",
      priority: "P0",
      examples: ["search trains"],
      description: "Submit once after previewing origin, destination, date and options."
    },
    {
      id: "IR06",
      site: "irctc",
      priority: "P0",
      examples: ["open train 12627"],
      description: "Verify train number/name, journey date and route."
    },
    {
      id: "IR07",
      site: "irctc",
      priority: "P0",
      examples: ["show availability"],
      description: "Read displayed availability/fare as transient site data with timestamp/context."
    },
    {
      id: "IR08",
      site: "irctc",
      priority: "P0",
      examples: ["swap origin and destination"],
      description: "Swap explicitly and verify both fields before searching again."
    },
    {
      id: "IR09",
      site: "irctc",
      priority: "P1",
      examples: ["sort by departure time"],
      description: "Only if exposed; verify actual sort state."
    },
    {
      id: "IR10",
      site: "irctc",
      priority: "P1",
      examples: ["add passenger"],
      description: "Fixture-only dummy data initially; no live passenger details or booking."
    },
    {
      id: "IR11",
      site: "irctc",
      priority: "P2",
      examples: ["book this ticket"],
      description: "Rejected in initial release; never activate booking/payment controls."
    },
    {
      id: "MAP01",
      site: "maps",
      priority: "P0",
      examples: ["find the Bengaluru Palace"],
      description: "Resolve place by name/address and ask when same-name results exist."
    },
    {
      id: "MAP02",
      site: "maps",
      priority: "P0",
      examples: ["open the second result"],
      description: "Bind ordinal to the latest announced list and verify place identity."
    },
    {
      id: "MAP03",
      site: "maps",
      priority: "P0",
      examples: ["read the address"],
      description: "Read only visible current-place facts and identify unavailable values."
    },
    {
      id: "MAP04",
      site: "maps",
      priority: "P0",
      examples: ["get directions from Bengaluru Palace to Bengaluru airport"],
      description: "Resolve both endpoints separately; require confirmation of exact places."
    },
    {
      id: "MAP05",
      site: "maps",
      priority: "P0",
      examples: ["switch to walking"],
      description: "Set route mode and verify endpoints/mode."
    },
    {
      id: "MAP06",
      site: "maps",
      priority: "P0",
      examples: ["choose the fastest route"],
      description: "Select among announced alternatives and verify route summary."
    },
    {
      id: "MAP07",
      site: "maps",
      priority: "P0",
      examples: ["zoom the map in"],
      description: "Change map scale using supported controls; verify map, not browser zoom."
    },
    {
      id: "MAP08",
      site: "maps",
      priority: "P0",
      examples: ["pan the map east"],
      description: "Only if a semantic keyboard/control route is available; verify center changed."
    },
    {
      id: "MAP09",
      site: "maps",
      priority: "P1",
      examples: ["search near this place for cafes"],
      description: "Use current place as grounded location and verify result scope."
    },
    {
      id: "MAP10",
      site: "maps",
      priority: "P1",
      examples: ["avoid tolls"],
      description: "Set available route options and verify route recomputation."
    },
    {
      id: "MAP11",
      site: "maps",
      priority: "P2",
      examples: ["start navigation"],
      description: "Not claimed on desktop. Mobile navigation and Street View require separate adapters."
    },
    {
      id: "YT01",
      site: "youtube",
      priority: "P0",
      examples: ["Search YouTube for Formula 1 highlights"],
      description: "Search YouTube and verify that results are visible."
    },
    {
      id: "YT02",
      site: "youtube",
      priority: "P0",
      examples: ["List videos on screen", "list results"],
      description: "Announce numbered visible video cards in visual reading order."
    },
    {
      id: "YT03",
      site: "youtube",
      priority: "P0",
      examples: ["Open video two", "play the third video"],
      description: "Open a video from the current announced visible list."
    },
    {
      id: "YT04",
      site: "youtube",
      priority: "P0",
      examples: ["Open the video titled WTF is a Googlebook?"],
      description: "Match a visible video title and clarify duplicate matches."
    },
    {
      id: "YT05",
      site: "youtube",
      priority: "P0",
      examples: ["Pause", "resume the video"],
      description: "Control the current YouTube player and verify playback state."
    },
    {
      id: "YT11",
      site: "youtube",
      priority: "P0",
      examples: ["Resume the video", "play YouTube"],
      description: "Resume the current YouTube player and verify playback state."
    },
    {
      id: "YT06",
      site: "youtube",
      priority: "P0",
      examples: ["Skip forward thirty seconds", "go back ten seconds"],
      description: "Seek relative to the current video time."
    },
    {
      id: "YT07",
      site: "youtube",
      priority: "P0",
      examples: ["Set volume to forty percent", "mute the video"],
      description: "Set or mute the current player volume."
    },
    {
      id: "YT12",
      site: "youtube",
      priority: "P0",
      examples: ["Mute the video", "unmute YouTube"],
      description: "Mute or unmute the current YouTube player."
    },
    {
      id: "YT08",
      site: "youtube",
      priority: "P0",
      examples: ["Turn captions on", "turn captions off"],
      description: "Set the current video's caption state when controls are available."
    },
    {
      id: "YT09",
      site: "youtube",
      priority: "P0",
      examples: ["Set playback speed to one point five"],
      description: "Set supported playback rate and verify the player value."
    },
    {
      id: "YT10",
      site: "youtube",
      priority: "P0",
      examples: ["What video is playing?"],
      description: "Read the current video title and channel."
    },
    {
      id: "CH01",
      site: "chatgpt",
      priority: "P0",
      examples: ["Start a new chat"],
      description: "Open a new ChatGPT conversation."
    },
    {
      id: "CH02",
      site: "chatgpt",
      priority: "P0",
      examples: ["Ask AI how photosynthesis works", "Ask this assistant a question"],
      description: "Send only an explicit, user-spoken prompt to the current ChatGPT page."
    },
    {
      id: "CH03",
      site: "chatgpt",
      priority: "P0",
      examples: ["Summarize this chat", "Summarize this conversation"],
      description: "Ask ChatGPT to summarize the current conversation."
    },
    {
      id: "CH04",
      site: "chatgpt",
      priority: "P0",
      examples: ["Stop generating"],
      description: "Stop the current response generation."
    },
    {
      id: "CH05",
      site: "chatgpt",
      priority: "P0",
      examples: ["Regenerate the response"],
      description: "Regenerate the current assistant response if available."
    },
    {
      id: "CH06",
      site: "chatgpt",
      priority: "P0",
      examples: ["Read the last response"],
      description: "Read a bounded excerpt from the latest visible response."
    },
    {
      id: "CH07",
      site: "chatgpt",
      priority: "P0",
      examples: ["List conversations", "open conversation two"],
      description: "List visible sidebar conversations and open a numbered choice."
    }
  ];
  function siteForUrl(url) {
    try {
      const u = new URL(url);
      if (u.protocol !== "https:" || u.username || u.password || u.port)
        return null;
      if (["www.google.com", "google.com"].includes(u.hostname))
        return /^\/maps(?:\/|$)/.test(u.pathname) ? "maps" : null;
      return {
        "en.wikipedia.org": "wikipedia",
        "www.wikipedia.org": "wikipedia",
        "github.com": "github",
        "reddit.com": "reddit",
        "www.reddit.com": "reddit",
        "amazon.in": "amazon",
        "www.amazon.in": "amazon",
        "open.spotify.com": "spotify",
        "netflix.com": "netflix",
        "www.netflix.com": "netflix",
        "x.com": "x",
        "www.x.com": "x",
        "twitter.com": "x",
        "web.whatsapp.com": "whatsapp",
        "mail.google.com": "gmail",
        "meet.google.com": "meet",
        "linkedin.com": "linkedin",
        "www.linkedin.com": "linkedin",
        "irctc.co.in": "irctc",
        "www.irctc.co.in": "irctc",
        "maps.google.com": "maps",
        "youtube.com": "youtube",
        "www.youtube.com": "youtube",
        "m.youtube.com": "youtube",
        "chatgpt.com": "chatgpt",
        "www.chatgpt.com": "chatgpt"
      }[u.hostname] ?? null;
    } catch {
      return null;
    }
  }

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/whatsapp.ts
  var whatsapp = {
    site: "whatsapp",
    scope: "#main",
    current: '#main header [data-testid="conversation-info-header-chat-title"],#main header [title]:not([data-testid="conversation-info-header-chat-title"]):not([data-testid="conversation-info-header-chat-title"] *)',
    currentKind: "chat",
    entities: {
      chat: '#pane-side [role="row"]',
      message: "#main .message-in,#main .message-out"
    },
    actions: [
      {
        id: "WA01",
        pattern: /^(?:open (?:my |the )?chat with|search(?: for)?|find (?:the )?conversation with) (.+)$/,
        extract: "query",
        operation: { kind: "entities", entity: "chat" }
      },
      {
        id: "WA02",
        pattern: /^(?:show unread chats|open the next chat|next chat)$/,
        extract: "mode",
        operation: { kind: "group-b" }
      },
      {
        id: "WA03",
        pattern: /^read (?:the )?(latest|previous) message$/,
        extract: "mode",
        operation: { kind: "group-b", scope: "#main" }
      },
      {
        id: "WA04",
        pattern: /^(?:go to the newest message|scroll (older|newer) messages)$/,
        extract: "mode",
        operation: { kind: "group-b", scope: "#main" }
      },
      {
        id: "WA05",
        pattern: /^(?:write|dictate|draft) (?:a |the )?message$/,
        operation: { kind: "group-b", scope: "#main" }
      },
      {
        id: "WA06",
        guardNames: ["Send"],
        pattern: /^(?:send (?:this|the)(?: message| draft| to my test chat)?|please send my draft)$/,
        write: true,
        operation: { kind: "group-b", scope: "#main" }
      },
      {
        id: "WA07",
        guardNames: ["Clear draft"],
        pattern: /^(?:clear (?:this|the) draft|cancel sending)$/,
        write: true,
        extract: "mode",
        operation: { kind: "group-b", scope: "#main" }
      },
      {
        id: "WA08",
        pattern: /^search this chat for (.+)$/,
        extract: "query",
        operation: { kind: "group-b", scope: "#main" }
      },
      {
        id: "WA09",
        pattern: /^(open|close) chat info$/,
        extract: "mode",
        operation: { kind: "group-b", scope: "#main" }
      },
      {
        id: "WA10",
        pattern: /^reply to that message$/,
        operation: {
          kind: "unsupported",
          reason: "Quoted message replies need a selected message and are not supported yet. The chat draft remains available."
        }
      },
      {
        id: "WA11",
        pattern: /^call this contact$/,
        operation: {
          kind: "unsupported",
          reason: "WhatsApp calls are outside the supported desktop workflows."
        }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/gmail.ts
  var gmail = {
    site: "gmail",
    scope: '[role="main"]',
    current: '[role="main"] h2.hP',
    currentKind: "thread",
    entities: { thread: '[role="main"] tr.zA', draft: '[role="dialog"]' },
    actions: [
      {
        id: "GM01",
        pattern: /^search(?: gmail)?(?: for)? (.+)$/,
        extract: "query",
        operation: { kind: "group-b" }
      },
      {
        id: "GM02",
        pattern: /^open (?:the )?(.+?)(?: result| email| conversation)$/,
        extract: "query",
        operation: { kind: "entities", entity: "thread" }
      },
      {
        id: "GM03",
        pattern: /^(?:go back to inbox|expand the latest message)$/,
        extract: "mode",
        operation: { kind: "group-b" }
      },
      {
        id: "GM04",
        pattern: /^(?:compose (?:an |a )?email|write (?:the )?(recipient|subject|body)(?: field)?)$/,
        extract: "mode",
        operation: { kind: "group-b" }
      },
      {
        id: "GM05",
        guardNames: ["Send", "Send \u202A(Ctrl-Enter)\u202C"],
        pattern: /^send (?:this|the) (?:email|draft|to my test address)$/,
        write: true,
        operation: {
          kind: "group-b",
          scope: '[role="dialog"],[data-reply-editor],.ip.adB'
        }
      },
      {
        id: "GM06",
        pattern: /^(?:reply to this email|answer the latest email)$/,
        operation: { kind: "group-b", scope: '[role="main"]' }
      },
      {
        id: "GM07",
        guardNames: ["Archive", "Move to Inbox"],
        pattern: /^(?:archive this conversation|restore that email)$/,
        extract: "mode",
        write: true,
        operation: { kind: "group-b", scope: '[role="main"]' }
      },
      {
        id: "GM08",
        guardNames: ["Mark as read", "Mark as unread"],
        pattern: /^mark as (unread|read)$/,
        extract: "mode",
        write: true,
        operation: { kind: "group-b", scope: '[role="main"]' }
      },
      {
        id: "GM09",
        pattern: /^switch to the other draft$/,
        operation: { kind: "entities", entity: "draft", selectOnly: true }
      },
      {
        id: "GM10",
        guardNames: ["Discard draft", "Discard"],
        pattern: /^discard (?:this|the) draft$/,
        write: true,
        operation: { kind: "group-b", scope: '[role="dialog"]' }
      },
      {
        id: "GM11",
        pattern: /^attach (?:the )?(.+)$/,
        extract: "query",
        operation: {
          kind: "unsupported",
          reason: "File attachments require an assisted browser file picker and are outside this release."
        }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/meet.ts
  var meet = {
    site: "meet",
    scope: "body",
    current: '[data-meeting-title],[aria-label="Meeting details"]',
    currentKind: "meeting",
    entities: { meeting: 'a[href^="https://meet.google.com/"]' },
    actions: [
      {
        id: "ME01",
        guardNames: ["Join now", "Ask to join"],
        pattern: /^(?:join this meeting|open my test meeting)$/,
        write: true,
        operation: { kind: "group-b" }
      },
      {
        id: "ME02",
        pattern: /^(?:mute (?:my )?(?:meeting|meet) (?:microphone|mic)|unmute(?: my)?(?: meeting)?(?: microphone| mic| meet)?)$/,
        extract: "mode",
        operation: { kind: "group-b" }
      },
      {
        id: "ME03",
        pattern: /^turn (?:my )?(?:meet|meeting) camera (off|on)$/,
        extract: "mode",
        operation: { kind: "group-b" }
      },
      {
        id: "ME04",
        pattern: /^turn captions (on|off)$/,
        extract: "mode",
        operation: { kind: "group-b" }
      },
      {
        id: "ME05",
        pattern: /^(raise|lower) my hand$/,
        extract: "mode",
        operation: { kind: "group-b" }
      },
      {
        id: "ME06",
        pattern: /^open (participants|meeting chat)$/,
        extract: "mode",
        operation: { kind: "group-b" }
      },
      {
        id: "ME07",
        pattern: /^write a chat message$/,
        operation: {
          kind: "group-b",
          scope: '[aria-label="In-call messages"],[data-panel-id="chat"]'
        }
      },
      {
        id: "ME08",
        guardNames: ["Send a message", "Send"],
        pattern: /^send (?:this|the)(?: message)? to the meeting$/,
        write: true,
        operation: {
          kind: "group-b",
          scope: '[aria-label="In-call messages"],[data-panel-id="chat"]'
        }
      },
      {
        id: "ME09",
        pattern: /^present this tab$/,
        operation: {
          kind: "unsupported",
          reason: "Screen presentation requires an assisted browser-owned picker and is not automated."
        }
      },
      {
        id: "ME10",
        guardNames: ["Leave call"],
        pattern: /^leave (?:the|this) meeting$/,
        write: true,
        operation: { kind: "group-b" }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/linkedin.ts
  var linkedin = {
    site: "linkedin",
    scope: "main",
    current: ".job-details-jobs-unified-top-card__job-title,.jobs-unified-top-card__job-title",
    currentKind: "job",
    entities: {
      job: 'a.job-card-list__title--link,a.job-card-container__link,[data-job-id] a[href*="/jobs/view/"]'
    },
    actions: [
      {
        id: "LI01",
        pattern: /^(?:search linkedin jobs for|look for|find) (.+?)(?: jobs| roles)?$/,
        extract: "query",
        operation: {
          kind: "search",
          url: "https://www.linkedin.com/jobs/search/?keywords={query}"
        }
      },
      {
        id: "LI02",
        pattern: /^set location to (.+)$/,
        extract: "query",
        operation: { kind: "group-b" }
      },
      {
        id: "LI03",
        pattern: /^(?:filter for|choose) (remote jobs|full time|part time|hybrid jobs|on site jobs)$/,
        extract: "query",
        operation: { kind: "group-b" }
      },
      {
        id: "LI04",
        pattern: /^open (?:the )?(.+) job$/,
        extract: "query",
        operation: { kind: "entities", entity: "job" }
      },
      {
        id: "LI05",
        pattern: /^(?:read job details|return to results)$/,
        extract: "mode",
        operation: { kind: "group-b" }
      },
      {
        id: "LI06",
        guardNames: ["Save", "Saved", "Unsave"],
        pattern: /^(save|unsave) (?:this|the) job$/,
        extract: "mode",
        write: true,
        operation: {
          kind: "group-b",
          scope: ".jobs-search__job-details--container,.jobs-details,.job-view-layout"
        }
      },
      {
        id: "LI07",
        pattern: /^show the company profile$/,
        operation: { kind: "group-b" }
      },
      {
        id: "LI08",
        pattern: /^draft a message to my test contact$/,
        operation: {
          kind: "unsupported",
          reason: "Contact-specific LinkedIn messaging is outside the qualified job-search adapter."
        }
      },
      {
        id: "LI09",
        pattern: /^apply for this role$/,
        operation: {
          kind: "unsupported",
          reason: "Applications and employer redirects require assisted review. No application was submitted."
        }
      },
      {
        id: "LI10",
        pattern: /^send this connection request$/,
        operation: {
          kind: "unsupported",
          reason: "Connection requests and bulk outreach are outside the supported workflows."
        }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/irctc.ts
  var irctc = {
    site: "irctc",
    scope: "app-train-search,app-train-list",
    current: '[data-train-number][aria-selected="true"],.train-heading',
    currentKind: "train",
    entities: {
      station: 'p-autocomplete [role="option"],p-autocomplete .ui-autocomplete-list-item',
      train: "[data-train-number],.train-heading"
    },
    actions: [
      {
        id: "IR01",
        pattern: /^set (?:origin|from) to (.+)$/,
        extract: "query",
        operation: { kind: "group-b" }
      },
      {
        id: "IR02",
        pattern: /^set (?:destination|to) to (.+)$/,
        extract: "query",
        operation: { kind: "group-b" }
      },
      {
        id: "IR03",
        pattern: /^(?:travel on|set (?:the )?date to) (.+)$/,
        extract: "query",
        operation: { kind: "group-b" }
      },
      {
        id: "IR04",
        pattern: /^(?:choose|select) (.+)$/,
        extract: "query",
        operation: { kind: "group-b" }
      },
      {
        id: "IR05",
        guardNames: ["Search", "Search trains"],
        pattern: /^(?:search|find) trains$/,
        write: true,
        operation: { kind: "group-b" }
      },
      {
        id: "IR06",
        pattern: /^open train (.+)$/,
        extract: "query",
        operation: { kind: "entities", entity: "train" }
      },
      {
        id: "IR07",
        pattern: /^(?:show availability|read (?:the )?fare)$/,
        extract: "mode",
        operation: { kind: "group-b" }
      },
      {
        id: "IR08",
        pattern: /^swap origin and destination$/,
        operation: { kind: "group-b" }
      },
      {
        id: "IR09",
        pattern: /^sort by departure time$/,
        operation: { kind: "group-b" }
      },
      {
        id: "IR10",
        pattern: /^add passenger$/,
        operation: {
          kind: "unsupported",
          reason: "Passenger details and booking are excluded. Authentication, CAPTCHA and OTP need user assistance."
        }
      },
      {
        id: "IR11",
        pattern: /^book (?:this|the) ticket$/,
        operation: {
          kind: "unsupported",
          reason: "Ticket booking, payment and cancellation are excluded. No transaction control was activated."
        }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/maps.ts
  var maps = {
    site: "maps",
    scope: '[role="main"]',
    current: '[role="main"] h1',
    currentKind: "place",
    entities: {
      place: 'a.hfpxzc,a[href*="/maps/place/"][aria-label]',
      route: '[data-trip-index],[role="listitem"][data-route-index]'
    },
    actions: [
      {
        id: "MAP01",
        pattern: /^(?:find|look up|search maps for) (.+)$/,
        extract: "query",
        operation: {
          kind: "search",
          url: "https://www.google.com/maps/search/?api=1&query={query}"
        }
      },
      {
        id: "MAP02",
        pattern: /^open (?:the )?(.+) result$/,
        extract: "query",
        operation: { kind: "entities", entity: "place" }
      },
      {
        id: "MAP03",
        pattern: /^(?:read (?:the )?address|show opening hours)$/,
        extract: "mode",
        operation: { kind: "group-b" }
      },
      {
        id: "MAP04",
        pattern: /^(?:(?:get|show) directions from (.+) to (.+)|review directions)$/,
        extract: "query",
        write: true,
        operation: { kind: "group-b" }
      },
      {
        id: "MAP05",
        pattern: /^(?:use|switch to|show) (walking|driving|public transit|public transport|transit|cycling|bicycling)(?: directions)?$/,
        extract: "mode",
        operation: { kind: "group-b" }
      },
      {
        id: "MAP06",
        pattern: /^choose (?:the )?(.+) route$/,
        extract: "query",
        operation: { kind: "entities", entity: "route" }
      },
      {
        id: "MAP07",
        pattern: /^zoom (?:the map )?(in|out)(?: one level)?$/,
        extract: "mode",
        operation: { kind: "group-b" }
      },
      {
        id: "MAP08",
        pattern: /^pan the map (north|south|east|west)$/,
        extract: "mode",
        operation: {
          kind: "unsupported",
          reason: "This canvas has no qualified semantic pan control. Dragging and synthetic keyboard panning are not claimed."
        }
      },
      {
        id: "MAP09",
        pattern: /^search near this place for (.+)$/,
        extract: "query",
        operation: { kind: "group-b" }
      },
      {
        id: "MAP10",
        pattern: /^avoid (tolls|highways)$/,
        extract: "mode",
        operation: { kind: "group-b" }
      },
      {
        id: "MAP11",
        pattern: /^start navigation$/,
        operation: {
          kind: "unsupported",
          reason: "Desktop route planning is supported. Live turn-by-turn navigation and Street View are outside this adapter."
        }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/wikipedia.ts
  var wikipedia = {
    site: "wikipedia",
    scope: "#mw-content-text",
    current: "#firstHeading",
    entities: {
      article: ".mw-search-result-heading a, .mw-parser-output .hatnote a, .mw-parser-output ul > li > a",
      section: ".mw-parser-output h2[id],.mw-parser-output h3[id],.mw-heading h2[id],.mw-heading h3[id]",
      link: ".mw-parser-output p a[href]",
      reference: ".references li[id]"
    },
    actions: [
      {
        id: "W01",
        pattern: /^(?:search(?: wikipedia)?(?: for)?|look up|find an article about) (.+)$/,
        extract: "query",
        operation: {
          kind: "search",
          url: "https://en.wikipedia.org/w/index.php?search={query}"
        }
      },
      {
        id: "W02",
        pattern: /^(?:open|choose)(?: the)? (.+?)(?: search)? result$/,
        extract: "ordinal",
        operation: { kind: "entities", entity: "article" }
      },
      {
        id: "W03",
        pattern: /^(?:choose|i mean) (.+)$/,
        extract: "query",
        operation: { kind: "entities", entity: "article" }
      },
      {
        id: "W04",
        pattern: /^(?:open|go to|take me to)(?: the)? (.+?)(?: section)?$/,
        extract: "query",
        operation: { kind: "section" }
      },
      {
        id: "W05",
        pattern: /^(?:list(?: the)? sections|what headings are here)$/,
        operation: { kind: "sections" }
      },
      {
        id: "W06",
        pattern: /^(next section|previous heading|previous section)$/,
        extract: "mode",
        operation: { kind: "section-next" }
      },
      {
        id: "W07",
        pattern: /^(?:go to(?: the)? introduction|start of(?: the)? article)$/,
        operation: { kind: "introduction" }
      },
      {
        id: "W08",
        pattern: /^(?:open|follow|find|select)(?: the)? link(?: called)? (.+)$/,
        extract: "query",
        operation: { kind: "entities", entity: "link" }
      },
      {
        id: "W09",
        pattern: /^open (?:that|this|the selected) link in a new tab$/,
        operation: { kind: "entities", entity: "link" }
      },
      {
        id: "W10",
        pattern: /^(?:show reference|open citation(?: number)?) (.+)$/,
        extract: "number",
        operation: { kind: "reference" }
      },
      {
        id: "W11",
        pattern: /^(?:back to(?: the)? sentence|return from(?: the)? reference)$/,
        operation: { kind: "reference-return" }
      },
      {
        id: "W12",
        pattern: /^find (.+) in (?:this|the) article$/,
        extract: "query",
        operation: { kind: "find" }
      },
      {
        id: "W13",
        pattern: /^(next match|previous occurrence|previous match)$/,
        extract: "mode",
        operation: { kind: "find-next" }
      },
      {
        id: "W14",
        pattern: /^(?:show(?: the)? contents|expand(?: the)? table of contents|table of contents)$/,
        operation: { kind: "sections" }
      },
      {
        id: "W16",
        pattern: /^(?:show(?: the)? infobox|go to(?: the)? facts box)$/,
        operation: { kind: "section" }
      },
      {
        id: "W19",
        pattern: /^(?:show|go to) (references|external links)$/,
        extract: "query",
        operation: { kind: "section" }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/github.ts
  var github = {
    site: "github",
    scope: "main",
    current: '[itemprop="name"] a, strong[itemprop="name"], [data-testid="issue-title"], .markdown-title',
    entities: {
      repository: 'a[data-testid="result-repository"], .search-title a, h3 a[href]',
      folder: '[role="row"] a[href*="/tree/"], .react-directory-filename-cell a[href*="/tree/"]',
      file: '[role="row"] a[href*="/blob/"], .react-directory-filename-cell a[href*="/blob/"], [role="dialog"] a[href*="/blob/"]',
      issue: 'a[href*="/issues/"][data-hovercard-type="issue"], .Link--primary[href*="/issues/"]',
      "pull-request": 'a[href*="/pull/"][data-hovercard-type="pull_request"]'
    },
    actions: [
      {
        id: "G01",
        pattern: /^search(?: github)?(?: for)? (.+)$/,
        extract: "query",
        operation: { kind: "search", url: "https://github.com/search?q={query}" }
      },
      {
        id: "G02",
        pattern: /^(?:show|search only)(?: the)? (repository results|repositories|issues|code|users)$/,
        extract: "query",
        operation: {
          kind: "control",
          names: ["Repositories", "Issues", "Code", "Users"],
          scope: '[aria-label="Search filters"],nav',
          verify: "selected"
        }
      },
      {
        id: "G03",
        pattern: /^open (.+?)(?: repository)?$/,
        extract: "query",
        operation: { kind: "entities", entity: "repository" }
      },
      {
        id: "G04",
        pattern: /^(?:show(?: the)? readme|go to repository overview)$/,
        operation: { kind: "route", path: "/{repo}" }
      },
      {
        id: "G05",
        pattern: /^open (?:the )?(.+) folder$/,
        extract: "query",
        operation: { kind: "entities", entity: "folder" }
      },
      {
        id: "G06",
        pattern: /^open (.+(?: dot |\.).+)$/,
        extract: "query",
        operation: { kind: "entities", entity: "file" }
      },
      {
        id: "G07",
        pattern: /^go up one folder$/,
        operation: { kind: "route", path: "{parent}" }
      },
      {
        id: "G08",
        pattern: /^find a file named (.+)$/,
        extract: "query",
        operation: { kind: "entities", entity: "file", selectOnly: true }
      },
      {
        id: "G09",
        pattern: /^switch to(?: the)? (.+) branch$/,
        extract: "query",
        operation: {
          kind: "control",
          names: [],
          verify: "entity-change"
        }
      },
      {
        id: "G10",
        pattern: /^(?:open|show) (issues|pull requests)$/,
        extract: "mode",
        operation: { kind: "route", path: "/{repo}/{mode}" }
      },
      {
        id: "G11",
        pattern: /^(?:search issues(?: for)? (.+)|show (open|closed) issues)$/,
        extract: "query",
        operation: {
          kind: "search",
          url: "https://github.com/{repo}/issues?q={query}"
        }
      },
      {
        id: "G12",
        pattern: /^open issue (.+)$/,
        extract: "number",
        operation: { kind: "route", path: "/{repo}/issues/{value}" }
      },
      {
        id: "G13",
        pattern: /^open pull request (.+)$/,
        extract: "number",
        operation: { kind: "route", path: "/{repo}/pull/{value}" }
      },
      {
        id: "G14",
        pattern: /^(?:show(?: the)? (changed files)|open(?: the)? (conversation))$/,
        extract: "mode",
        operation: {
          kind: "control",
          names: ["Files changed", "Conversation"],
          scope: '[aria-label="Pull request tabs"],nav',
          verify: "selected"
        }
      },
      {
        id: "G15",
        pattern: /^(?:star(?: this)?(?: repository)?|like this repo|like this)$/,
        write: true,
        operation: {
          kind: "state",
          names: ["Star", "Star this repository"],
          opposite: ["Unstar", "Unstar this repository"],
          desired: true,
          scope: "main"
        }
      },
      {
        id: "G16",
        pattern: /^(?:remove my star|unstar(?: this)?(?: repository)?)$/,
        write: true,
        operation: {
          kind: "state",
          names: ["Star", "Star this repository"],
          opposite: ["Unstar", "Unstar this repository"],
          desired: false,
          scope: "main"
        }
      },
      {
        id: "G17",
        pattern: /^show commits$/,
        operation: { kind: "route", path: "/{repo}/commits" }
      },
      {
        id: "G18",
        pattern: /^show releases$/,
        operation: { kind: "route", path: "/{repo}/releases" }
      },
      {
        id: "G19",
        pattern: /^(?:go to|show) line (.+)$/,
        extract: "number",
        operation: { kind: "section" }
      },
      {
        id: "G21",
        pattern: /^create a new issue draft$/,
        operation: { kind: "route", path: "/{repo}/issues/new" }
      },
      {
        id: "G22",
        pattern: /^(?:write|select)(?: the)?(?: issue)? (title|body|description)(?: field)?$/,
        extract: "mode",
        operation: {
          kind: "field",
          names: [
            "Title",
            "Add a title",
            "Add a description",
            "Description",
            "Body"
          ],
          scope: "main form"
        }
      },
      {
        id: "G23",
        pattern: /^(?:preview(?: the)? issue|show edit mode)$/,
        operation: {
          kind: "control",
          names: ["Preview", "Write"],
          scope: "main form",
          verify: "selected"
        }
      },
      {
        id: "G24",
        pattern: /^submit (?:this|the) issue$/,
        write: true,
        operation: {
          kind: "submit",
          names: ["Submit new issue", "Create issue"],
          scope: "main form",
          created: '[data-testid="issue-title"],.markdown-title'
        }
      },
      {
        id: "G25",
        pattern: /^(?:reply to this issue|write a comment)$/,
        operation: {
          kind: "field",
          names: ["Leave a comment", "Add a comment", "Comment"],
          scope: "main form"
        }
      },
      {
        id: "G26",
        pattern: /^post (?:the|this) comment$/,
        write: true,
        operation: {
          kind: "submit",
          names: ["Comment"],
          scope: "main form",
          created: ".timeline-comment"
        }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/reddit.ts
  var reddit = {
    site: "reddit",
    scope: "main,shreddit-post",
    current: "shreddit-post[post-title], main h1",
    entities: {
      post: 'shreddit-post,article[data-testid="post-container"],.Post',
      comment: 'shreddit-comment,[data-testid="comment"],.Comment',
      community: 'a[href^="/r/"]'
    },
    actions: [
      {
        id: "R01",
        pattern: /^search(?: reddit)?(?: for)? (.+)$/,
        extract: "query",
        operation: {
          kind: "search",
          url: "https://www.reddit.com/search/?q={query}"
        }
      },
      {
        id: "R02",
        pattern: /^search within this community(?: for)? (.+)$/,
        extract: "query",
        operation: {
          kind: "search",
          url: "https://www.reddit.com/r/{community}/search/?q={query}&restrict_sr=on"
        }
      },
      {
        id: "R03",
        pattern: /^open r(?: slash |\/)([\w]+)$/,
        extract: "query",
        operation: { kind: "route", path: "/r/{query}/" }
      },
      {
        id: "R04",
        pattern: /^open (?:the )?(.+) post$/,
        extract: "query",
        operation: { kind: "entities", entity: "post" }
      },
      {
        id: "R05",
        pattern: /^(next post|previous post)$/,
        extract: "mode",
        operation: { kind: "entities", entity: "post", selectOnly: true }
      },
      {
        id: "R06",
        pattern: /^(?:show comments|open(?: the)? discussion)$/,
        operation: { kind: "entities", entity: "post" }
      },
      {
        id: "R07",
        pattern: /^(?:sort posts by|show) (new|hot|top|best)(?: posts)?(?: (today|this week|this month|all time))?$/,
        extract: "query",
        operation: {
          kind: "control",
          names: [],
          scope: 'main, [role="menu"]',
          verify: "selected"
        }
      },
      {
        id: "R08",
        pattern: /^(?:sort comments by|show) (best|new|top|old|controversial)(?: comments)?$/,
        extract: "query",
        operation: {
          kind: "control",
          names: [],
          scope: '[aria-label="Comment sort"],[role="menu"]',
          verify: "selected"
        }
      },
      {
        id: "R09",
        pattern: /^(?:expand this thread|show(?: the)? replies to comment (.+))$/,
        extract: "number",
        operation: {
          kind: "control",
          names: ["Expand", "Expand thread", "Show replies"],
          verify: "expanded"
        }
      },
      {
        id: "R10",
        pattern: /^collapse this comment thread$/,
        operation: {
          kind: "control",
          names: ["Collapse", "Collapse thread"],
          verify: "expanded"
        }
      },
      {
        id: "R11",
        pattern: /^(next comment|previous comment|go to the parent comment)$/,
        extract: "mode",
        operation: { kind: "entities", entity: "comment", selectOnly: true }
      },
      {
        id: "R12",
        pattern: /^(?:like(?: this| the)?(?: post| video)?|upvote(?: this| the)?(?: post| video)?)$/,
        write: true,
        operation: {
          kind: "state",
          names: ["Upvote"],
          opposite: ["Remove upvote", "Upvoted"],
          desired: true
        }
      },
      {
        id: "R13",
        pattern: /^(?:downvote this post|give it a downvote)$/,
        write: true,
        operation: {
          kind: "state",
          names: ["Downvote"],
          opposite: ["Remove downvote", "Downvoted"],
          desired: true
        }
      },
      {
        id: "R14",
        pattern: /^(?:remove my vote|undo that upvote)$/,
        write: true,
        operation: {
          kind: "state",
          names: ["Upvote"],
          opposite: ["Remove upvote", "Upvoted"],
          desired: false
        }
      },
      {
        id: "R15",
        pattern: /^upvote this comment$/,
        write: true,
        operation: {
          kind: "state",
          names: ["Upvote"],
          opposite: ["Remove upvote", "Upvoted"],
          desired: true
        }
      },
      {
        id: "R16",
        pattern: /^(?:close this post|return to(?: the)? feed)$/,
        operation: { kind: "back" }
      },
      {
        id: "R17",
        pattern: /^(save this post|unsave it)$/,
        extract: "mode",
        write: true,
        operation: {
          kind: "state",
          names: ["Save"],
          opposite: ["Unsave"],
          desired: true
        }
      },
      {
        id: "R20",
        pattern: /^reply to (?:this post|comment (.+))$/,
        extract: "number",
        operation: {
          kind: "control",
          names: ["Reply", "Add a comment"],
          verify: "expanded"
        }
      },
      {
        id: "R21",
        pattern: /^write (?:the|this) reply$/,
        operation: {
          kind: "field",
          names: ["Reply", "Add a comment", "Comment"],
          scope: 'form,[role="dialog"]'
        }
      },
      {
        id: "R22",
        pattern: /^post (?:this|the) reply$/,
        write: true,
        operation: {
          kind: "submit",
          names: ["Reply", "Comment", "Post"],
          scope: "form",
          created: 'shreddit-comment,[data-testid="comment"]'
        }
      },
      {
        id: "R23",
        pattern: /^discard (?:this|the) reply$/,
        write: true,
        operation: { kind: "clear-draft", scope: "form" }
      },
      {
        id: "R24",
        pattern: /^(play this post.s video|pause(?: the| this)?(?: video)?)$/,
        extract: "mode",
        operation: { kind: "media", command: "play" }
      },
      {
        id: "R25",
        pattern: /^(mute this video|unmute it)$/,
        extract: "mode",
        operation: { kind: "media", command: "mute" }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/amazon.ts
  var amazon = {
    site: "amazon",
    scope: "#dp, #search, #sc-active-cart",
    current: "#productTitle",
    entities: {
      product: '[data-component-type="s-search-result"][data-asin] h2 a, [data-component-type="s-search-result"][data-asin] a:has(h2), [data-asin].sc-list-item a.sc-product-link'
    },
    actions: [
      {
        id: "A01",
        pattern: /^search(?: amazon)?(?: for)? (.+)$/,
        extract: "query",
        operation: { kind: "search", url: "https://www.amazon.in/s?k={query}" }
      },
      {
        id: "A02",
        pattern: /^(?:show|open)(?: the)? (.+?)(?: product)?$/,
        extract: "query",
        operation: { kind: "entities", entity: "product" }
      },
      {
        id: "A03",
        pattern: /^(?:only show items |filter |show items )?under (.+?)(?: rupees)?$/,
        extract: "number",
        operation: { kind: "price", upper: "#high-price", submit: "Go" }
      },
      {
        id: "A04",
        pattern: /^between (.+) and (.+?)(?: rupees)?$/,
        extract: "number",
        operation: {
          kind: "price",
          lower: "#low-price",
          upper: "#high-price",
          submit: "Go"
        }
      },
      {
        id: "A05",
        pattern: /^(?:filter by (.+)|show(?: the)? (.+) brand)$/,
        extract: "query",
        operation: {
          kind: "control",
          names: [],
          scope: "#brandsRefinements",
          verify: "selected"
        }
      },
      {
        id: "A06",
        pattern: /^sort by (.+)$/,
        extract: "query",
        operation: { kind: "select", selector: "#s-result-sort-select" }
      },
      {
        id: "A07",
        pattern: /^(?:clear(?: the)? price filter|remove all filters)$/,
        operation: {
          kind: "control",
          names: ["Clear", "Clear all", "Clear all filters"],
          scope: "#s-refinements",
          verify: "entity-change"
        }
      },
      {
        id: "A08",
        pattern: /^(?:choose|select)(?: size)? (.+)$/,
        extract: "query",
        operation: {
          kind: "control",
          names: [],
          scope: "#twister,#twister_feature_div",
          verify: "selected"
        }
      },
      {
        id: "A09",
        pattern: /^choose (.+) version$/,
        extract: "query",
        operation: {
          kind: "control",
          names: [],
          scope: "#twister,#twister_feature_div",
          verify: "selected"
        }
      },
      {
        id: "A10",
        pattern: /^what variant is selected$/,
        operation: { kind: "info" }
      },
      {
        id: "A11",
        pattern: /^(?:show product details|go to specifications)$/,
        operation: { kind: "section" }
      },
      {
        id: "A12",
        pattern: /^show customer reviews$/,
        operation: { kind: "section" }
      },
      {
        id: "A13",
        pattern: /^(?:show (.+) reviews|sort reviews by (.+))$/,
        extract: "query",
        operation: {
          kind: "select",
          selector: "#review-sort-order,#filterByStar"
        }
      },
      {
        id: "A14",
        pattern: /^show the next product image$/,
        operation: {
          kind: "control",
          names: ["Next image", "Next"],
          scope: "#imageBlock,#ivLargeImage",
          verify: "entity-change"
        }
      },
      {
        id: "A15",
        pattern: /^close image zoom$/,
        operation: {
          kind: "control",
          names: ["Close"],
          scope: '[role="dialog"],#ivImagesTab',
          verify: "closed"
        }
      },
      {
        id: "A16",
        pattern: /^go back to search results$/,
        operation: { kind: "back" }
      },
      {
        id: "A17",
        pattern: /^add (?:one|1) of these to my cart$/,
        write: true,
        operation: {
          kind: "unsupported",
          reason: "Cart additions need a live-qualified product, variant, seller, price and cart postcondition. Use the local cart demo for now."
        }
      },
      {
        id: "A18",
        pattern: /^open my cart$/,
        operation: { kind: "route", path: "/gp/cart/view.html" }
      },
      {
        id: "A19",
        pattern: /^set this item.s quantity to (.+)$/,
        extract: "number",
        write: true,
        operation: {
          kind: "unsupported",
          reason: "Live cart changes are not qualified in this version."
        }
      },
      {
        id: "A20",
        pattern: /^remove (.+) from my cart$/,
        extract: "query",
        write: true,
        operation: {
          kind: "unsupported",
          reason: "Live cart removal is not qualified in this version."
        }
      },
      {
        id: "A24",
        pattern: /^show delivery information$/,
        operation: { kind: "section" }
      },
      {
        id: "A25",
        pattern: /^show other sellers$/,
        operation: {
          kind: "control",
          names: ["Other sellers on Amazon", "See all buying options"],
          verify: "expanded"
        }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/spotify.ts
  var spotify = {
    site: "spotify",
    scope: "main",
    current: '[data-testid="now-playing-widget"] [data-testid="context-item-link"], [data-testid="nowplaying-track-link"]',
    entities: {
      track: '[data-testid="tracklist-row"]',
      album: 'a[href^="/album/"]',
      playlist: 'a[href^="/playlist/"]',
      artist: 'a[href^="/artist/"]'
    },
    actions: [
      {
        id: "S01",
        pattern: /^search(?: spotify)?(?: for)? (.+)$/,
        extract: "query",
        operation: {
          kind: "search",
          url: "https://open.spotify.com/search/{query}"
        }
      },
      {
        id: "S02",
        pattern: /^show (songs|albums|playlists|artists|podcasts)$/,
        extract: "query",
        operation: {
          kind: "control",
          names: [],
          scope: "main",
          verify: "selected"
        }
      },
      {
        id: "S03",
        pattern: /^play (.+?)(?: by (.+))?$/,
        extract: "query",
        operation: { kind: "entities", entity: "track" }
      },
      {
        id: "S04",
        pattern: /^open(?: the)? album (.+)$/,
        extract: "query",
        operation: { kind: "entities", entity: "album" }
      },
      {
        id: "S05",
        pattern: /^(play this playlist|start the album)$/,
        operation: { kind: "media", command: "play" }
      },
      {
        id: "S06",
        pattern: /^(?:pause(?: the| this)?(?: song| music)?|hold(?: the)? music|stop playing for a moment)$/,
        operation: { kind: "media", command: "pause" }
      },
      {
        id: "S07",
        pattern: /^(?:resume(?: the| this)?(?: music| song)?|continue playing)$/,
        operation: { kind: "media", command: "play" }
      },
      {
        id: "S08",
        pattern: /^(?:next(?: track| song)?|skip this (?:song|track)|play the next one|move to the following track)$/,
        operation: { kind: "media", command: "next" }
      },
      {
        id: "S09",
        pattern: /^(previous track|previous song|restart this song)$/,
        extract: "mode",
        operation: { kind: "media", command: "previous" }
      },
      {
        id: "S10",
        pattern: /^(mute spotify|mute the player|unmute the player|unmute spotify)$/,
        extract: "mode",
        operation: { kind: "media", command: "mute" }
      },
      {
        id: "S11",
        pattern: /^set(?: player)? volume to (.+?)(?: percent|%)$/,
        extract: "number",
        operation: { kind: "media", command: "volume" }
      },
      {
        id: "S12",
        pattern: /^(?:turn it up a little|lower volume (.+?)(?: percent|%)|turn volume up (.+?)(?: percent|%))$/,
        extract: "number",
        operation: { kind: "media", command: "volume-relative" }
      },
      {
        id: "S13",
        pattern: /^(?:go |skip |seek )?(forward|back|rewind)(?: by)? (.+?)(?: seconds?)$/,
        extract: "number",
        operation: { kind: "media", command: "seek" }
      },
      {
        id: "S14",
        pattern: /^(?:jump|go) to (.+)$/,
        extract: "number",
        operation: { kind: "media", command: "seek-absolute" }
      },
      {
        id: "S15",
        pattern: /^what song is playing$/,
        operation: { kind: "info" }
      },
      {
        id: "S16",
        pattern: /^(?:like(?: this)?(?: song)?|save(?: the)? current track|give this a thumbs up|mark this as liked)$/,
        write: true,
        operation: {
          kind: "state",
          names: ["Add to Liked Songs", "Save to Your Library", "Save"],
          opposite: [
            "Remove from Liked Songs",
            "Remove from Your Library",
            "Saved"
          ],
          desired: true,
          scope: '[data-testid="now-playing-widget"]'
        }
      },
      {
        id: "S17",
        pattern: /^remove this from liked songs$/,
        write: true,
        operation: {
          kind: "state",
          names: ["Add to Liked Songs", "Save to Your Library", "Save"],
          opposite: [
            "Remove from Liked Songs",
            "Remove from Your Library",
            "Saved"
          ],
          desired: false,
          scope: '[data-testid="now-playing-widget"]'
        }
      },
      {
        id: "S18",
        pattern: /^(show my library|open liked songs)$/,
        extract: "mode",
        operation: { kind: "route", path: "/collection/tracks" }
      },
      {
        id: "S19",
        pattern: /^show the queue$/,
        operation: { kind: "control", names: ["Queue"], verify: "expanded" }
      },
      {
        id: "S27",
        pattern: /^(show lyrics|close lyrics)$/,
        extract: "mode",
        operation: { kind: "control", names: ["Lyrics"], verify: "expanded" }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/netflix.ts
  var netflix = {
    site: "netflix",
    scope: "main,.mainView,.watch-video",
    current: ".video-title h4,.previewModal--player-titleTreatmentWrapper img[alt],.title-title",
    entities: {
      profile: ".profile-link",
      title: '.title-card a[href*="/watch/"],.title-card a[href*="jbv="],.previewModal--player-titleTreatmentWrapper',
      episode: ".episodeSelector .episode-item"
    },
    actions: [
      {
        id: "N01",
        pattern: /^open the profile named (.+)$/,
        extract: "query",
        operation: { kind: "entities", entity: "profile" }
      },
      {
        id: "N02",
        pattern: /^search(?: netflix)?(?: for)? (.+)$/,
        extract: "query",
        operation: {
          kind: "search",
          url: "https://www.netflix.com/search?q={query}"
        }
      },
      {
        id: "N03",
        pattern: /^(?:open(?: the)? (.+) title|show this film.s details)$/,
        extract: "query",
        operation: { kind: "entities", entity: "title" }
      },
      {
        id: "N04",
        pattern: /^(?:play this title|start(?: the)? episode)$/,
        operation: { kind: "media", command: "play" }
      },
      {
        id: "N05",
        pattern: /^continue watching (.+)$/,
        extract: "query",
        operation: { kind: "entities", entity: "title" }
      },
      {
        id: "N06",
        pattern: /^(?:pause(?: the| this)?(?: video| episode)?|stop playing for a moment)$/,
        operation: { kind: "media", command: "pause" }
      },
      {
        id: "N07",
        pattern: /^(?:resume(?: the| this)?(?: episode| video)?|continue playing)$/,
        operation: { kind: "media", command: "play" }
      },
      {
        id: "N08",
        pattern: /^(?:go |skip |seek )?(forward|back|rewind)(?: by)? (.+?)(?: seconds?)$/,
        extract: "number",
        operation: { kind: "media", command: "seek" }
      },
      {
        id: "N09",
        pattern: /^go to (.+)$/,
        extract: "number",
        operation: { kind: "media", command: "seek-absolute" }
      },
      {
        id: "N10",
        pattern: /^(mute netflix|mute this video|unmute this video|unmute netflix)$/,
        extract: "mode",
        operation: { kind: "media", command: "mute" }
      },
      {
        id: "N11",
        pattern: /^set(?: player)? volume to (.+?)(?: percent|%)$/,
        extract: "number",
        operation: { kind: "media", command: "volume" }
      },
      { id: "N12", pattern: /^what am i watching$/, operation: { kind: "info" } },
      {
        id: "N13",
        pattern: /^(?:like(?: this| the)?(?: video| title)?|give this(?: title)? a thumbs up|mark this as liked)$/,
        write: true,
        operation: {
          kind: "state",
          names: ["I like this", "Thumbs up"],
          opposite: ["Rated: I like this", "Remove thumbs up rating"],
          desired: true,
          scope: '.previewModal,[data-uia="player"]'
        }
      },
      {
        id: "N14",
        pattern: /^remove my rating$/,
        write: true,
        operation: {
          kind: "state",
          names: ["I like this", "Thumbs up"],
          opposite: ["Rated: I like this", "Remove thumbs up rating"],
          desired: false,
          scope: '.previewModal,[data-uia="player"]'
        }
      },
      {
        id: "N15",
        pattern: /^(close the details|back to browsing)$/,
        operation: {
          kind: "control",
          names: ["Close", "Back to Browse"],
          scope: ".previewModal,.watch-video",
          verify: "closed"
        }
      },
      {
        id: "N16",
        pattern: /^(show episodes|open the episode list)$/,
        operation: { kind: "control", names: ["Episodes"], verify: "expanded" }
      },
      {
        id: "N17",
        pattern: /^choose season (.+)$/,
        extract: "number",
        operation: { kind: "select", selector: 'select[aria-label="Season"]' }
      },
      {
        id: "N18",
        pattern: /^play episode (.+)$/,
        extract: "ordinal",
        operation: { kind: "entities", entity: "episode" }
      },
      {
        id: "N19",
        pattern: /^next episode$/,
        operation: { kind: "media", command: "next" }
      },
      {
        id: "N20",
        pattern: /^skip intro$/,
        operation: { kind: "control", names: ["Skip Intro"], verify: "closed" }
      },
      {
        id: "N21",
        pattern: /^skip recap$/,
        operation: { kind: "control", names: ["Skip Recap"], verify: "closed" }
      },
      {
        id: "N22",
        pattern: /^turn on (.+) subtitles$/,
        extract: "query",
        operation: {
          kind: "control",
          names: [],
          scope: '[data-uia="subtitle-menu"]',
          verify: "selected"
        }
      },
      {
        id: "N23",
        pattern: /^turn subtitles off$/,
        operation: {
          kind: "control",
          names: ["Off"],
          scope: '[data-uia="subtitle-menu"]',
          verify: "selected"
        }
      },
      {
        id: "N24",
        pattern: /^switch audio to (.+)$/,
        extract: "query",
        operation: {
          kind: "control",
          names: [],
          scope: '[data-uia="audio-menu"]',
          verify: "selected"
        }
      },
      {
        id: "N25",
        pattern: /^show audio and subtitles$/,
        operation: {
          kind: "control",
          names: ["Audio & Subtitles", "Audio and subtitles"],
          verify: "expanded"
        }
      },
      {
        id: "N26",
        pattern: /^(go fullscreen|leave fullscreen)$/,
        operation: {
          kind: "unsupported",
          reason: "Chrome requires user activation for fullscreen. Voice-only fullscreen has not been qualified."
        }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/x.ts
  var x = {
    site: "x",
    scope: "main",
    current: '[data-testid="tweetDetail"]',
    entities: {
      post: 'article[data-testid="tweet"]',
      profile: 'a[data-testid="UserCell"]'
    },
    actions: [
      {
        id: "X01",
        pattern: /^search(?: x| twitter)?(?: for)? (.+)$/,
        extract: "query",
        operation: {
          kind: "search",
          url: "https://x.com/search?q={query}&src=typed_query"
        }
      },
      {
        id: "X02",
        pattern: /^open (?:the )?(.+) post$/,
        extract: "query",
        operation: { kind: "entities", entity: "post" }
      },
      {
        id: "X03",
        pattern: /^open the profile named (.+)$/,
        extract: "query",
        operation: { kind: "entities", entity: "profile" }
      },
      {
        id: "X04",
        pattern: /^show replies$/,
        operation: { kind: "entities", entity: "post" }
      },
      {
        id: "X05",
        pattern: /^next post$/,
        extract: "mode",
        operation: { kind: "entities", entity: "post", selectOnly: true }
      },
      {
        id: "X06",
        pattern: /^previous post$/,
        extract: "mode",
        operation: { kind: "entities", entity: "post", selectOnly: true }
      },
      {
        id: "X07",
        pattern: /^(?:like(?: this)?(?: post)?|give this a thumbs up|mark this as liked)$/,
        write: true,
        operation: {
          kind: "state",
          names: ["Like"],
          opposite: ["Unlike"],
          desired: true
        }
      },
      {
        id: "X08",
        pattern: /^unlike (?:this|the) post$/,
        write: true,
        operation: {
          kind: "state",
          names: ["Like"],
          opposite: ["Unlike"],
          desired: false
        }
      },
      {
        id: "X09",
        pattern: /^bookmark this post$/,
        write: true,
        operation: {
          kind: "state",
          names: ["Bookmark"],
          opposite: ["Remove Bookmark"],
          desired: true
        }
      },
      {
        id: "X10",
        pattern: /^remove this bookmark$/,
        write: true,
        operation: {
          kind: "state",
          names: ["Bookmark"],
          opposite: ["Remove Bookmark"],
          desired: false
        }
      },
      {
        id: "X11",
        pattern: /^show my bookmarks$/,
        operation: { kind: "route", path: "/i/bookmarks" }
      },
      {
        id: "X12",
        pattern: /^back to the feed$/,
        operation: { kind: "route", path: "/home" }
      },
      {
        id: "X13",
        pattern: /^reply to this post$/,
        operation: { kind: "control", names: ["Reply"], verify: "expanded" }
      },
      {
        id: "X14",
        pattern: /^write (?:the|this) reply$/,
        operation: {
          kind: "field",
          names: ["Post text", "Reply text"],
          scope: '[role="dialog"]'
        }
      },
      {
        id: "X15",
        pattern: /^post (?:this|the) reply$/,
        write: true,
        operation: {
          kind: "submit",
          names: ["Reply"],
          scope: '[role="dialog"]',
          created: 'article[data-testid="tweet"]'
        }
      },
      {
        id: "X16",
        pattern: /^discard (?:this|the) reply$/,
        write: true,
        operation: { kind: "clear-draft", scope: '[role="dialog"]' }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/youtube.ts
  var youtube = {
    site: "youtube",
    scope: "#movie_player, main, ytd-app",
    current: "ytd-watch-metadata h1, h1.ytd-video-primary-info-renderer",
    currentKind: "video",
    entities: {
      video: "ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer"
    },
    actions: [
      {
        id: "YT01",
        pattern: /^search(?: youtube)?(?: for)? (.+)$/,
        extract: "query",
        operation: {
          kind: "search",
          url: "https://www.youtube.com/results?search_query={query}"
        }
      },
      {
        id: "YT02",
        pattern: /^(?:list|show)(?: the)? videos? on screen$/,
        operation: { kind: "entities", entity: "video" }
      },
      {
        id: "YT03",
        pattern: /^(?:open|play) (?:the )?(?:(\w+) video|video (?:number )?(\w+))(?:(?: in)? (?:a )?new tab)?$/,
        extract: "ordinal",
        operation: { kind: "entities", entity: "video" }
      },
      {
        id: "YT04",
        pattern: /^(?:open|play)(?: the)? video (?:titled|called) (.+)$/,
        extract: "query",
        operation: { kind: "entities", entity: "video" }
      },
      {
        id: "YT05",
        pattern: /^(?:pause(?: the video| youtube)?|hold the video)$/,
        operation: { kind: "media", command: "pause" }
      },
      {
        id: "YT11",
        pattern: /^(?:resume(?: the video)?|play(?: the video| youtube)?)$/,
        operation: { kind: "media", command: "play" }
      },
      {
        id: "YT06",
        pattern: /^(?:(?:skip|seek|go)(?: the)? )?(?:forward|back|rewind)(?: by)? (.+?)(?: seconds?)?$/,
        extract: "number",
        operation: { kind: "media", command: "seek" }
      },
      {
        id: "YT07",
        pattern: /^set(?: player)? volume to (.+?)(?: percent|%)$/,
        extract: "number",
        operation: { kind: "media", command: "volume" }
      },
      {
        id: "YT12",
        pattern: /^(mute(?: the)? video|unmute(?: the)? video|mute youtube|unmute youtube)$/,
        extract: "mode",
        operation: { kind: "media", command: "mute" }
      },
      {
        id: "YT08",
        pattern: /^(?:turn|switch) captions? (on|off)$/,
        extract: "mode",
        operation: {
          kind: "state",
          names: ["Turn on captions", "Subtitles/closed captions"],
          opposite: ["Turn off captions", "Subtitles are on"],
          desired: true
        }
      },
      {
        id: "YT09",
        pattern: /^(?:set playback speed to|play at) (.+)$/,
        extract: "number",
        operation: { kind: "media", command: "speed" }
      },
      {
        id: "YT10",
        pattern: /^(?:what video is playing|what am i watching)\??$/,
        operation: { kind: "info" }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/chatgpt.ts
  var chatgpt = {
    site: "chatgpt",
    scope: "main",
    current: 'main [data-message-author-role="assistant"]',
    currentKind: "message",
    entities: {
      chat: 'nav a[href^="/c/"], aside a[href^="/c/"]'
    },
    actions: [
      {
        id: "CH01",
        pattern: /^(?:start|create|begin)(?: a)? new chat$/,
        operation: {
          kind: "control",
          names: ["New chat", "New chat, \u2318\u21E7O"],
          verify: "destination"
        }
      },
      {
        id: "CH02",
        // "ChatGPT" is often split or mistranscribed by speech recognition.
        // Prefer the easy-to-say "Ask AI …" phrase, while keeping the old forms.
        pattern: /^(?:(?:word|would) )?(?:i want to )?ask (?:(?:chat ?gpt)|(?:the )?ai|this assistant) (.+)$/,
        extract: "query",
        write: true,
        operation: {
          kind: "prompt",
          editor: '#mobile-composer-prompt, #prompt-textarea, textarea[placeholder="Ask ChatGPT"], [contenteditable="true"][data-placeholder], textarea[placeholder*="Message"]',
          submitNames: ["Send prompt", "Send message", "Send"],
          responseSelector: 'main [data-message-author-role="assistant"]'
        }
      },
      {
        id: "CH03",
        pattern: /^summarize (?:this|the current) (?:conversation|chat)$/,
        write: true,
        operation: {
          kind: "prompt",
          editor: '#mobile-composer-prompt, #prompt-textarea, textarea[placeholder="Ask ChatGPT"], [contenteditable="true"][data-placeholder], textarea[placeholder*="Message"]',
          submitNames: ["Send prompt", "Send message", "Send"],
          responseSelector: 'main [data-message-author-role="assistant"]'
        }
      },
      {
        id: "CH04",
        pattern: /^(?:stop generating|stop the response|stop ChatGPT)$/,
        operation: {
          kind: "control",
          names: ["Stop generating", "Stop streaming"],
          verify: "closed"
        }
      },
      {
        id: "CH05",
        pattern: /^(?:regenerate|regenerate the response|try again)$/,
        operation: {
          kind: "control",
          names: ["Regenerate", "Regenerate response"],
          verify: "entity-change"
        }
      },
      {
        id: "CH06",
        pattern: /^read (?:the )?(?:last|latest) response$/,
        operation: { kind: "info" }
      },
      {
        id: "CH07",
        pattern: /^(?:list conversations|open conversation (.+))$/,
        extract: "query",
        operation: { kind: "entities", entity: "chat" }
      }
    ]
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/registry.ts
  var adapters = {
    whatsapp,
    gmail,
    meet,
    linkedin,
    irctc,
    maps,
    wikipedia,
    github,
    reddit,
    amazon,
    spotify,
    netflix,
    youtube,
    chatgpt,
    x
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/context.ts
  var SiteContext = class {
    constructor(url = () => location.href) {
      this.url = url;
      if (typeof document === "undefined" || typeof window === "undefined")
        return;
      if (document.documentElement && typeof MutationObserver !== "undefined") {
        const observer = this.observer = new MutationObserver(this.markDirty);
        observer.observe(document.documentElement, {
          childList: true,
          subtree: true,
          characterData: true,
          attributes: true,
          attributeFilter: [
            "aria-label",
            "aria-hidden",
            "aria-pressed",
            "aria-selected",
            "aria-expanded",
            "href",
            "title",
            "role",
            "contenteditable",
            "placeholder",
            "disabled",
            "class",
            "style",
            "data-testid",
            "data-id",
            "data-chat-id",
            "data-asin",
            "data-job-id",
            "data-train-number",
            "data-meeting-title"
          ]
        });
      }
      document.addEventListener("input", this.markDirty, true);
      document.addEventListener("change", this.markDirty, true);
      window.addEventListener("scroll", this.markDirty, true);
      window.addEventListener("resize", this.markDirty, true);
    }
    url;
    documentId = crypto.randomUUID();
    revision = 0;
    signature = "";
    ids = /* @__PURE__ */ new WeakMap();
    nodes = /* @__PURE__ */ new Map();
    counter = 0;
    dirty = true;
    observer = null;
    lastInspectedUrl = "";
    cachedSnapshot = null;
    markDirty = () => {
      this.dirty = true;
    };
    node(id) {
      const e = this.nodes.get(id);
      return e?.isConnected && visible(e) ? e : void 0;
    }
    invalidate() {
      this.revision++;
      this.signature = "";
      this.dirty = true;
    }
    inspect() {
      if (this.observer?.takeRecords().length) this.dirty = true;
      const url = this.url(), site = siteForUrl(url);
      if (!this.dirty && this.lastInspectedUrl === url)
        return this.cachedSnapshot;
      if (!site) {
        this.nodes.clear();
        this.lastInspectedUrl = url;
        this.cachedSnapshot = null;
        this.dirty = false;
        return null;
      }
      const adapter = adapters[site], entities = [];
      this.nodes.clear();
      const inViewport = (node) => {
        const rect = node.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.right > 0 && rect.top < window.innerHeight && rect.left < window.innerWidth;
      };
      const visualOrder = (nodes) => nodes.filter(inViewport).sort((a, b) => {
        const ar = a.getBoundingClientRect();
        const br = b.getBoundingClientRect();
        return Math.abs(ar.top - br.top) > 24 ? ar.top - br.top : ar.left - br.left;
      });
      const make = (node, kind) => {
        const link = node instanceof HTMLAnchorElement ? node : (kind === "video" ? node.querySelector('a[href*="/watch"]') : null) || node.querySelector(
          'a[href*="/status/"],a[href*="/comments/"],a[href*="/track/"]'
        ) || node.querySelector("a[href]");
        const href = ["section", "reference"].includes(kind) && node.id ? new URL("#" + node.id, url).href : link ? new URL(link.getAttribute("href"), url).href : void 0;
        const chatIds = site === "whatsapp" && kind === "chat" && !node.closest("#pane-side") ? [
          ...new Set(
            [
              elements("#main[data-chat-id],#main [data-chat-id]").map(
                (e) => e.getAttribute("data-chat-id") || ""
              ),
              elements("#main [data-id]").map(
                (e) => /^(?:true|false)_([^_]+)_[^]+$/.exec(
                  e.getAttribute("data-id") || ""
                )?.[1] || ""
              )
            ].flat().filter(Boolean)
          )
        ] : [];
        const identity = chatIds.length === 1 && !node.closest("#pane-side") ? chatIds[0] : void 0;
        const title = (site === "youtube" && kind === "video" ? node.querySelector(
          "#video-title, a#video-title, h3"
        )?.getAttribute("title") || node.querySelector(
          "#video-title, a#video-title, h3"
        )?.textContent : void 0) || node.getAttribute("post-title") || (site === "whatsapp" && kind === "chat" && node.closest("#pane-side") ? node.querySelector(
          '[data-testid="cell-frame-title"] [title],span[title]'
        )?.getAttribute("title") : void 0) || (site === "gmail" && kind === "thread" ? node.querySelector(".bog")?.textContent : void 0) || node.querySelector(
          'h1,h2,h3,[data-testid="tweetText"],[data-testid="track-name"]'
        )?.textContent || label(node);
        const key = JSON.stringify([
          kind,
          href,
          title,
          node.getAttribute("data-asin"),
          node.getAttribute("post-id"),
          identity,
          node.getAttribute("data-id"),
          node.getAttribute("data-job-id"),
          node.getAttribute("data-train-number"),
          node.getAttribute("data-meeting-title")
        ]);
        let stored = this.ids.get(node);
        if (!stored || stored.key !== key) {
          stored = { id: `${site}:${++this.counter}`, key };
          this.ids.set(node, stored);
        }
        const id = stored.id;
        this.nodes.set(id, node);
        return {
          id,
          kind,
          label: title.trim().slice(0, 180),
          ...identity ? { identity } : {},
          detail: ((site === "youtube" && kind === "video" ? node.querySelector(
            "#channel-name a, ytd-channel-name a, .ytd-channel-name a"
          )?.textContent || "" : label(node)) + (href && ["file", "folder", "repository"].includes(kind) ? " " + new URL(href).pathname : "")).slice(0, 240),
          ...href ? { href } : {}
        };
      };
      for (const [kind, selector] of Object.entries(adapter.entities)) {
        const seen = /* @__PURE__ */ new Set();
        let kindCount = 0;
        const found = elements(selector);
        const ordered = site === "youtube" && kind === "video" ? visualOrder(found) : found;
        for (const node of ordered) {
          if (site === "wikipedia" && node.closest('.navbox,.sidebar,.vertical-navbox,[role="navigation"]'))
            continue;
          const entity = make(node, kind);
          const key = entity.href || entity.id;
          if (entity.label && !seen.has(key)) {
            seen.add(key);
            entities.push(entity);
            kindCount++;
          }
          if (kindCount >= 40) break;
        }
      }
      const currentNodes = elements(adapter.current);
      const currentNode = site === "chatgpt" ? currentNodes.at(-1) : currentNodes.length === 1 ? currentNodes[0] : void 0;
      let current = currentNode ? make(
        currentNode,
        adapter.currentKind || (site === "spotify" ? "track" : site === "github" ? "repository" : site === "amazon" ? "product" : site === "wikipedia" ? "article" : site === "netflix" ? "title" : "post")
      ) : null;
      if (!current && (site === "x" && /\/status\//.test(new URL(url).pathname) || site === "reddit" && /\/comments\//.test(new URL(url).pathname))) {
        const posts = entities.filter((e) => e.kind === "post");
        if (posts.length === 1) current = posts[0];
      }
      const drafts = elements(
        'input:not([type="password"]),textarea,[contenteditable="true"]'
      ).map(
        (e) => e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement ? e.value : e.textContent
      );
      const controlSignature = elements(
        "button,[aria-pressed],[aria-selected],select"
      ).map((e) => [
        label(e),
        e.getAttribute("aria-pressed"),
        e.getAttribute("aria-selected"),
        e instanceof HTMLSelectElement ? e.value : ""
      ]);
      const signature = JSON.stringify([
        url,
        entities,
        current,
        controlSignature,
        drafts,
        elements("[email],[data-email]").map((e) => [
          e.getAttribute("email"),
          e.getAttribute("data-email")
        ])
      ]);
      if (this.signature && signature !== this.signature) this.revision++;
      this.signature = signature;
      const snapshot = {
        site,
        url,
        documentId: this.documentId,
        revision: this.revision,
        pageType: new URL(url).pathname,
        ...site === "meet" ? { meetingActive: controls(["Leave call"]).length === 1 } : {},
        entities,
        current,
        capabilities: catalogue.filter((a) => a.site === site).map((a) => {
          const spec = adapter.actions.find((s) => s.id === a.id);
          let state = !spec || spec.operation.kind === "unsupported" ? "not-implemented" : spec.write && spec.operation.kind !== "prompt" ? "needs-confirmation" : "available";
          if (spec && spec.operation.kind !== "unsupported") {
            const op = spec.operation;
            if (op.kind === "group-b") {
              const roots = elements(op.scope || adapter.scope);
              if (!roots.length) state = "unavailable";
              if (op.scope && roots.length > 1) state = "needs-choice";
              const names = {
                ME01: ["Join now", "Ask to join"],
                ME02: [
                  "Turn off microphone",
                  "Turn on microphone",
                  "Turn off microphone (ctrl + d)",
                  "Turn on microphone (ctrl + d)"
                ],
                ME03: [
                  "Turn off camera",
                  "Turn on camera",
                  "Turn off camera (ctrl + e)",
                  "Turn on camera (ctrl + e)"
                ],
                ME04: ["Turn off captions", "Turn on captions"],
                ME05: ["Raise hand", "Lower hand"],
                ME06: ["Show everyone", "People", "Chat with everyone", "Chat"],
                ME10: ["Leave call"],
                IR05: ["Search", "Search trains"],
                IR08: ["Swap", "Swap stations"],
                MAP07: ["Zoom in", "Zoom out"]
              };
              if (names[spec.id] && !controls(names[spec.id]).length)
                state = "unavailable";
              if (["WA03", "WA04", "WA05", "WA07", "MAP03", "LI05"].includes(
                spec.id
              ) && !current)
                state = "unavailable";
            }
            if (op.kind === "entities" && !entities.some((e) => e.kind === op.entity))
              state = "unavailable";
            if (op.kind === "state") {
              const roots = op.scope ? elements(op.scope) : [document];
              const matches = roots.flatMap(
                (root) => controls([...op.names, ...op.opposite], root)
              );
              state = matches.length === 0 ? "unavailable" : matches.length > 1 || !current ? "needs-choice" : "needs-confirmation";
            }
            if (op.kind === "media" && !elements("audio,video").length && !controls(["Play", "Pause", "Next", "Previous"]).length)
              state = "unavailable";
            if (op.kind === "select" && !elements(op.selector).length)
              state = "unavailable";
            if (op.kind === "price" && !elements(op.upper).length)
              state = "unavailable";
            if (op.kind === "field" && !elements('input,textarea,[contenteditable="true"]').length)
              state = "unavailable";
            if (op.kind === "control" && op.names.length && !controls(op.names).length)
              state = "unavailable";
          }
          return { id: a.id, state, description: a.description };
        })
      };
      this.lastInspectedUrl = url;
      this.cachedSnapshot = snapshot;
      this.dirty = false;
      return snapshot;
    }
    adapter() {
      const site = siteForUrl(this.url());
      return site ? adapters[site] : null;
    }
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/core/parser.ts
  function normalizeSpeech(text) {
    return text.normalize("NFKC").toLowerCase().trim().replace(/[.!?,;:]+$/g, "").trim().replace(/\s+/g, " ");
  }
  var numberNames = [
    "one",
    "two",
    "three",
    "four",
    "five",
    "six",
    "seven",
    "eight",
    "nine",
    "ten"
  ];
  var tabNumberNames = [
    ...numberNames,
    "eleven",
    "twelve",
    "thirteen",
    "fourteen",
    "fifteen",
    "sixteen",
    "seventeen",
    "eighteen",
    "nineteen",
    "twenty"
  ];

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/language.ts
  var small = {
    zero: 0,
    one: 1,
    two: 2,
    three: 3,
    four: 4,
    five: 5,
    six: 6,
    seven: 7,
    eight: 8,
    nine: 9,
    ten: 10,
    eleven: 11,
    twelve: 12,
    thirteen: 13,
    fourteen: 14,
    fifteen: 15,
    sixteen: 16,
    seventeen: 17,
    eighteen: 18,
    nineteen: 19,
    twenty: 20,
    thirty: 30,
    forty: 40,
    fifty: 50,
    sixty: 60,
    seventy: 70,
    eighty: 80,
    ninety: 90,
    first: 1,
    second: 2,
    third: 3,
    fourth: 4,
    fifth: 5
  };
  function numberSlot(value2) {
    const text = normalizeSpeech(value2).replace(/-/g, " ");
    if (/^\d{1,7}(?:\.\d{1,2})?$/.test(text)) return Number(text);
    const decimal = /^(.+) point (zero|one|two|three|four|five|six|seven|eight|nine)$/.exec(text);
    if (decimal) {
      const whole = numberSlot(decimal[1]);
      const fraction = small[decimal[2]];
      return whole === null ? null : whole + fraction / 10;
    }
    let total = 0, part = 0;
    for (const word of text.split(" ")) {
      if (word === "and") continue;
      if (Object.hasOwn(small, word)) part += small[word];
      else if (word === "hundred" && part) part *= 100;
      else if (word === "thousand" && part) {
        total += part * 1e3;
        part = 0;
      } else return null;
    }
    return total + part;
  }
  function isCancellation(text) {
    return /^(?:cancel(?: that request| the search| it)?|never mind|nevermind|don't do that|do not do that|leave it as it is|stop that action|no|isko mat bhejo)$/.test(
      normalizeSpeech(text)
    );
  }
  function validateSiteRequest(value2) {
    if (!value2 || typeof value2 !== "object") return null;
    const v = value2;
    if (v.type !== "site-action" || !Object.hasOwn(adapters, v.site) || !adapters[v.site].actions.some((a) => a.id === v.action) || v.url !== void 0 && (typeof v.url !== "string" || v.url.length > 3e3 || siteForUrl(v.url) !== v.site) || typeof v.documentId !== "string" || v.documentId.length > 100 || typeof v.requestId !== "string" || v.requestId.length > 100 || !Number.isSafeInteger(v.revision) || v.revision < 0 || !v.args || typeof v.args !== "object")
      return null;
    const { query, value: n, end, index, mode } = v.args;
    if (query !== void 0 && (typeof query !== "string" || !query.trim() || query.length > 300) || mode !== void 0 && (typeof mode !== "string" || mode.length > 100) || [n, end, index].some(
      (x2) => x2 !== void 0 && (typeof x2 !== "number" || !Number.isFinite(x2) || Math.abs(x2) > 1e6)
    ) || index !== void 0 && (!Number.isInteger(index) || index < 1 || index > 100))
      return null;
    return {
      type: "site-action",
      site: v.site,
      ...typeof v.url === "string" ? { url: v.url } : {},
      action: v.action,
      args: { query, value: n, end, index, mode },
      revision: v.revision,
      documentId: v.documentId,
      requestId: v.requestId,
      ...typeof v.entityId === "string" && v.entityId.length <= 100 ? { entityId: v.entityId } : {}
    };
  }

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/sites/executor.ts
  var safelyDescribeDestination = (snapshot) => snapshot.site + " " + new URL(snapshot.url).pathname.slice(0, 180);
  var result = (state, feedback, rest = {}) => ({ state, feedback, ...rest });
  var SiteExecutor = class {
    constructor(url, now = () => Date.now(), publicationAllowed = () => false, recipientAllowed = () => false) {
      this.now = now;
      this.publicationAllowed = publicationAllowed;
      this.recipientAllowed = recipientAllowed;
      this.context = new SiteContext(url);
    }
    now;
    publicationAllowed;
    recipientAllowed;
    context;
    selected = null;
    selectedRevision = -1;
    pending = null;
    choices = null;
    active = new AbortController();
    uncertain = /* @__PURE__ */ new Set();
    handled = /* @__PURE__ */ new Map();
    citationOrigin = null;
    findQuery = "";
    matches = [];
    matchIndex = -1;
    sectionIndex = -1;
    lastFeedback = "";
    cancel() {
      this.active.abort();
      this.active = new AbortController();
      this.pending = null;
      this.choices = null;
    }
    invalidate() {
      this.cancel();
      this.context.invalidate();
      this.selected = null;
      this.selectedRevision = -1;
    }
    fresh(request) {
      const s = this.context.inspect();
      return !!s && s.site === request.site && s.documentId === request.documentId && s.revision === request.revision;
    }
    snapshot() {
      let snapshot = this.context.inspect();
      if (snapshot && !this.publicationAllowed())
        snapshot = {
          ...snapshot,
          capabilities: snapshot.capabilities.map(
            (c) => this.context.adapter()?.actions.find((a) => a.id === c.id)?.operation.kind === "submit" ? { ...c, state: "not-implemented" } : c
          )
        };
      if (snapshot) {
        const baseSnapshot = snapshot;
        snapshot = {
          ...baseSnapshot,
          capabilities: baseSnapshot.capabilities.map((capability) => {
            if (!groupBSends.has(capability.id)) return capability;
            const spec = this.context.adapter().actions.find((a) => a.id === capability.id);
            const roots = spec.operation.kind === "group-b" && spec.operation.scope ? elements(spec.operation.scope) : [document];
            if (roots.length !== 1)
              return {
                ...capability,
                state: roots.length ? "needs-choice" : "unavailable"
              };
            const prepared = prepareGroupB(
              spec,
              {
                type: "site-action",
                site: baseSnapshot.site,
                url: baseSnapshot.url,
                action: spec.id,
                args: {},
                revision: baseSnapshot.revision,
                documentId: baseSnapshot.documentId,
                requestId: "capability"
              },
              baseSnapshot,
              roots[0],
              this.recipientAllowed
            );
            return {
              ...capability,
              state: prepared.result?.state || "needs-confirmation"
            };
          })
        };
      }
      return snapshot && this.selected && this.selectedRevision === snapshot.revision ? { ...snapshot, selected: this.selected } : snapshot;
    }
    identity(request, snapshot) {
      if (request.entityId)
        return snapshot.entities.find((e) => e.id === request.entityId) || (snapshot.current?.id === request.entityId ? snapshot.current : null);
      return this.selectedRevision === snapshot.revision ? this.selected : snapshot.current;
    }
    scope(spec, snapshot, request) {
      const op = spec.operation;
      if (spec.id === "R07" || op.kind === "group-b" && !op.scope)
        return document;
      const selector = "scope" in op ? op.scope : void 0;
      if (selector) {
        let roots = elements(selector);
        const selected = this.identity(request, snapshot);
        const selectedNode = selected && this.context.node(selected.id);
        if (selectedNode && roots.length > 1) {
          const bound = roots.filter(
            (root) => root === selectedNode || root.contains(selectedNode)
          );
          if (bound.length === 1) roots = bound;
        }
        if (roots.length > 1 && op.kind === "field") {
          const names = request.args.mode?.includes("title") ? ["Title", "Add a title"] : request.args.mode?.match(/body|description/) ? ["Body", "Description", "Add a description"] : op.names;
          roots = roots.filter(
            (root) => elements('input,textarea,[contenteditable="true"]', root).some(
              (e) => editable(e) && names.some((n) => norm(label(e)) === norm(n))
            )
          );
        }
        if (roots.length > 1 && op.kind === "submit")
          roots = roots.filter((root) => controls(op.names, root).length === 1);
        if (roots.length > 1)
          roots = roots.filter(
            (root) => !roots.some((other) => other !== root && root.contains(other))
          );
        return roots.length === 1 ? roots[0] : null;
      }
      if (spec.write && op.kind !== "prompt" || ["R09", "R10", "R15", "R20", "X13", "R24", "R25"].includes(spec.id)) {
        const entity = this.identity(request, snapshot);
        if (!entity) return null;
        const node = this.context.node(entity.id);
        if (!node) return null;
        return node.closest(
          'shreddit-post,shreddit-comment,article,[data-testid="post-container"],[data-testid="comment"],.previewModal,[data-testid="now-playing-widget"]'
        ) || node;
      }
      return document;
    }
    signature(node) {
      return node ? JSON.stringify([
        label(node),
        elements("[email],[data-email]").map((e) => [
          e.getAttribute("email"),
          e.getAttribute("data-email")
        ]),
        node.getAttribute("aria-pressed"),
        node.getAttribute("aria-expanded"),
        node.closest("form")?.textContent,
        [
          ...(node.closest("form") || node.parentElement || node).querySelectorAll('input,textarea,[contenteditable="true"]')
        ].map(
          (e) => e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement ? e.value : e.textContent
        )
      ]) : "";
    }
    remember(value2) {
      this.lastFeedback = value2.feedback;
      return value2;
    }
    guardActivation(node) {
      const snapshot = this.context.inspect(), adapter = this.context.adapter();
      if (!snapshot || !adapter) return null;
      const name = norm(label(node));
      if (snapshot.site === "irctc" && node.closest("app-passenger-input,app-review-booking,app-payment"))
        return "blocked";
      for (const spec of adapter.actions) {
        const op = spec.operation;
        if (spec.write && op.kind === "group-b") {
          if ((spec.guardNames || []).some((n) => norm(n) === name))
            return "blocked";
        }
        if (!spec.write || !("names" in op)) continue;
        const names = [...op.names, ...op.kind === "state" ? op.opposite : []];
        if (!names.some((n) => norm(n) === name)) continue;
        const entity = snapshot.entities.find(
          (e) => this.context.node(e.id)?.contains(node)
        );
        if (entity) {
          this.selected = entity;
          this.selectedRevision = snapshot.revision;
        }
        return {
          type: "site-action",
          site: snapshot.site,
          url: snapshot.url,
          action: spec.id,
          args: {},
          documentId: snapshot.documentId,
          revision: snapshot.revision,
          requestId: crypto.randomUUID(),
          ...entity ? { entityId: entity.id } : {}
        };
      }
      if (/\b(like|unlike|upvote|downvote|star|unstar|save|unsave|bookmark|repost|retweet|follow|unfollow|send|post|publish|submit|comment|reply|delete|remove|clear|discard|cart|buy|book|booking|pay|payment|apply|checkout|order|merge|subscribe)\b/.test(
        name
      ) && !editable(node) && !(node.matches("a[href]") && /^(?:cart|my cart|bookmarks)$/.test(name)))
        return "blocked";
      return null;
    }
    async dialogue(text) {
      const n = norm(text).replace(/[.!?,]+$/, "");
      if (isCancellation(n)) {
        this.cancel();
        return this.remember(
          result(
            "available",
            "Cancelled the pending request. Completed actions are unchanged."
          )
        );
      }
      if (n === "say that again")
        return result(
          "available",
          this.lastFeedback || "There is no previous feedback."
        );
      if (/^(what can i (?:do|say) (?:here|on this page)|help|explain the choices)$/.test(
        n
      )) {
        const s = this.snapshot();
        if (!s) return null;
        const actions = s.capabilities.filter(
          (a) => a.state !== "not-implemented"
        );
        return this.remember(
          result(
            "available",
            `${s.site}. Available commands depend on visible controls. ${actions.slice(0, 5).map((a) => catalogue.find((c) => c.id === a.id)?.examples[0]).join(". ")}. Say list results to hear choices.`
          )
        );
      }
      if (n === "which item are you talking about")
        return result(
          "available",
          this.pending || this.choices ? this.pending?.preview || this.choiceFeedback(this.choices) : this.selected ? `Selected ${this.selected.label}.` : "No voice target is selected."
        );
      if (n === "more choices" && this.choices) {
        this.choices.offset += 5;
        return result("needs-choice", this.choiceFeedback(this.choices), {
          choices: this.choices.entities.slice(
            this.choices.offset,
            this.choices.offset + 5
          )
        });
      }
      if (/^(?:yes|confirm(?: .+)?)$/.test(n)) {
        if (!this.pending) return null;
        const pending = this.pending;
        this.pending = null;
        if (this.now() > pending.expires || !this.fresh(pending.request) || pending.node && (!visible(pending.node) || this.signature(pending.node) !== pending.signature))
          return this.remember(
            result(
              "unavailable",
              "The confirmation expired or its target changed. Nothing was activated."
            )
          );
        return this.run(pending.request, true);
      }
      if (this.choices) {
        const choices = this.choices;
        const indexText = n.replace(/^actually[, ]*/, "").replace(/^(?:choose|select|open)(?: number)? /, "").replace(/^the /, "").replace(/ one(?: please)?$/, "").replace(/ please$/, "");
        let index = numberSlot(indexText);
        if (index === null) {
          const query = n.replace(/^(?:choose|select)(?: the one)?(?: by)? /, "");
          const matches = choices.entities.filter(
            (e) => norm(e.label).includes(query) || norm(e.detail).includes(query)
          );
          if (matches.length === 1)
            index = choices.entities.indexOf(matches[0]) + 1;
        }
        if (index !== null) {
          this.choices = null;
          if (this.now() > choices.expires || !this.fresh(choices.request))
            return result(
              "unavailable",
              "Those choices changed. Ask for the results again."
            );
          const entity = choices.entities[index - 1];
          if (!entity)
            return result(
              "unavailable",
              "That numbered choice is not available."
            );
          this.selected = entity;
          this.selectedRevision = choices.request.revision;
          return this.run(
            {
              ...choices.request,
              entityId: entity.id,
              args: {
                ...choices.request.args,
                index: void 0,
                query: void 0,
                mode: choices.request.args.mode === "list" ? void 0 : choices.request.args.mode
              }
            },
            false
          );
        }
      }
      if (this.pending) this.pending = null;
      if (/^(?:list results|list comments|list chats|list conversations|list videos(?: on screen)?|show videos on screen|list messages|list drafts|list jobs|list trains|list places|list routes)$/.test(
        n
      )) {
        const s = this.context.inspect();
        if (!s) return null;
        const spec = this.context.adapter().actions.find(
          (a) => a.operation.kind === "entities" && (n === "list results" || a.operation.entity === {
            "list comments": "comment",
            "list chats": "chat",
            "list conversations": "chat",
            "list videos": "video",
            "list videos on screen": "video",
            "show videos on screen": "video",
            "list messages": "message",
            "list drafts": "draft",
            "list jobs": "job",
            "list trains": "train",
            "list places": "place",
            "list routes": "route"
          }[n])
        );
        if (!spec)
          return result("unavailable", "No result list is available here.");
        return this.run({
          type: "site-action",
          site: s.site,
          url: s.url,
          action: spec.id,
          documentId: s.documentId,
          revision: s.revision,
          requestId: crypto.randomUUID(),
          args: { mode: "list" }
        });
      }
      return null;
    }
    choiceFeedback(choices) {
      const batch = choices.entities.slice(choices.offset, choices.offset + 5);
      return batch.length ? `Which item? ${batch.map((e, i) => `${choices.offset + i + 1}. ${e.label}${e.detail !== e.label ? ", " + e.detail : ""}`).join(". ")}. Say choose a number, more choices, or cancel.` : "No more choices. Say a previously announced number or cancel.";
    }
    async run(raw, confirmed = false) {
      let request = validateSiteRequest(raw);
      if (!request)
        return result("unavailable", "Invalid or unsupported site action.");
      const previous = this.handled.get(request.requestId);
      if (previous) return previous;
      const spec = this.context.adapter()?.actions.find((a) => a.id === request.action);
      if (!spec)
        return result("unavailable", "Invalid or unsupported site action.");
      if (!this.fresh(request)) {
        const current = this.context.inspect();
        const canRebaseSpotifyRead = request.site === "spotify" && !!request.url && !request.entityId && request.args.index === void 0 && !spec?.write && current?.site === request.site && current.documentId === request.documentId && current.url === request.url;
        if (canRebaseSpotifyRead)
          request = { ...request, revision: current.revision };
        else {
          this.cancel();
          return this.remember(
            result(
              "unavailable",
              "The page or target changed. Repeat your request."
            )
          );
        }
      }
      const snapshot = this.snapshot(), op = spec.operation;
      const boundEntity = this.identity(request, snapshot);
      if (spec.write && op.kind === "state" && snapshot.site === "github" && boundEntity?.kind === "comment")
        return result(
          "not-implemented",
          "Comment reactions are not implemented. Repository stars cannot substitute for them."
        );
      if (op.kind === "submit" && !this.publicationAllowed())
        return result(
          "not-implemented",
          "Publishing is disabled outside explicitly configured owned test spaces. No content was posted."
        );
      if (op.kind === "unsupported")
        return this.remember(result("not-implemented", op.reason));
      if (this.pending && this.pending.request.requestId !== request.requestId)
        this.pending = null;
      if (["R09", "R20"].includes(spec.id) && request.args.value !== void 0) {
        const choices = this.choices;
        const chosen = choices?.entities[request.args.value - 1];
        if (!choices || this.now() > choices.expires || !this.fresh(choices.request) || chosen?.kind !== "comment") {
          this.choices = null;
          return result(
            "needs-choice",
            "Say list comments first, then refer to an announced comment number."
          );
        }
        request.entityId = chosen.id;
        this.choices = null;
      }
      if (this.choices && this.choices.request.requestId !== request.requestId) {
        const ordinal = request.args.index ?? (request.args.query ? numberSlot(request.args.query.replace(/^the /, "")) : null);
        if (op.kind === "entities" && ordinal !== null && ordinal !== void 0 && this.now() <= this.choices.expires && this.fresh(this.choices.request)) {
          const chosen = this.choices.entities[ordinal - 1];
          if (!chosen || chosen.kind !== op.entity)
            return result(
              "unavailable",
              "That number is not in the announced list for this object type."
            );
          request.entityId = chosen.id;
          request.args = {
            ...request.args,
            index: void 0,
            query: void 0,
            mode: request.args.mode === "list" ? void 0 : request.args.mode
          };
        }
        this.choices = null;
      }
      const scope = this.scope(spec, snapshot, request);
      if (!scope)
        return this.remember(
          result(
            "needs-choice",
            "Select a specific item first. Say list results or open a named item."
          )
        );
      const signal = this.active.signal;
      const valid = () => !signal.aborted && this.context.inspect()?.documentId === request.documentId && this.context.inspect()?.url === snapshot.url;
      const args = request.args;
      let target;
      let groupPreview;
      if (op.kind === "group-b") {
        const prepared = prepareGroupB(
          spec,
          request,
          snapshot,
          scope,
          this.recipientAllowed
        );
        if (prepared.result) return this.remember(prepared.result);
        target = prepared.target;
        groupPreview = prepared.preview;
      }
      if (op.kind === "state") {
        const matches = controls([...op.names, ...op.opposite], scope);
        if (matches.length !== 1)
          return this.remember(
            result(
              "unavailable",
              matches.length ? "Several reaction controls match. Select the exact item first." : "The reaction control is unavailable. Sign-in or account access may be required."
            )
          );
        target = matches[0];
        const state = stateOf(target, op.opposite, op.names);
        const desired = args.mode === "off" || args.mode?.startsWith("unsave") ? false : args.mode === "on" ? true : op.desired;
        if (state === desired)
          return this.remember(
            result(
              "already-satisfied",
              `${snapshot.current?.label || this.selected?.label || "This item"} is already ${desired ? "saved or liked" : "not saved or liked"}.`,
              { evidence: "desired-state" }
            )
          );
        if (state === null && !op.names.some((n) => norm(n) === norm(label(target))))
          return result(
            "unavailable",
            "The current reaction state cannot be established."
          );
      }
      if (op.kind === "submit") {
        const buttons = controls(op.names, scope);
        if (buttons.length !== 1)
          return result(
            "unavailable",
            "A unique publication control is unavailable."
          );
        target = buttons[0];
        const drafts = elements(
          'input,textarea,[contenteditable="true"]',
          scope
        ).filter(editable);
        if (!drafts.length || !drafts.some(
          (e) => (e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement ? e.value : e.textContent || "").trim()
        ))
          return result("unavailable", "The scoped draft is empty.");
      }
      if (spec.write && op.kind !== "prompt" && !confirmed) {
        const identity = this.identity(request, snapshot);
        if (!identity && op.kind !== "submit" && op.kind !== "clear-draft" && op.kind !== "group-b")
          return result(
            "needs-choice",
            "Which item should change? Select a named item first."
          );
        if (["R15"].includes(spec.id) && identity?.kind !== "comment")
          return result("needs-choice", "Select a comment before voting on it.");
        const preview = `${groupPreview || catalogue.find((a) => a.id === spec.id).description}. Target: ${identity?.label || (scope instanceof HTMLElement ? label(scope) : snapshot.site)} on ${safelyDescribeDestination(snapshot)}. Say confirm within 15 seconds, or cancel.`;
        this.pending = {
          request,
          preview,
          expires: this.now() + 15e3,
          node: target,
          signature: this.signature(target)
        };
        return this.remember(result("needs-confirmation", preview));
      }
      const guardedWrite = spec.write || op.kind === "prompt";
      const mutationKey = op.kind === "prompt" ? `${spec.id}:${request.args.query || "summary"}` : `${spec.id}:${request.entityId || this.selected?.id || snapshot.current?.id}`;
      if (guardedWrite && this.uncertain.has(mutationKey))
        return result(
          "failed",
          "The previous change has an uncertain outcome. Inspect the item before trying again. It will not be repeated automatically."
        );
      if (guardedWrite) this.uncertain.add(mutationKey);
      let output;
      try {
        output = await this.execute(
          spec,
          request,
          snapshot,
          scope,
          target,
          valid
        );
      } catch (error) {
        output = result(
          "failed",
          error instanceof Error ? error.message : "The page interaction failed."
        );
      }
      if (op.kind === "prompt" && output.evidence === "prompt-not-sent")
        this.uncertain.delete(mutationKey);
      if (!valid())
        output = result(
          "failed",
          "The action was cancelled or the page changed. Its result was not verified."
        );
      if (guardedWrite && ["available", "already-satisfied"].includes(output.state))
        this.uncertain.delete(mutationKey);
      if (guardedWrite || output.state === "available") {
        this.handled.set(request.requestId, output);
        if (this.handled.size > 100)
          this.handled.delete(this.handled.keys().next().value);
      }
      const updated = this.context.inspect();
      if (output.state === "needs-choice" && output.choices?.length && updated) {
        this.choices = {
          request: { ...request, revision: updated.revision },
          entities: output.choices,
          offset: 0,
          expires: this.now() + 3e4
        };
        output.feedback = this.choiceFeedback(this.choices);
      }
      if (updated && this.selected && updated.entities.some((e) => e.id === this.selected.id))
        this.selectedRevision = updated.revision;
      return this.remember(output);
    }
    async execute(spec, request, s, scope, target, valid) {
      const op = spec.operation, a = request.args;
      const verified = async (check, message) => await until(check, valid) ? result("available", message, { evidence: "observed-postcondition" }) : result(
        "failed",
        "The control was activated, but its result could not be verified. No automatic retry."
      );
      if (op.kind === "prompt") {
        const editors = elements(op.editor, document).filter(editable);
        if (editors.length !== 1)
          return result("unavailable", "A unique ChatGPT prompt field is unavailable.", { evidence: "prompt-not-sent" });
        const editor = editors[0];
        const readEditor = () => editor instanceof HTMLInputElement || editor instanceof HTMLTextAreaElement ? editor.value : editor.textContent || "";
        if (readEditor().trim())
          return result("needs-choice", "The ChatGPT message field already has text. Clear or review it before sending another prompt.", { evidence: "prompt-not-sent" });
        const prompt = a.query || "Summarize this conversation, including its main points and any unresolved questions.";
        editor.focus();
        insertText(editor, prompt);
        if (norm(readEditor()) !== norm(prompt))
          return result("failed", "The prompt could not be placed in ChatGPT's message field. It was not sent.", { evidence: "prompt-not-sent" });
        const send = controls(op.submitNames);
        if (send.length !== 1)
          return result("unavailable", "ChatGPT has no enabled Send button. The prompt remains in the field and was not sent; check whether this page requires you to sign in.", { evidence: "prompt-not-sent" });
        const prior = elements(op.responseSelector).map((e) => e.textContent || "").join("\n");
        send[0].click();
        const sent = await until(() => {
          const response = elements(op.responseSelector).map((e) => e.textContent || "").join("\n");
          return !readEditor().trim() || controls(["Stop generating", "Stop streaming"]).length > 0 || response !== prior;
        }, valid, 1800);
        return sent ? result("available", "Sent your prompt to ChatGPT.", { evidence: "composer-cleared-or-response-started" }) : result("failed", "I could not verify that ChatGPT accepted the prompt. Check the message field before trying again; Handsfree will not resend it automatically.");
      }
      if (op.kind === "group-b")
        return executeGroupB(
          spec,
          request,
          s,
          scope,
          target,
          valid,
          this.context
        );
      if (op.kind === "search" || op.kind === "route") {
        const url = new URL(s.url), parts = url.pathname.split("/").filter(Boolean), repo = parts.slice(0, 2).join("/");
        if (s.site === "github" && (!repo || parts.length < 2) && ("path" in op ? op.path : op.url).includes("{repo}"))
          return result(
            "unavailable",
            "Open a repository before using this command."
          );
        let path = op.kind === "search" ? op.url : op.path;
        const replacements = {
          query: encodeURIComponent(a.query || ""),
          repo,
          community: parts[0] === "r" ? parts[1] || "" : "",
          value: String(a.value ?? ""),
          mode: a.mode === "pull requests" ? "pulls" : a.mode || "",
          parent: parts.length > 4 ? "/" + parts.slice(0, -1).join("/") : "/" + repo
        };
        if (path.includes("{community}") && !replacements.community)
          return result("unavailable", "Open a community first.");
        if (path.includes("{query}") && !a.query || path.includes("{value}") && (!Number.isInteger(a.value) || a.value < 1))
          return result("unavailable", "Provide a valid query or number.");
        path = path.replace(/\{(\w+)\}/g, (_, key) => replacements[key] || "");
        return result("available", "Opening the requested destination.", {
          navigate: { url: new URL(path, s.url).href, newTab: false }
        });
      }
      if (spec.id === "WA01" && a.query && !request.entityId) {
        const inputs = elements(
          '#side [contenteditable="true"][role="textbox"],#pane-side input[aria-label="Search chats"],#side input[aria-label="Search chats"],#side [aria-label="Search input textbox"],input[aria-label="Search or start a new chat"],[role="textbox"][aria-label="Search or start a new chat"]'
        );
        if (inputs.length !== 1 || !editable(inputs[0]))
          return result(
            "unavailable",
            "The chat-search field is unavailable. Only rendered chats can be selected here."
          );
        const input = inputs[0];
        input.focus();
        if (input instanceof HTMLInputElement) setInput(input, a.query);
        else {
          const range = document.createRange();
          range.selectNodeContents(input);
          getSelection()?.removeAllRanges();
          getSelection()?.addRange(range);
          insertText(input, a.query);
        }
        let signature = "", stableSince = performance.now();
        const started = stableSince;
        const settled = await until(() => {
          const chats = this.context.inspect()?.entities.filter((e) => e.kind === "chat") || [];
          const next = chats.map((e) => e.id + ":" + e.label).join("|");
          if (next !== signature) {
            signature = next;
            stableSince = performance.now();
          }
          return performance.now() - started >= 400 && performance.now() - stableSince >= 200 && !elements('#side [aria-busy="true"],#pane-side [aria-busy="true"]').length && chats.some((e) => norm(e.label).includes(norm(a.query)));
        }, valid);
        if (!settled)
          return result(
            "unavailable",
            "The chat search did not settle. No chat was opened."
          );
        const refreshed = this.context.inspect();
        if (!valid() || !refreshed)
          return result("unavailable", "The chat-search request was cancelled.");
        s = refreshed;
        request = { ...request, revision: refreshed.revision };
      }
      if (spec.id === "G08") {
        const query = a.query;
        if (!query) return result("unavailable", "Name a file to find.");
        const available = s.entities.filter(
          (e) => e.kind === "file" && norm(e.label).includes(norm(query))
        );
        if (!available.length) {
          const openers = controls(["Go to file"]);
          if (openers.length !== 1)
            return result(
              "unavailable",
              "The repository file finder is unavailable. Only rendered files can be selected here."
            );
          openers[0].click();
          await until(
            () => elements(
              '[role="dialog"] input,input[aria-label="Go to file"]'
            ).filter(editable).length === 1,
            valid
          );
          const fields = elements(
            '[role="dialog"] input,input[aria-label="Go to file"]'
          ).filter(editable);
          if (fields.length !== 1)
            return result(
              "unavailable",
              "The file finder input is unavailable or ambiguous."
            );
          setInput(fields[0], query);
          await until(
            () => !!this.context.inspect()?.entities.some(
              (e) => e.kind === "file" && norm(e.label).includes(norm(query))
            ),
            valid
          );
          const refreshed = this.context.inspect();
          if (!valid() || !refreshed)
            return result(
              "unavailable",
              "The repository changed while finding the file."
            );
          s = refreshed;
          request = { ...request, revision: refreshed.revision };
        }
      }
      if (op.kind === "entities") {
        let candidates = s.entities.filter((e) => e.kind === op.entity);
        if (a.mode === "list") {
          if (!candidates.length)
            return result(
              "unavailable",
              "No visible results are available here."
            );
          this.choices = {
            request,
            entities: candidates,
            offset: 0,
            expires: this.now() + 3e4
          };
          return result("needs-choice", this.choiceFeedback(this.choices), {
            choices: candidates.slice(0, 5)
          });
        }
        let chosen = request.entityId ? candidates.find((e) => e.id === request.entityId) : void 0;
        if (!chosen && a.index !== void 0) {
          if (request.site === "youtube" && spec.id === "YT03") {
            chosen = candidates[a.index - 1];
            if (!chosen) return result("unavailable", "That video number is not visible on this screen.");
          } else {
            if (!this.choices || !this.fresh(this.choices.request))
              return result(
                "needs-choice",
                "Ask to list results first, then choose a number."
              );
            chosen = this.choices.entities[a.index - 1];
          }
        }
        if (!chosen && a.query) {
          const q = norm(a.query).replace(/^the /, "");
          const ordinal = numberSlot(q);
          if (ordinal !== null)
            return result(
              "needs-choice",
              "Say list results first so the numbers refer to an announced list."
            );
          const tokens = q.split(/\s+/).filter((word) => !["a", "an", "the", "by"].includes(word));
          candidates = candidates.filter(
            (e) => tokens.length > 0 && tokens.every(
              (token) => norm(e.label + " " + e.detail).includes(token)
            )
          );
        }
        if (op.selectOnly && a.mode && !chosen) {
          const at = candidates.findIndex((e) => e.id === this.selected?.id);
          chosen = candidates[at + (a.mode.startsWith("previous") ? -1 : 1)];
        }
        if (!chosen && !a.query && this.selectedRevision === s.revision && this.selected?.kind === op.entity)
          chosen = this.selected;
        if (!chosen && candidates.length === 1) chosen = candidates[0];
        if (!chosen) {
          if (!candidates.length)
            return result(
              "unavailable",
              "No matching visible item is available."
            );
          this.choices = {
            request,
            entities: candidates,
            offset: 0,
            expires: this.now() + 3e4
          };
          return result("needs-choice", this.choiceFeedback(this.choices), {
            choices: candidates.slice(0, 5)
          });
        }
        const node = this.context.node(chosen.id);
        if (!node)
          return result("unavailable", "That item is no longer available.");
        this.selected = chosen;
        this.selectedRevision = s.revision;
        node.scrollIntoView({ block: "center" });
        if (op.selectOnly || a.mode === "select")
          return result("available", `Selected ${chosen.label}.`, {
            evidence: chosen.id
          });
        if (chosen.href && !["track", "profile", "episode"].includes(chosen.kind)) {
          const url = new URL(chosen.href);
          if (!["https:", "http:"].includes(url.protocol))
            return result("unavailable", "That link scheme is unsupported.");
          return result("available", `Opening ${chosen.label}.`, {
            navigate: {
              url: url.href,
              newTab: spec.id === "W09" || request.args.mode === "new-tab"
            }
          });
        }
        if (["chat", "thread", "train", "route"].includes(chosen.kind)) {
          if (chosen.kind === "train")
            return result("available", `Selected train ${chosen.label}.`, {
              evidence: chosen.id
            });
          if (chosen.kind === "route" && !request.entityId)
            return result(
              "needs-choice",
              "Say list routes, then choose an announced number. Fastest is not inferred from an unqualified route list."
            );
          node.click();
          return verified(
            () => chosen.kind === "route" ? stateOf(node, []) === true : chosen.kind === "thread" ? !node.isConnected && !!this.context.inspect()?.current : norm(this.context.inspect()?.current?.label || "") === norm(chosen.label),
            `Opened ${chosen.label}.`
          );
        }
        if (chosen.kind === "draft") {
          node.focus();
          return result("available", `Selected draft ${chosen.label}.`, {
            evidence: chosen.id
          });
        }
        const player = node.querySelector(
          'button[aria-label^="Play"],button[data-testid="play-button"]'
        );
        (player || node).click();
        return verified(() => {
          if (chosen.kind === "profile")
            return !node.isConnected && !elements(".profile-link").length;
          const current = this.context.inspect()?.current;
          const same = chosen.href ? current?.href === chosen.href : !!current && norm(current.label) === norm(chosen.label);
          return same && elements("video,audio").some(
            (e) => e instanceof HTMLMediaElement && !e.paused
          );
        }, `Opened ${chosen.label}.`);
      }
      if (op.kind === "sections") {
        const sections = s.entities.filter((e) => e.kind === "section");
        if (!sections.length)
          return result("unavailable", "No article sections are available.");
        this.choices = {
          request: { ...request, action: "W04" },
          entities: sections,
          offset: 0,
          expires: this.now() + 3e4
        };
        return result("needs-choice", this.choiceFeedback(this.choices), {
          choices: sections.slice(0, 5)
        });
      }
      if (op.kind === "section" || op.kind === "introduction" || op.kind === "section-next" || op.kind === "section-previous" || op.kind === "reference") {
        let nodes = [];
        if (op.kind === "introduction") nodes = elements("#firstHeading");
        else if (op.kind === "reference") {
          const n = a.value;
          if (!Number.isInteger(n) || n < 1 || n > 1e4)
            return result("unavailable", "Provide a valid reference number.");
          nodes = elements(`.references li[id]`).filter((_, i) => i === n - 1);
          this.citationOrigin = elements(`a[href="#${nodes[0]?.id}"]`)[0] || null;
        } else if (spec.id === "G19")
          nodes = elements(`[id="L${a.value}"],[data-line-number="${a.value}"]`);
        else if (s.site === "amazon") {
          const selector = {
            A11: "#productDetails_feature_div,#prodDetails",
            A12: "#customerReviews",
            A24: "#deliveryBlockMessage"
          }[spec.id];
          if (selector) nodes = elements(selector);
        } else {
          const sections = s.entities.filter((e) => e.kind === "section");
          let entity = request.entityId ? sections.find((e) => e.id === request.entityId) : void 0;
          if (op.kind === "section-next" || op.kind === "section-previous") {
            this.sectionIndex += a.mode?.startsWith("previous") ? -1 : 1;
            entity = sections[this.sectionIndex];
          }
          if (!entity && a.query) {
            const matches = sections.filter(
              (e) => norm(e.label) === norm(a.query)
            );
            if (matches.length === 1) entity = matches[0];
            else if (matches.length > 1) {
              this.choices = {
                request,
                entities: matches,
                offset: 0,
                expires: this.now() + 3e4
              };
              return result("needs-choice", this.choiceFeedback(this.choices), {
                choices: matches.slice(0, 5)
              });
            }
          }
          if (entity) {
            this.sectionIndex = sections.indexOf(entity);
            const node = this.context.node(entity.id);
            if (node) nodes = [node];
          }
          if (spec.id === "W16") nodes = elements(".infobox");
        }
        if (nodes.length !== 1)
          return result(
            "unavailable",
            "That section or reference is absent or ambiguous."
          );
        nodes[0].scrollIntoView({ block: "start", behavior: "instant" });
        return verified(
          () => {
            const r = nodes[0].getBoundingClientRect();
            return r.top >= -10 && r.top < innerHeight;
          },
          `At ${label(nodes[0]) || "the requested section"}.`
        );
      }
      if (op.kind === "reference-return") {
        if (!this.citationOrigin?.isConnected)
          return result("unavailable", "No citation origin is recorded.");
        this.citationOrigin.scrollIntoView({ block: "center" });
        return result("available", "Returned to the citation sentence.", {
          evidence: this.citationOrigin.id
        });
      }
      if (op.kind === "find") {
        this.findQuery = a.query || "";
        this.matches = elements("#mw-content-text p,#mw-content-text li").filter(
          (e) => norm(e.textContent || "").includes(norm(this.findQuery))
        );
        this.matchIndex = -1;
        return result(
          "available",
          `${this.matches.length} matching paragraphs. Say next match.`,
          { evidence: String(this.matches.length) }
        );
      }
      if (op.kind === "find-next" || op.kind === "find-previous") {
        if (!this.matches.length)
          return result("unavailable", "Find a term in this article first.");
        this.matchIndex = (this.matchIndex + (a.mode?.startsWith("previous") ? -1 : 1) + this.matches.length) % this.matches.length;
        const node = this.matches[this.matchIndex];
        if (!node.isConnected)
          return result(
            "unavailable",
            "The article changed. Find the term again."
          );
        node.scrollIntoView({ block: "center" });
        return result(
          "available",
          `Match ${this.matchIndex + 1} of ${this.matches.length}.`,
          { evidence: this.findQuery }
        );
      }
      if (op.kind === "info") {
        if (s.site === "chatgpt") {
          const latest = elements('main [data-message-author-role="assistant"]').at(-1);
          if (!latest)
            return result("unavailable", "There is no visible ChatGPT response to read yet.");
          const text = (latest.innerText || latest.textContent || "").replace(/\s+/g, " ").trim().slice(0, 1400);
          return text ? result("available", `Latest ChatGPT response: ${text}`, { evidence: "visible-assistant-message" }) : result("unavailable", "The latest ChatGPT response has no readable text.");
        }
        if (s.site === "amazon") {
          const product = s.current;
          if (!product)
            return result("unavailable", "Open a unique product first.");
          const selected = elements(
            '#twister .selection,#twister [aria-pressed="true"],#twister [aria-checked="true"],#twister_feature_div .selection'
          ).map(label);
          const price = elements(
            "#corePrice_feature_div .a-price .a-offscreen,#corePriceDisplay_desktop_feature_div .a-price .a-offscreen"
          ).map(label);
          const availability = elements("#availability").map(label);
          return result(
            "available",
            `${product.label}. Variant: ${selected.join(", ") || "not exposed by this page"}. Displayed price: ${price[0] || "unavailable"}. ${availability.join(" ")}`,
            { evidence: product.id }
          );
        }
        const info = s.current;
        if (!info)
          return result(
            "unavailable",
            "The current item is ambiguous or unavailable."
          );
        return result(
          "available",
          `Current ${info.kind}: ${info.label}. ${info.detail !== info.label ? info.detail : ""}`,
          { evidence: info.id }
        );
      }
      if (op.kind === "state") {
        const desired = a.mode === "off" || a.mode?.startsWith("unsave") ? false : a.mode === "on" ? true : op.desired;
        if (!target || !visible(target))
          return result("unavailable", "The reaction control changed.");
        target.click();
        return verified(() => {
          const candidates = controls([...op.names, ...op.opposite], scope);
          return candidates.length === 1 && stateOf(candidates[0], op.opposite, op.names) === desired;
        }, "Verified the requested saved or reaction state.");
      }
      if (op.kind === "field") {
        const desired = a.mode?.match(/title/) ? ["Title", "Add a title"] : a.mode?.match(/body|description/) ? ["Body", "Description", "Add a description"] : op.names;
        const fields = elements(
          'input,textarea,[contenteditable="true"]',
          scope
        ).filter(
          (e) => editable(e) && desired.some((n) => norm(label(e)) === norm(n))
        );
        if (fields.length !== 1)
          return result(
            "unavailable",
            "A unique named editable field is unavailable. Protected fields are blocked."
          );
        fields[0].focus();
        return result(
          "available",
          `Dictating into ${label(fields[0])}. Say finish dictation to exit. Say literal finish dictation to insert those words.`,
          { focusField: true, evidence: label(fields[0]) }
        );
      }
      if (op.kind === "clear-draft") {
        const drafts = elements(
          'input,textarea,[contenteditable="true"]',
          scope
        ).filter(editable);
        if (drafts.length !== 1)
          return result("unavailable", "Select a single draft first.");
        const draft = drafts[0];
        draft.focus();
        if (draft instanceof HTMLInputElement || draft instanceof HTMLTextAreaElement)
          draft.select();
        else {
          const range = document.createRange();
          range.selectNodeContents(draft);
          getSelection()?.removeAllRanges();
          getSelection()?.addRange(range);
        }
        insertText(draft, "");
        return verified(
          () => !(draft instanceof HTMLInputElement || draft instanceof HTMLTextAreaElement ? draft.value : draft.textContent),
          "Cleared the selected draft."
        );
      }
      if (op.kind === "submit") {
        if (!target || !visible(target))
          return result("unavailable", "The publication control changed.");
        const before = new Set(elements(op.created));
        target.click();
        return verified(
          () => elements(op.created).filter((e) => !before.has(e)).length === 1,
          "Exactly one new publication is visible. Check its destination and ownership before live qualification."
        );
      }
      if (op.kind === "select") {
        const nodes = elements(op.selector).filter(
          (e) => e instanceof HTMLSelectElement
        );
        if (nodes.length !== 1)
          return result(
            "unavailable",
            "The selection control is unavailable or ambiguous."
          );
        const select = nodes[0], query = a.query || String(a.value ?? "");
        const options = [...select.options].filter(
          (o) => !o.disabled && (norm(o.text) === norm(query) || norm(o.value) === norm(query) || norm(o.text) === `season ${query}`)
        );
        if (options.length !== 1)
          return result(
            "unavailable",
            "That option is unavailable. Ask for an option displayed on this page."
          );
        setInput(select, options[0].value);
        return verified(
          () => select.value === options[0].value,
          `Selected ${options[0].text}.`
        );
      }
      if (op.kind === "price") {
        if (a.value === void 0 || a.value < 0 || a.end !== void 0 && a.end < a.value)
          return result("unavailable", "The price range is invalid.");
        const upper = elements(op.upper)[0], lower = op.lower ? elements(op.lower)[0] : null;
        const buttons = controls(
          [op.submit],
          elements("#s-refinements")[0] || document
        );
        if (!(upper instanceof HTMLInputElement) || op.lower && !(lower instanceof HTMLInputElement) || buttons.length !== 1)
          return result(
            "unavailable",
            "This category does not expose the supported price controls."
          );
        if (lower instanceof HTMLInputElement) setInput(lower, String(a.value));
        setInput(upper, String(a.end ?? a.value));
        const before = s.url;
        buttons[0].click();
        return verified(
          () => location.href !== before && new URL(location.href).search !== new URL(before).search,
          "The price filter changed the results destination."
        );
      }
      if (spec.id === "G09") {
        const branch = request.args.query;
        if (!branch) return result("unavailable", "Name an available branch.");
        const currentPath = new URL(s.url).pathname.split("/");
        if (["tree", "blob"].includes(currentPath[3]) && decodeURIComponent(currentPath[4] || "") === branch)
          return result("already-satisfied", `Already on branch ${branch}.`);
        let choices = controls(
          [branch],
          elements('[role="dialog"],[role="menu"]')[0] || document
        );
        if (!choices.length) {
          const openers = elements(
            'button[data-hotkey="w"],button[aria-label="Switch branches or tags"],[data-testid="branch-picker-dropdown"]'
          );
          if (openers.length !== 1)
            return result("unavailable", "The branch selector is unavailable.");
          openers[0].click();
          await until(
            () => controls(
              [branch],
              elements('[role="dialog"],[role="menu"]')[0] || document
            ).length > 0,
            valid
          );
          choices = controls(
            [branch],
            elements('[role="dialog"],[role="menu"]')[0] || document
          );
        }
        if (choices.length !== 1)
          return result("unavailable", "That branch is absent or ambiguous.");
        const choice = choices[0];
        if (choice instanceof HTMLAnchorElement) {
          const destination2 = new URL(choice.href, s.url);
          if (destination2.hostname !== "github.com" || !destination2.pathname.startsWith(
            currentPath.slice(0, 3).join("/") + "/"
          ))
            return result(
              "unavailable",
              "The branch link belongs to a different repository."
            );
          return result("available", `Opening branch ${branch}.`, {
            navigate: { url: destination2.href, newTab: false }
          });
        }
        choice.click();
        return verified(
          () => stateOf(choice, []) === true || decodeURIComponent(
            new URL(location.href).pathname.split("/")[4] || ""
          ) === branch,
          `Switched to ${branch}.`
        );
      }
      if (spec.id === "R07") {
        const [sort, range] = (a.query || "").split(" by ");
        const roots = elements('main,[role="menu"]');
        const root = roots.find((e) => e.getAttribute("role") === "menu") || roots[0];
        if (!root || !sort)
          return result("unavailable", "Open the post sorting menu first.");
        const choices = controls([sort], root);
        if (choices.length !== 1)
          return result(
            "unavailable",
            "That post sort is unavailable. Open its menu first."
          );
        if (stateOf(choices[0], []) !== true) {
          choices[0].click();
          if (!await until(() => stateOf(choices[0], []) === true, valid))
            return result(
              "failed",
              "The post sort changed without a verifiable selected state."
            );
        }
        if (range) {
          const names = {
            today: ["Today", "Past 24 hours"],
            "this week": ["This week", "Past week"],
            "this month": ["This month", "Past month"],
            "all time": ["All time"]
          }[range];
          const ranges = controls(names || [range]);
          if (ranges.length !== 1)
            return result(
              "unavailable",
              "The sort was selected, but the requested time range is unavailable. Open the time range menu."
            );
          ranges[0].click();
          return verified(
            () => stateOf(ranges[0], []) === true,
            `Sorted posts by ${sort}, ${range}.`
          );
        }
        return result("available", `Sorted posts by ${sort}.`, {
          evidence: "selected-sort"
        });
      }
      if (op.kind === "control") {
        let names = op.names;
        if (a.query) names = [a.query];
        if (spec.id === "G14")
          names = [a.mode === "conversation" ? "Conversation" : "Files changed"];
        let matches = controls(names, scope);
        if (matches.length !== 1)
          return result(
            "unavailable",
            "That control is missing, disabled or ambiguous. Open its menu explicitly if needed."
          );
        const node = matches[0], before = s.current?.id, expanded = node.getAttribute("aria-expanded"), url = location.href;
        if (op.verify === "selected" && stateOf(node, []) === true)
          return result(
            "already-satisfied",
            `${label(node)} is already selected.`
          );
        node.click();
        return verified(
          () => op.verify === "closed" ? !visible(node) : op.verify === "selected" ? stateOf(node, []) === true : op.verify === "expanded" ? node.getAttribute("aria-expanded") !== expanded || !!elements('[role="dialog"],[role="menu"],textarea').length : location.href !== url || this.context.inspect()?.current?.id !== before,
          `Verified ${names[0]}.`
        );
      }
      if (spec.id === "S05") {
        if (!/^\/(?:album|playlist)\//.test(new URL(s.url).pathname))
          return result(
            "needs-choice",
            "Open the album or playlist first. Resuming the previous track would not start that collection."
          );
        const main = elements("main")[0], players = elements("audio,video").filter(
          (e) => e instanceof HTMLMediaElement
        );
        const buttons = main ? controls(["Play"], main) : [];
        if (buttons.length !== 1 || players.length !== 1)
          return result(
            "unavailable",
            "The collection player cannot be verified on this page."
          );
        const trackHrefs = s.entities.filter((e) => e.kind === "track").map((e) => e.href);
        buttons[0].click();
        return verified(
          () => !players[0].paused && trackHrefs.includes(this.context.inspect()?.current?.href),
          "Playing a track from the current collection."
        );
      }
      if (op.kind === "media")
        return this.media(op.command, request, scope, valid);
      if (op.kind === "back") {
        history.back();
        return result(
          "available",
          "Returning through browser history. Verify the destination after it loads.",
          { evidence: "history-request" }
        );
      }
      return result(
        "not-implemented",
        "This action has no execution path in this version."
      );
    }
    async media(command, request, scope, valid) {
      const a = request.args;
      if (a.mode?.startsWith("pause")) command = "pause";
      if (a.mode?.startsWith("restart")) command = "restart";
      if (request.site === "spotify" && ["play", "pause"].includes(command)) {
        const testIdControls = elements('[data-testid="control-button-playpause"]', scope);
        const namedControls = controls(["Play", "Pause"], scope);
        const control = testIdControls.length === 1 ? testIdControls[0] : namedControls.length === 1 ? namedControls[0] : null;
        if (control) {
          const isPlaying = () => {
            const name = norm(label(control));
            if (name === "pause" || name.startsWith("pause ")) return true;
            if (name === "play" || name.startsWith("play ")) return false;
            return null;
          };
          const desired = command === "play";
          const current = isPlaying();
          if (current === desired)
            return result("already-satisfied", desired ? "Spotify is already playing." : "Spotify is already paused.", { evidence: "spotify-play-pause-control" });
          if (current === null)
            return result("unavailable", "Spotify's play/pause control does not expose its current state. Nothing was toggled.");
          control.click();
          const changed = await until(() => isPlaying() === desired, valid);
          return changed ? result("available", desired ? "Spotify playback resumed." : "Spotify playback paused.", { evidence: "spotify-play-pause-control" }) : result("failed", "Spotify's play/pause control changed, but its final state could not be verified. No automatic retry.");
        }
      }
      const players = elements("video,audio", scope).filter(
        (e) => e instanceof HTMLMediaElement
      );
      const player = players.length === 1 ? players[0] : null;
      if (!player) {
        if (["play", "pause", "next", "previous"].includes(command)) {
          const names = {
            play: ["Play"],
            pause: ["Pause"],
            next: ["Next", "Next episode"],
            previous: ["Previous"]
          }[command];
          const buttons2 = controls(names);
          if (buttons2.length === 1) {
            const before2 = this.context.inspect()?.current?.id;
            buttons2[0].click();
            const changed = await until(
              () => command === "play" ? controls(["Pause"]).length === 1 : command === "pause" ? controls(["Play"]).length === 1 : this.context.inspect()?.current?.id !== before2,
              valid
            );
            return changed ? result("available", command === "play" ? "Playback resumed." : command === "pause" ? "Playback paused." : "Player advanced.", { evidence: "player-ui-state" }) : result("failed", "Player state could not be verified. No automatic retry.");
          }
        }
        return result(
          "unavailable",
          "No unique supported player is accessible. Account restrictions or DRM may prevent this control."
        );
      }
      if (command === "pause") {
        player.pause();
        return !player.paused ? result("failed", "Playback did not pause.") : result("available", "Playback paused.", {
          evidence: "media.paused=true"
        });
      }
      if (command === "play") {
        await player.play();
        return player.paused ? result("failed", "Playback did not start.") : result("available", "Playback resumed.", {
          evidence: "media.paused=false"
        });
      }
      if (command === "mute") {
        const desired = !a.mode?.startsWith("unmute");
        player.muted = desired;
        return result(
          "available",
          desired ? "Player muted." : "Player unmuted.",
          { evidence: `muted=${player.muted}` }
        );
      }
      if (command === "speed") {
        const allowed = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
        if (a.value === void 0 || !allowed.some((speed) => Math.abs(speed - a.value) < 1e-3))
          return result("unavailable", "Choose a supported playback speed from 0.25x to 2x.");
        player.playbackRate = a.value;
        return Math.abs(player.playbackRate - a.value) < 1e-3 ? result("available", `Playback speed set to ${a.value}x.`, { evidence: `playbackRate=${player.playbackRate}` }) : result("failed", "The player rejected the requested playback speed.");
      }
      if (command === "volume" || command === "volume-relative") {
        if (a.value === void 0 || Math.abs(a.value) > 100 || command === "volume" && a.value < 0)
          return result(
            "unavailable",
            "Volume must be between zero and one hundred percent."
          );
        player.volume = Math.max(
          0,
          Math.min(
            1,
            command === "volume" ? a.value / 100 : player.volume + a.value / 100
          )
        );
        return result(
          "available",
          `Player volume ${Math.round(player.volume * 100)} percent.`,
          { evidence: String(player.volume) }
        );
      }
      if (["seek", "seek-absolute", "restart"].includes(command)) {
        if (!Number.isFinite(player.duration) || player.duration <= 0)
          return result("unavailable", "Seeking is unavailable for this stream.");
        if (command !== "restart" && (a.value === void 0 || !Number.isFinite(a.value) || command === "seek" && Math.abs(a.value) > 600 || command === "seek-absolute" && a.value < 0))
          return result("unavailable", "Provide a valid bounded time.");
        const requested = command === "restart" ? 0 : command === "seek" ? player.currentTime + a.value : a.value;
        if (requested < 0 || requested > player.duration)
          return result("unavailable", "That position is outside this title.");
        player.currentTime = requested;
        return await until(
          () => !player.seeking && Math.abs(player.currentTime - requested) < 1.5,
          valid
        ) ? result("available", `Playback at ${Math.round(requested)} seconds.`, {
          evidence: String(player.currentTime)
        }) : result("failed", "Seeking could not be verified.");
      }
      const before = this.context.inspect()?.current?.id;
      const buttons = controls(
        command === "next" ? ["Next", "Next episode"] : ["Previous"]
      );
      if (buttons.length !== 1)
        return result(
          "unavailable",
          "Track or episode switching is unavailable."
        );
      buttons[0].click();
      return await until(
        () => this.context.inspect()?.current?.id !== before,
        valid
      ) ? result("available", "The current track or episode changed.", {
        evidence: "entity-change"
      }) : result(
        "failed",
        "The requested track or episode change could not be verified."
      );
    }
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/core/safety.ts
  var ActivationGate = class {
    config;
    targetId = null;
    enteredAt = null;
    handSince = null;
    latched = false;
    lastAt = null;
    constructor(config = {}) {
      this.config = { dwellMs: 800, confidenceThreshold: 0.7 };
      this.configure(config);
    }
    configure(config) {
      if (config.dwellMs !== void 0 && Number.isFinite(config.dwellMs))
        this.config.dwellMs = Math.max(250, Math.min(5e3, config.dwellMs));
      if (config.confidenceThreshold !== void 0 && Number.isFinite(config.confidenceThreshold))
        this.config.confidenceThreshold = Math.max(
          0,
          Math.min(1, config.confidenceThreshold)
        );
      this.enteredAt = null;
      this.handSince = null;
    }
    reset() {
      this.targetId = null;
      this.enteredAt = null;
      this.handSince = null;
      this.latched = false;
      this.lastAt = null;
    }
    update(sample) {
      const blocked = (reason) => {
        this.enteredAt = null;
        this.handSince = null;
        return { activate: false, progress: 0, reason };
      };
      if (!Number.isFinite(sample.now) || !Number.isFinite(sample.confidence) || this.lastAt !== null && sample.now < this.lastAt)
        return blocked("invalid");
      this.lastAt = sample.now;
      if (sample.paused) return blocked("paused");
      if (!sample.tracking) return blocked("tracking-loss");
      if (sample.confidence < this.config.confidenceThreshold)
        return blocked("low-confidence");
      if (!sample.targetId) {
        this.targetId = null;
        this.latched = false;
        return blocked("no-target");
      }
      if (sample.targetId !== this.targetId) {
        this.targetId = sample.targetId;
        this.enteredAt = sample.now;
        this.handSince = null;
        this.latched = false;
      }
      if (this.latched)
        return { activate: false, progress: 1, reason: "latched" };
      if (this.enteredAt === null) this.enteredAt = sample.now;
      const hand = sample.activate === "hand" || sample.handHold === true;
      if (hand && this.handSince === null) this.handSince = sample.now;
      if (!hand) this.handSince = null;
      if (sample.activate !== "voice" && !hand && sample.dwellEnabled === false)
        return { activate: false, progress: 0, reason: "disabled" };
      const elapsed = sample.now - (hand ? this.handSince : this.enteredAt);
      const progress = Math.max(0, Math.min(1, elapsed / this.config.dwellMs));
      if (sample.activate === "voice" || progress >= 1) {
        this.latched = true;
        return { activate: true, progress: 1, reason: "activated" };
      }
      return { activate: false, progress, reason: "waiting" };
    }
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/shared.ts
  var defaults = {
    enabledInputs: null,
    onboardingStep: 0,
    onboardingCompleted: false,
    setupGuidance: "ask",
    voiceOnly: false,
    spokenFeedback: false,
    testWriteTargets: [],
    testMessageRecipients: [],
    sensitivity: 1,
    handSensitivity: 1.6,
    pausePhrase: "pause handsfree",
    resumePhrase: "resume handsfree",
    scrollSensitivity: 1,
    cursorStyle: "circle",
    dwellMs: 800,
    deadZone: 0.035,
    confidenceThreshold: 0.7,
    pointerMode: "face",
    dwellEnabled: true,
    edgeScroll: true,
    speechMode: "browser",
    language: "en-US",
    llmKey: "",
    llmModel: "gpt-4.1-mini",
    dashboardUrl: "http://localhost:3000/dashboard",
    groqModel: "qwen/qwen3.8-27b",
    jevProvider: "openrouter"
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/core/cursors.ts
  var cursorPaths = {
    arrow: "M19 19 V32 L23 28 L27 36 L31 34 L27 26 H33 Z",
    crosshair: "M19 7 V13 M19 25 V31 M7 19 H13 M25 19 H31",
    spark: "M19 8 Q21 17 30 19 Q21 21 19 30 Q17 21 8 19 Q17 17 19 8 Z"
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/content/overlay.ts
  var Overlay = class {
    host = document.createElement("div");
    cursor;
    ring;
    outline;
    label;
    feedback;
    choices;
    transcription;
    spokenText;
    spokenLabel;
    constructor() {
      this.host.id = overlayId;
      this.host.dataset.handsfreeIgnore = "true";
      this.host.style.cssText = "position:fixed;inset:0;pointer-events:none!important;z-index:2147483647;";
      const shadow = this.host.attachShadow({ mode: "open" });
      shadow.innerHTML = `<style>
      :host{all:initial;pointer-events:none!important}*{box-sizing:border-box;pointer-events:none!important}
      .cursor{position:fixed;left:0;top:0;width:38px;height:38px;transform:translate(-50%,-50%);display:none}
      .cursor svg{position:absolute;inset:0;width:38px;height:38px;filter:drop-shadow(0 1px 2px #0009)}
      .dwell-ring{transform:rotate(-90deg)}
      .dwell-ring circle{fill:none;stroke:#c1ef53;stroke-width:2.5;stroke-linecap:round;stroke-dasharray:100;stroke-dashoffset:100}
      .cursor-icon{display:none;fill:#f6f7f2;stroke:#20231b;stroke-width:1.5;stroke-linejoin:round}
      .cursor [data-icon=circle]{fill:#c1ef53}
      .cursor[data-style=circle] [data-icon=circle],.cursor[data-style=arrow] [data-icon=arrow],.cursor[data-style=crosshair] [data-icon=crosshair],.cursor[data-style=spark] [data-icon=spark]{display:block}
      .cursor [data-icon=crosshair]{fill:none;stroke:#f6f7f2;stroke-width:2;stroke-linecap:round}
      .outline{position:fixed;border:3px solid #c1ef53;border-radius:7px;box-shadow:0 0 0 2px #20231b;display:none}
      .label,.feedback,.choice{position:fixed;background:#20231b;color:#f6f7f2;border:1px solid #c1ef53;border-radius:9px;font:600 14px/1.5 system-ui,sans-serif;padding:8px 12px;max-width:min(430px,calc(100vw - 24px));overflow-wrap:anywhere}
      .label{display:none}.feedback{bottom:18px;left:18px}.feedback:empty{display:none}.feedback{max-height:45vh;overflow:auto;white-space:pre-wrap}
      .choice{padding:4px 8px;transform:translateY(-100%)}
      .transcription{position:fixed;right:20px;bottom:20px;width:min(320px,calc(100vw - 40px));padding:16px 18px;background:#20231b;color:#f6f7f2;border:1px solid #49533a;border-radius:16px;box-shadow:0 8px 32px #0003;font:500 14px/1.5 system-ui,sans-serif;overflow-wrap:anywhere;display:none}
      .spoken-label{color:#c1ef53;font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;margin-bottom:6px}.spoken-text:empty:after{content:'Say a command, or start typing.';color:#bfc4b6}
      @media(max-width:600px){.feedback{bottom:125px}}
    </style><div class="outline"></div><div class="label"></div><div class="cursor" data-style="circle"><svg class="cursor-icon" data-icon="circle" viewBox="0 0 38 38" aria-hidden="true"><circle cx="19" cy="19" r="5"/></svg><svg class="cursor-icon" data-icon="arrow" viewBox="0 0 38 38" aria-hidden="true"><path d="${cursorPaths.arrow}"/></svg><svg class="cursor-icon" data-icon="crosshair" viewBox="0 0 38 38" aria-hidden="true"><path d="${cursorPaths.crosshair}"/></svg><svg class="cursor-icon" data-icon="spark" viewBox="0 0 38 38" aria-hidden="true"><path d="${cursorPaths.spark}"/></svg><svg class="dwell-ring" viewBox="0 0 38 38" aria-hidden="true"><circle cx="19" cy="19" r="15" pathLength="100"/></svg></div><div class="choices"></div><div class="feedback" role="status" aria-live="polite" aria-atomic="true"></div><div class="transcription" aria-label="Voice transcription"><div class="spoken-label">Listening</div><div class="spoken-text" role="status" aria-live="polite" aria-atomic="true"></div></div>`;
      this.cursor = shadow.querySelector(".cursor");
      this.ring = shadow.querySelector(".dwell-ring circle");
      this.outline = shadow.querySelector(".outline");
      this.label = shadow.querySelector(".label");
      this.feedback = shadow.querySelector(".feedback");
      this.choices = shadow.querySelector(".choices");
      this.transcription = shadow.querySelector(".transcription");
      this.spokenText = shadow.querySelector(".spoken-text");
      this.spokenLabel = shadow.querySelector(".spoken-label");
      document.documentElement.append(this.host);
    }
    style(style) {
      this.cursor.dataset.style = ["circle", "arrow", "crosshair", "spark"].includes(style) ? style : "circle";
    }
    pointer(x2, y, visible2, progress = 0) {
      this.cursor.style.display = visible2 ? "block" : "none";
      this.cursor.style.left = `${x2}px`;
      this.cursor.style.top = `${y}px`;
      this.ring.style.strokeDashoffset = String(
        100 - Math.min(1, Math.max(0, progress)) * 100
      );
    }
    target(element) {
      this.outline.style.display = element ? "block" : "none";
      this.label.style.display = element ? "block" : "none";
      if (!element) return;
      const box = element.getBoundingClientRect();
      Object.assign(this.outline.style, {
        left: `${box.left - 3}px`,
        top: `${box.top - 3}px`,
        width: `${box.width + 6}px`,
        height: `${box.height + 6}px`
      });
      this.label.textContent = targetLabel(element);
      this.label.style.left = `${Math.max(12, Math.min(innerWidth - Math.min(430, innerWidth - 24), box.left))}px`;
      this.label.style.top = `${Math.min(innerHeight - 60, Math.max(12, box.bottom + 8))}px`;
    }
    announce(text) {
      this.feedback.textContent = text;
    }
    transcript(text, final, visible2) {
      this.transcription.style.display = visible2 ? "block" : "none";
      this.spokenLabel.textContent = final ? "Heard" : "Listening";
      this.spokenText.setAttribute("aria-live", final ? "polite" : "off");
      if (this.spokenText.textContent !== text) this.spokenText.textContent = text;
    }
    options(elements2) {
      this.choices.replaceChildren(
        ...elements2.map((element, index) => {
          const node = document.createElement("div");
          node.className = "choice";
          node.textContent = `${index + 1}. ${targetLabel(element)}`;
          const box = element.getBoundingClientRect();
          node.style.left = `${Math.max(8, Math.min(innerWidth - 220, box.left))}px`;
          node.style.top = `${Math.max(38, box.top)}px`;
          return node;
        })
      );
    }
    destroy() {
      this.host.remove();
    }
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/content/scroll.ts
  function scrollPixels(top, origin2) {
    if (!top) return;
    for (let element = origin2; element; element = element.parentElement) {
      if (!(element instanceof HTMLElement) || element === document.body || element === document.documentElement) continue;
      const overflow = getComputedStyle(element).overflowY;
      const maximum = element.scrollHeight - element.clientHeight;
      if (/^(auto|scroll|overlay)$/.test(overflow) && maximum > 1 && (top > 0 ? element.scrollTop < maximum - 1 : element.scrollTop > 1)) {
        const available = top > 0 ? maximum - element.scrollTop : element.scrollTop;
        const consumed = Math.sign(top) * Math.min(Math.abs(top), available);
        element.scrollBy({ top: consumed, behavior: "instant" });
        const remainder = top - consumed;
        if (remainder) scrollPixels(remainder, element.parentElement);
        return;
      }
    }
    window.scrollBy({ top, behavior: "instant" });
  }
  var ScrollMotion = class {
    animation = null;
    get active() {
      return this.animation !== null;
    }
    cancel() {
      this.animation = null;
    }
    command(top, origin2, now) {
      this.cancel();
      if (globalThis.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
        scrollPixels(top, origin2);
      } else {
        this.animation = { top, origin: origin2, elapsed: 0, last: now, progress: 0 };
      }
    }
    tick(now) {
      const a = this.animation;
      if (!a) return;
      a.elapsed += Math.max(0, Math.min(50, now - a.last));
      a.last = now;
      const t = Math.min(1, a.elapsed / 420);
      const progress = t * t * (3 - 2 * t);
      scrollPixels(a.top * (progress - a.progress), a.origin?.isConnected ? a.origin : null);
      a.progress = progress;
      if (t === 1) this.cancel();
    }
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/content/media.ts
  async function mediaControl(intent) {
    const media = [];
    function scan(root) {
      for (const element of root.querySelectorAll("video,audio")) {
        if (!(element instanceof HTMLMediaElement) || element.closest("[hidden],[inert],[data-handsfree-ignore]")) continue;
        const style = getComputedStyle(element), box = element.getBoundingClientRect();
        if (style.display === "none" || style.visibility === "hidden") continue;
        if (element instanceof HTMLVideoElement && (box.width <= 0 || box.height <= 0)) continue;
        media.push(element);
      }
      for (const element of root.querySelectorAll("*")) if (element.shadowRoot) scan(element.shadowRoot);
    }
    scan(document);
    const score = (element) => {
      const box = element.getBoundingClientRect();
      const width = Math.max(0, Math.min(innerWidth, box.right) - Math.max(0, box.left));
      const height = Math.max(0, Math.min(innerHeight, box.bottom) - Math.max(0, box.top));
      return element instanceof HTMLVideoElement ? width * height : element.paused ? 1 : 2;
    };
    media.sort((a, b) => score(b) - score(a));
    const selected = media[0];
    if (!selected) return { found: false, score: 0, error: "No video or audio player found. Open the player and enable webpage access." };
    const result2 = { found: true, score: score(selected) };
    if (!intent) return result2;
    try {
      if (intent.type === "media-pause") selected.pause();
      else if (intent.type === "media-play") await selected.play();
      else if (intent.type === "media-toggle") selected.paused ? await selected.play() : selected.pause();
      else if (intent.type === "media-seek") {
        const finite = Number.isFinite(selected.duration);
        const lower = finite ? 0 : selected.seekable.length ? selected.seekable.start(0) : 0;
        const upper = finite ? selected.duration : selected.seekable.length ? selected.seekable.end(selected.seekable.length - 1) : selected.duration;
        if (!Number.isFinite(upper)) return { ...result2, ok: false, error: "This live stream cannot seek yet." };
        selected.currentTime = Math.max(lower, Math.min(upper, selected.currentTime + intent.seconds));
      } else return { ...result2, ok: false };
      return { ...result2, ok: true };
    } catch {
      return { ...result2, ok: false, error: "The player blocked this action. Start playback once on the page, then retry." };
    }
  }

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/content/forms.ts
  var controlSelector = 'input:not([type="hidden"]),textarea,select,[role="combobox"],[role="radio"],[role="checkbox"]';
  var ignoredText = 'input,textarea,select,option,[contenteditable]:not([contenteditable="false"]),[role="textbox"],[role="combobox"],[role="alert"],[aria-live],script,style,noscript,template,[data-private],[data-handsfree-ignore]';
  var privateRegion = `[data-private],[data-handsfree-ignore],#${overlayId}`;
  var sensitivePatterns = [
    /\b(?:password|passwd|passcode|one[ -]?time(?:[ -]?(?:code|password))?|otp|verification[ -]?code|security[ -]?code)\b/i,
    /\b(?:credit|debit|payment|card(?:[ -]?(?:number|holder|expiry|expiration|details?))?|cvv|cvc|cc[ -]?(?:number|name|exp|csc|type)|bank|routing|iban|swift|account[ -]?number|upi[ -]?id)\b/i,
    /\b(?:passport|aadh?aar|social[ -]?security|ssn|national[ -]?(?:id|identifier|identification|insurance[ -]?number|number)|(?:government|govt)[ -]?(?:issued[ -]?)?(?:id|identifier|identification|number)|state[ -]?id|driver'?s?[ -]?licen[cs]e|birth[ -]?certificate|citizenship[ -]?(?:id|number)|tax(?:payer)?[ -]?(?:id|identifier|identification|number|reference|code|registration)|tin|ein|gstin|gst[ -]?(?:number|id|registration)|vat[ -]?(?:number|id|registration)|pan[ -]?(?:card|number)|voter[ -]?(?:id|number))\b/i,
    /\b(?:medical|health|diagnos(?:is|es|tic)|medications?|prescription|symptoms?|patients?|disabilit(?:y|ies)|allerg(?:y|ies)|blood[ -]?(?:type|group|pressure|sugar|glucose)|hiv|aids|pregnan(?:cy|t)|mental[ -]?(?:health|illness|disorder)|chronic|illness|disease|treatment|therapy|surgery|surgical|vaccin(?:e|ation|ated)|immuni[sz]ation|cholesterol|glucose|bmi|cancers?|tumou?rs?|oncolog(?:y|ical|ist)|malignan(?:t|cy)|diabet(?:es|ic)|asthma|hypertension|stroke|cardiac|heart[ -]?(?:disease|condition)|kidney[ -]?(?:disease|condition)|clinical|psychiatr(?:ic|y|ist)|addiction|infection|hepatitis|hospitali[sz]ation|family[ -]?history|(?:health|disease|surgical|treatment|patient)[ -]?history|history[ -]?of[ -]?(?:illness|disease|cancer|surgery|treatment))\b/i,
    /\b(?:epileps(?:y|ies)|seizures?|migraines?|headaches?|dementia|alzheimer'?s?|parkinson'?s?|multiple[ -]?sclerosis|depression|anxiety|bipolar|schizophrenia|ptsd|adhd|autism|copd|bronchitis|emphysema|apn(?:ea|oea)|arthritis|autoimmune|lupus|eczema|psoriasis|chemotherapy|metastasis|tuberculosis|covid(?:[ -]?19)?|crohn'?s?|irritable[ -]?bowel|celiac|coeliac|ulcers?|thyroid|cirrhosis|endometriosis|infertility|fertility[ -]?treatment)\b/i,
    /\b(?:heart[ -]?attack|myocardial[ -]?infarction|heart[ -]?failure|arrhythmia|angina|pneumonia|narcolepsy|insomnia|anorexia|bulimia|osteoporosis|fibromyalgia|gout|anemia|anaemia|sickle[ -]?cell|hemophilia|haemophilia|leukemia|leukaemia|lymphoma|melanoma|meningitis|sepsis|polio|measles|mumps|rubella|malaria|dengue|cholera|dyslexia|syndromes?|disorders?|lesions?|fractures?|concussions?|injuries|pain|bleeding|nausea|vomiting|fever|fatigue|dizziness|cough|dosage|doses?|vitals?|pulse|oxygen[ -]?(?:level|saturation)|body[ -]?(?:weight|temperature))\b/i
  ];
  var vagueName = /^(?:other|answer|response|field|input|text|select|choose|option|yes|no|please specify|untitled|id|identifier|number|code|reference|details?|information|history|status|condition|date|expiry|expiration|secret|confidential|sensitive|identity|personal (?:details|information|data)|(?:please )?(?:enter|describe|specify)(?: here)?|additional (?:details|information)|question\s*\d+)(?:\s*\d+)?$/i;
  var ordinarySingleName = /^(?:name|firstname|lastname|surname|email|e-mail|phone|telephone|mobile|website|url|address|street|city|state|province|country|postcode|zipcode|zip|postal|company|employer|organization|occupation|job|position|title|department|school|university|college|age|time|quantity|color|colour|size|comments?|feedback|message|notes?|subject|event|location|preference|hobby|username|description)$/i;
  var ordinaryMeaningPatterns = [
    /^(?:(?:first|middle|last|full|given|family|preferred|display|legal|contact|user) )?name$/i,
    /^(?:(?:work|home|personal|alternate|alternative|contact) )?(?:e mail|email)(?: address)?$/i,
    /^(?:(?:work|home|personal|alternate|alternative|contact|mobile|cell) )?(?:phone|telephone|mobile|cell)(?: number)?$/i,
    /^(?:website(?: url| address)?|web site(?: url| address)?|url|country code|dialing code|dialling code)$/i,
    /^(?:(?:mailing|shipping|billing|delivery|home|work|street|postal) )?address(?: line [12])?$/i,
    /^(?:(?:shipping|billing|delivery|home|work) )?(?:street(?: address| name| number)?|city|town|state|province|region|country|zip(?: code)?|postal code|post code)$/i,
    /^(?:company|employer|organization|organisation|business|department|school|university|college)(?: name| address| website| location)?$/i,
    /^(?:job title|position title|professional title|job role|employment status|employment type|work experience|years of experience|student year|graduation (?:year|date)|course(?: name)?|major|degree|academic (?:grade|score)|exam (?:grade|score))$/i,
    /^(?:employment|work|job|education|school|academic|order|purchase|travel|project|browser|search) history$/i,
    /^(?:student|employee|customer|order|product|item|project|booking|reservation|shipment|tracking) (?:id|identifier|number|code|reference|status|details|information|date)$/i,
    /^(?:product|item|shipping|weather|road) condition$/i,
    /^(?:event|meeting|appointment|reservation|booking|travel|arrival|departure|delivery|start|end) (?:name|title|date|time|location|details)$/i,
    /^(?:date of birth|birth date|birthdate|birthday|age|time zone|timezone)$/i,
    /^(?:(?:favorite|favourite|preferred) )?(?:color|colour|size|language|hobby|hobbies|interests|sport|movie|music|food|book)$/i,
    /^(?:contact|communication|delivery|shipping) (?:method|preference|preferences|instructions|details|information)$/i,
    /^(?:(?:additional|other|your|general) )?(?:comments|feedback|message|notes|description|suggestions)$/i,
    /^(?:message subject|subject line|search(?: query| terms)?|quantity|number of (?:items|tickets|guests|attendees)|terms and conditions|terms of (?:use|service)|newsletter(?: subscription)?|marketing consent)$/i
  ];
  function bounded(value2, length = 180) {
    return value2.replace(/\s+/g, " ").trim().slice(0, length);
  }
  function semanticText(value2) {
    return value2.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/[_./-]+/g, " ").replace(/\s+/g, " ").trim();
  }
  function meaningText(value2) {
    let meaning = semanticText(value2).toLowerCase();
    let previous;
    do {
      previous = meaning;
      meaning = meaning.replace(/^[\s:;,!?*–—]+|[\s:;,!?*–—]+$/g, "").replace(/\s*\((?:required|optional)\)$/, "").trim().replace(/^(?:(?:please|kindly|enter|provide|select|choose|describe|specify|your|the|a|an)\b|what (?:is|are)\b)[\s:;,!?–—]*/, "").trim();
    } while (meaning !== previous);
    return meaning;
  }
  function comparableMeaning(value2) {
    const meaning = meaningText(value2);
    if (meaning === "full name") return "name";
    if (meaning === "firstname" || meaning === "given name") return "first name";
    if (meaning === "lastname" || meaning === "surname" || meaning === "family name") return "last name";
    return meaning;
  }
  function ordinaryMeaning(value2) {
    const meaning = meaningText(value2);
    return ordinarySingleName.test(meaning) || ordinaryMeaningPatterns.some((pattern) => pattern.test(meaning));
  }
  function contactKind(value2) {
    const normalized = semanticText(value2).toLowerCase();
    const kinds = [
      /\b(?:email|e mail)\b/.test(normalized) ? "email" : null,
      /\b(?:phone|telephone|mobile|tel)\b/.test(normalized) ? "phone" : null,
      /\b(?:website|web site|url)\b/.test(normalized) ? "url" : null
    ].filter(Boolean);
    return kinds.length > 1 ? "conflicting" : kinds.length === 1 ? kinds[0] : null;
  }
  function parentOf(element) {
    if (element.parentElement) return element.parentElement;
    const root = element.getRootNode();
    return root instanceof ShadowRoot ? root.host : null;
  }
  function ancestors(element) {
    const result2 = [];
    for (let current = element; current; current = parentOf(current)) result2.push(current);
    return result2;
  }
  function rendered(element, requireBox = true, modalScope = true) {
    if (!(element instanceof HTMLElement) || !element.isConnected) return false;
    for (const ancestor of ancestors(element)) {
      if (ancestor.matches(`[hidden],[inert],[aria-hidden="true"],${privateRegion}`)) return false;
      const style = getComputedStyle(ancestor);
      if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse" || Number(style.opacity || "1") <= 0) return false;
    }
    if (requireBox) {
      const box = element.getBoundingClientRect();
      if (box.width <= 0 || box.height <= 0) return false;
    }
    if (modalScope) {
      const dialogs = [...document.querySelectorAll('dialog[open],[role="dialog"][aria-modal="true"]')].filter(usable);
      if (dialogs.length && !dialogs.some((dialog) => dialog.contains(element))) return false;
    }
    return true;
  }
  function all(selector, scope = document) {
    const found = [...scope.querySelectorAll(selector)];
    for (const host of scope.querySelectorAll("*"))
      if (host.shadowRoot) found.push(...all(selector, host.shadowRoot));
    return [...new Set(found)].filter((element) => element instanceof HTMLElement);
  }
  function staticText2(element, limit = 360, skipChoices = false) {
    if (!element || element.matches(privateRegion)) return "";
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
    let result2 = "";
    let node;
    while (result2.length < limit && (node = walker.nextNode())) {
      const parent = node.parentElement;
      if (!parent || parent.closest(ignoredText + "," + privateRegion)) continue;
      if (skipChoices && parent.closest('label,[role="radio"],[role="checkbox"]')) continue;
      if (ancestors(parent).some((ancestor) => {
        if (ancestor.matches('[hidden],[inert],[aria-hidden="true"]')) return true;
        const style = getComputedStyle(ancestor);
        return style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse";
      })) continue;
      const piece = bounded(node.textContent || "", limit - result2.length);
      if (piece) result2 += (result2 ? " " : "") + piece;
    }
    return bounded(result2, limit);
  }
  function referencedText(element, attribute) {
    const root = element.getRootNode();
    const ids = (element.getAttribute(attribute) || "").split(/\s+/).filter(Boolean).slice(0, 8);
    return bounded(ids.map((id) => {
      const target = root instanceof Document || root instanceof ShadowRoot ? root.getElementById(id) : null;
      return staticText2(target);
    }).filter(Boolean).join(" "));
  }
  function associatedLabel(element) {
    if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement || element instanceof HTMLSelectElement)
      return bounded([...element.labels || []].map((label2) => staticText2(label2)).filter(Boolean).join(" "));
    return "";
  }
  function groupContainer(element, boundary) {
    for (const ancestor of ancestors(element).slice(1)) {
      if (ancestor === boundary || ancestor.matches('form,[role="form"]')) break;
      if (!(ancestor instanceof HTMLElement)) continue;
      if (ancestor.matches('fieldset,[role="group"],[role="radiogroup"],[data-params],[data-item-id]')) return ancestor;
      const fields = ancestor.querySelectorAll(controlSelector).length;
      if (fields <= 12 && ancestor.querySelector('legend,label,h1,h2,h3,h4,h5,h6,[role="heading"],[aria-label],[aria-labelledby]')) return ancestor;
    }
    return null;
  }
  function groupName(group) {
    if (!group) return "";
    const legend = group.querySelector(":scope > legend");
    const heading = group.querySelector('h1,h2,h3,h4,h5,h6,[role="heading"]');
    const direct = staticText2(legend) || referencedText(group, "aria-labelledby") || group.getAttribute("aria-label") || staticText2(heading);
    if (direct) return bounded(direct);
    if (group.matches('[role="radiogroup"]')) {
      const question = ancestors(group).slice(1).find((ancestor) => ancestor.matches('[data-params],[data-item-id],[role="group"],fieldset') && !ancestor.matches('form,[role="form"]'));
      if (question instanceof HTMLElement) return groupName(question);
    }
    return bounded(staticText2(group, 360, true));
  }
  function questionName(group) {
    if (!group) return "";
    if (group.matches('fieldset,[role="group"],[role="radiogroup"],[data-params],[data-item-id]')) return groupName(group);
    return group.querySelectorAll(controlSelector).length === 1 ? groupName(group) : "";
  }
  function controlName(element, group) {
    return bounded(
      associatedLabel(element) || referencedText(element, "aria-labelledby") || element.getAttribute("aria-label") || (element.matches('[role="checkbox"],[role="radio"]') ? staticText2(element) : "") || staticText2(element.closest("fieldset")?.querySelector("legend") || null) || questionName(group) || element.getAttribute("placeholder") || ""
    );
  }
  function optionName(element) {
    return bounded(associatedLabel(element) || referencedText(element, "aria-labelledby") || element.getAttribute("aria-label") || staticText2(element));
  }
  function sectionRoot(element, boundary) {
    for (const ancestor of ancestors(element).slice(1)) {
      if (ancestor === boundary) break;
      if (ancestor.matches('section,[role="region"],[data-section-id]') && ancestor instanceof HTMLElement)
        return ancestor;
    }
    return null;
  }
  function sectionName(element, boundary) {
    const section = sectionRoot(element, boundary);
    return section ? bounded(referencedText(section, "aria-labelledby") || section.getAttribute("aria-label") || staticText2(section.querySelector('h1,h2,h3,h4,h5,h6,[role="heading"]')) || "") : "";
  }
  function classify(element, members, name, group, formName) {
    const descriptors = [...members, element, ...group ? [group] : []].map((item) => [
      item.getAttribute("type"),
      item.getAttribute("autocomplete"),
      item.getAttribute("name"),
      item.id,
      item.getAttribute("aria-label"),
      item.getAttribute("placeholder"),
      item.getAttribute("title"),
      referencedText(item, "aria-labelledby"),
      referencedText(item, "aria-describedby")
    ].filter(Boolean).join(" "));
    const questionContext = group ? staticText2(group, 1e3) : "";
    const ancestorContext = ancestors(element).slice(1).filter((ancestor) => ancestor.matches('section,[role="region"],[data-section-id],fieldset,[role="group"],[data-params],[data-item-id]')).map((ancestor) => [
      referencedText(ancestor, "aria-labelledby"),
      ancestor.getAttribute("aria-label"),
      referencedText(ancestor, "aria-describedby"),
      ancestor.getAttribute("title"),
      staticText2(ancestor.querySelector('legend,h1,h2,h3,h4,h5,h6,[role="heading"]'))
    ].filter(Boolean).join(" "));
    const context = semanticText([name, questionContext, formName, ...descriptors, ...ancestorContext].join(" "));
    if (sensitivePatterns.some((pattern) => pattern.test(context)) || /^(?:pan|nhs|nino)$/i.test(name.trim()))
      return { status: "blocked", reason: "sensitive" };
    const labelKind = contactKind(name);
    const metadata = [...members, element].flatMap((item) => [
      item.getAttribute("autocomplete") || "",
      item.getAttribute("name") || "",
      item instanceof HTMLInputElement ? item.type : ""
    ]);
    const metadataKinds = metadata.map(contactKind).filter(Boolean);
    const namingElement = element.matches('input[type="radio"],[role="radio"]') ? group : element;
    const explicitNames = namingElement ? [associatedLabel(namingElement), referencedText(namingElement, "aria-labelledby"), namingElement.getAttribute("aria-label") || ""].filter(Boolean) : [];
    const explicitKinds = explicitNames.map(contactKind).filter(Boolean);
    const typedKind = element instanceof HTMLInputElement ? contactKind(element.type) : null;
    if (labelKind === "conflicting" || metadataKinds.includes("conflicting") || explicitKinds.includes("conflicting") || labelKind && [...metadataKinds, ...explicitKinds].some((kind) => kind !== labelKind) || typedKind && typedKind !== labelKind || !labelKind && explicitKinds.length > 0)
      return { status: "blocked", reason: "uncertain" };
    const normalizedName = semanticText(name).toLowerCase();
    const clarifications = [groupName(group), ...ancestorContext].map(semanticText);
    const qualified = vagueName.test(name) && clarifications.some((value2) => {
      const words = value2.toLowerCase().split(/\s+/);
      const labelWords = normalizedName.split(/\s+/);
      const mentionsLabel = words.some((_, index) => labelWords.every((word, offset) => words[index + offset] === word));
      return mentionsLabel && ordinaryMeaning(value2);
    });
    if (!name || !ordinaryMeaning(name) && !qualified || explicitNames.some((value2) => comparableMeaning(value2) !== comparableMeaning(name) && (!ordinaryMeaning(value2) || !labelKind || contactKind(value2) !== labelKind)) || questionContext.length >= 1e3 || context.length >= 2400)
      return { status: "blocked", reason: "uncertain" };
    return { status: "safe" };
  }
  function inputType(element) {
    if (element.getAttribute("role") === "combobox") return "combobox";
    if (element.getAttribute("role") === "radio") return "radio-group";
    if (element.getAttribute("role") === "checkbox") return "checkbox";
    if (element instanceof HTMLTextAreaElement) return "textarea";
    if (element instanceof HTMLSelectElement) return "select";
    if (!(element instanceof HTMLInputElement)) return null;
    if (element.type === "radio") return "radio-group";
    if (element.type === "checkbox") return "checkbox";
    if (element.type === "password") return "unsupported";
    if (["text", "email", "tel", "url", "number", "search", "date", "time", "datetime-local", "month", "week"].includes(element.type))
      return element.type;
    return null;
  }
  function isDisabled(element) {
    return element.matches(':disabled,[aria-disabled="true"]') || ancestors(element).some((ancestor) => ancestor.matches('[aria-disabled="true"]'));
  }
  function isReadOnly(element) {
    return element.matches('[readonly],[aria-readonly="true"]') || ancestors(element).some((ancestor) => ancestor.matches('[aria-readonly="true"]'));
  }
  function isRequired(element) {
    return element.matches('[required],[aria-required="true"]') || ancestors(element).some((ancestor) => ancestor.matches('[aria-required="true"]'));
  }
  function completed(element, type, members) {
    if (type === "radio-group") return members.some((member) => member instanceof HTMLInputElement ? member.checked : member.getAttribute("aria-checked") === "true");
    if (type === "checkbox") return element instanceof HTMLInputElement ? element.checked : element.getAttribute("aria-checked") === "true";
    if (type === "select" && element instanceof HTMLSelectElement) return Boolean(element.value);
    if (type === "combobox") {
      if (element instanceof HTMLInputElement) return Boolean(element.value.trim());
      return Boolean(element.getAttribute("aria-valuetext") || element.getAttribute("aria-valuenow"));
    }
    if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) return Boolean(element.value.trim());
    return false;
  }
  function digest(parts) {
    let hash = 2166136261;
    for (const character of parts.join("")) {
      hash ^= character.charCodeAt(0);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(36);
  }
  function availableOption(option) {
    for (const ancestor of ancestors(option)) {
      if (ancestor.matches('[hidden],[aria-hidden="true"]')) return false;
      const style = getComputedStyle(ancestor);
      if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") return false;
      if (ancestor instanceof HTMLSelectElement) break;
    }
    return true;
  }
  function nativeSubmit(element) {
    return element instanceof HTMLButtonElement ? element.type === "submit" : element instanceof HTMLInputElement && (element.type === "submit" || element.type === "image");
  }
  function submitCandidates(scope = document) {
    return all('button,input[type="submit"],input[type="image"],[role="button"]', scope).filter((element) => nativeSubmit(element) || element.getAttribute("role") === "button").filter((element) => rendered(element));
  }
  function fallbackGroup(elements2) {
    if (elements2.length === 1) return true;
    const shared = ancestors(elements2[0]).find((ancestor) => elements2.every((element) => ancestors(element).includes(ancestor)));
    for (let ancestor = shared || null; ancestor; ancestor = parentOf(ancestor)) {
      if (!(ancestor instanceof HTMLElement) || ancestor.matches("html,body")) break;
      if (ancestor.matches('main,[role="main"]')) continue;
      if (!ancestor.matches('fieldset,[role="group"],[role="radiogroup"]')) continue;
      const heading = ancestor.querySelector(':scope > h1,:scope > h2,:scope > h3,:scope > h4,:scope > h5,:scope > h6,:scope > [role="heading"],:scope > header > h1,:scope > header > h2,:scope > header > h3,:scope > header > h4,:scope > header > h5,:scope > header > h6');
      const name = referencedText(ancestor, "aria-labelledby") || ancestor.getAttribute("aria-label") || staticText2(ancestor.querySelector(":scope > legend")) || staticText2(heading);
      if (bounded(name || "") && !/^(?:group|form|section|untitled)$/i.test(bounded(name || ""))) return true;
    }
    return false;
  }
  var documentId = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `doc-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  var FormModel = class {
    ids = /* @__PURE__ */ new WeakMap();
    sequence = 0;
    current = { documentId, signature: "", forms: [] };
    controls = /* @__PURE__ */ new Map();
    id(object) {
      let id = this.ids.get(object);
      if (!id) {
        id = `${documentId}:${++this.sequence}`;
        this.ids.set(object, id);
      }
      return id;
    }
    discover() {
      return this.refresh();
    }
    control(id) {
      const control = this.controls.get(id);
      return control?.element.isConnected ? control : void 0;
    }
    refresh() {
      const candidates = all(controlSelector).filter((element) => rendered(element)).filter((element) => inputType(element) !== null);
      const roots = all('form,[role="form"]').filter((root) => rendered(root, false, false));
      const buckets = /* @__PURE__ */ new Map();
      for (const root of roots) buckets.set(root, []);
      const unrooted = [];
      for (const candidate of candidates) {
        const nativeForm = "form" in candidate ? candidate.form : null;
        const root = nativeForm && buckets.has(nativeForm) ? nativeForm : ancestors(candidate).find((ancestor) => ancestor instanceof HTMLElement && buckets.has(ancestor));
        if (root) buckets.get(root)?.push(candidate);
        else unrooted.push(candidate);
      }
      if (!roots.length && unrooted.length && fallbackGroup(unrooted)) buckets.set(document, unrooted);
      const nextControls = /* @__PURE__ */ new Map();
      const forms = [];
      for (const [root, elements2] of buckets) {
        if (!elements2.length) continue;
        const formId = this.id(root);
        const name = root instanceof Document ? bounded(document.title) : bounded(
          referencedText(root, "aria-labelledby") || root.getAttribute("aria-label") || staticText2(root.querySelector('legend,h1,h2,h3,h4,h5,h6,[role="heading"]')) || root.getAttribute("name") || "Form"
        );
        const seen = /* @__PURE__ */ new Set();
        const controls2 = [];
        for (const element of elements2) {
          if (seen.has(element)) continue;
          const type = inputType(element);
          if (!type) continue;
          let members = [element];
          let group = groupContainer(element, root);
          if (type === "radio-group") {
            const radioRoot = ancestors(element).find((ancestor) => ancestor.matches('[role="radiogroup"],fieldset'));
            if (radioRoot instanceof HTMLElement && radioRoot !== root) group = radioRoot;
            if (element instanceof HTMLInputElement && element.name)
              members = elements2.filter((other) => other instanceof HTMLInputElement && other.type === "radio" && other.name === element.name && (group ? group.contains(other) : true));
            else if (element.getAttribute("role") === "radio" && group) {
              const radioGroup = group;
              members = elements2.filter((other) => other.getAttribute("role") === "radio" && radioGroup.contains(other));
            }
            members = members.filter((member) => !seen.has(member));
          }
          for (const member of members) seen.add(member);
          const controlElement = type === "radio-group" && group?.matches('[role="radiogroup"]') ? group : element;
          const label2 = type === "radio-group" ? groupName(group) : controlName(element, group);
          if (!label2) continue;
          const optionElements = type === "select" && element instanceof HTMLSelectElement ? [...element.options] : type === "radio-group" ? members : type === "combobox" ? (() => {
            const ids = [element.getAttribute("aria-controls"), element.getAttribute("aria-owns")].filter(Boolean);
            const tree = element.getRootNode();
            const node = ids.flatMap((value2) => value2.split(/\s+/)).map((id) => tree instanceof Document || tree instanceof ShadowRoot ? tree.getElementById(id) : null).find(Boolean);
            return node ? all('[role="option"]', node) : [];
          })() : [];
          const options = optionElements.filter((option) => type === "select" ? availableOption(option) : rendered(option)).slice(0, 100).map((option) => ({
            id: this.id(option),
            label: bounded(type === "radio-group" ? optionName(option) : option instanceof HTMLOptionElement ? option.label : staticText2(option) || option.getAttribute("aria-label") || ""),
            element: option,
            disabled: isDisabled(option)
          })).filter((option) => option.label);
          const sensitivity = classify(controlElement, members, label2, group, name);
          const control = {
            id: this.id(controlElement),
            formId,
            element: controlElement,
            members,
            name: label2,
            type,
            required: members.some(isRequired) || isRequired(controlElement),
            disabled: members.every(isDisabled) || isDisabled(controlElement),
            readOnly: members.every(isReadOnly) || isReadOnly(controlElement),
            completed: completed(element, type, members),
            options,
            sensitivity,
            section: sectionName(element, root),
            supported: type !== "unsupported" && sensitivity.status === "safe" && !members.every(isDisabled) && !members.every(isReadOnly)
          };
          controls2.push(control);
          nextControls.set(control.id, control);
        }
        if (!controls2.length) continue;
        const rootShape = root instanceof HTMLFormElement ? [root.getAttribute("action") || "", root.getAttribute("method") || "", root.getAttribute("target") || ""] : [root instanceof Document ? "document" : root.getAttribute("role") || ""];
        const submitShape = submitCandidates().filter((element) => root instanceof Document ? true : root instanceof HTMLFormElement ? (element instanceof HTMLButtonElement || element instanceof HTMLInputElement) && element.form === root || element.getAttribute("role") === "button" && root.contains(element) : root.contains(element)).flatMap((element) => [
          this.id(element),
          element.getAttribute("type") || "",
          element.getAttribute("aria-label") || staticText2(element),
          element.getAttribute("formaction") || "",
          element.getAttribute("formmethod") || "",
          element.getAttribute("formtarget") || "",
          String(element.hasAttribute("formnovalidate")),
          String(isDisabled(element))
        ]);
        const signature2 = digest([formId, name, ...rootShape, ...submitShape, ...controls2.flatMap((control) => [
          control.id,
          control.name,
          control.type,
          control.section,
          this.id(sectionRoot(control.element, root) || root),
          String(control.required),
          String(control.disabled),
          String(control.readOnly),
          control.sensitivity.status,
          control.sensitivity.status === "blocked" ? control.sensitivity.reason : "",
          ...control.options.flatMap((option) => [option.id, option.label, String(option.disabled)])
        ])]);
        forms.push({ id: formId, root, name, controls: controls2, signature: signature2 });
      }
      const signature = digest([location.href, document.baseURI, ...forms.flatMap((form) => [form.id, form.signature])]);
      this.controls = nextControls;
      this.current = { documentId, signature, forms };
      return this.current;
    }
  };
  function speechKey(value2) {
    return value2.normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
  }
  var FormAssistant = class {
    model = new FormModel();
    selectedFormId = null;
    choices = [];
    choiceSignature = "";
    pending = null;
    get ownsChoices() {
      return this.choices.length > 0;
    }
    get hasPendingConfirmation() {
      return this.pending !== null;
    }
    clearChoices() {
      this.choices = [];
      this.choiceSignature = "";
    }
    result(feedback, ok = true) {
      return { ok, feedback };
    }
    signature(button) {
      return [button.tagName, button.getAttribute("type"), button.getAttribute("aria-label"), button.textContent, button.getAttribute("disabled"), button.getAttribute("aria-disabled")].join("|");
    }
    selected(inventory) {
      return this.selectedFormId ? inventory.forms.filter((form) => form.id === this.selectedFormId) : inventory.forms;
    }
    remember(inventory, choices) {
      this.choices = choices.slice(0, 10);
      this.choiceSignature = inventory.signature;
    }
    onMutation() {
      if (!this.choices.length && !this.pending) return;
      const inventory = this.model.refresh();
      if (this.choices.length && inventory.signature !== this.choiceSignature) this.clearChoices();
      if (this.pending) {
        const form = inventory.forms.find((item) => item.id === this.pending?.formId);
        if (!form || form.signature !== this.pending.signature || !this.pending.button.isConnected || this.signature(this.pending.button) !== this.pending.buttonSignature) this.pending = null;
      }
    }
    pageChanged() {
      this.model = new FormModel();
      this.selectedFormId = null;
      this.pending = null;
      this.clearChoices();
    }
    cancel() {
      this.pending = null;
      this.clearChoices();
    }
    onUserEdit() {
      this.pending = null;
    }
    formsFor(query, inventory) {
      const key = speechKey(query);
      const exact = inventory.forms.filter((form) => speechKey(form.name) === key);
      return exact.length ? exact : inventory.forms.filter((form) => speechKey(form.name).includes(key) || key.includes(speechKey(form.name)));
    }
    fieldsFor(forms, query) {
      const key = speechKey(query);
      const controls2 = forms.flatMap((form) => form.controls).filter((control) => control.supported && control.sensitivity.status === "safe");
      const exact = controls2.filter((control) => speechKey(control.name) === key);
      return exact.length ? exact : controls2.filter((control) => speechKey(control.name).includes(key) || key.includes(speechKey(control.name)));
    }
    selectForm(form) {
      this.selectedFormId = form.id;
      this.clearChoices();
      return this.result("Selected " + form.name + ".");
    }
    currentControl(inventory, id) {
      const control = this.model.control(id);
      const form = inventory.forms.find((entry) => entry.id === control?.formId);
      return form && control?.element.isConnected && control.supported && control.sensitivity.status === "safe" && !control.disabled && !control.readOnly ? control : void 0;
    }
    ambiguousFields(inventory, controls2) {
      this.remember(inventory, controls2.map((control) => ({ kind: "field", formId: control.formId, controlId: control.id })));
      const options = controls2.slice(0, 10).map((control, index) => index + 1 + ": " + control.name).join(". ");
      return this.result("Several fields match. " + options + ". Say choose followed by the number, then repeat the field command.");
    }
    setValue(element, value2) {
      const proto = element instanceof HTMLInputElement ? HTMLInputElement.prototype : element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLSelectElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (!setter) return false;
      setter.call(element, value2);
      element.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
      element.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      return element.value === value2;
    }
    write(control, value2) {
      const element = control.element;
      if (!element.isConnected || control.sensitivity.status !== "safe" || control.disabled || control.readOnly) return false;
      if (!(element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement)) return false;
      if (element instanceof HTMLInputElement && !["text", "email", "tel", "url", "number", "search", "date", "time", "datetime-local", "month", "week"].includes(element.type)) return false;
      if (element instanceof HTMLInputElement && element.type === "number" && value2 && !Number.isFinite(Number(value2))) return false;
      if (!this.setValue(element, value2)) return false;
      return !value2 || element.checkValidity();
    }
    async activateOption(control, option) {
      if (option.disabled || !option.element.isConnected || control.disabled || control.readOnly || control.sensitivity.status !== "safe") return false;
      if (control.element instanceof HTMLSelectElement && option.element instanceof HTMLOptionElement)
        return this.setValue(control.element, option.element.value) && control.element.selectedOptions[0] === option.element;
      if (control.type === "radio-group" || control.type === "combobox") {
        option.element.click();
        await new Promise((resolve) => setTimeout(resolve, 50));
        if (control.type === "radio-group")
          return option.element instanceof HTMLInputElement ? option.element.checked : option.element.getAttribute("aria-checked") === "true";
        this.model.refresh();
        const updated = this.model.control(control.id);
        const activeId = updated?.element.getAttribute("aria-activedescendant");
        const selected = option.element.getAttribute("aria-selected") === "true" || activeId === option.element.id;
        const value2 = updated?.element instanceof HTMLInputElement ? updated.element.value : updated?.element.getAttribute("aria-valuetext");
        return selected || speechKey(value2 || "") === speechKey(option.label);
      }
      return false;
    }
    async selectOption(control, query) {
      let current = control;
      let found = current.options.filter((option) => !option.disabled && speechKey(option.label) === speechKey(query));
      if (!found.length && current.type === "combobox") {
        current.element.click();
        await new Promise((resolve) => setTimeout(resolve, 100));
        this.model.refresh();
        current = this.model.control(control.id) || current;
        found = current.options.filter((option) => !option.disabled && speechKey(option.label) === speechKey(query));
      }
      return found.length === 1 ? this.activateOption(current, found[0]) : false;
    }
    submitButtons(form) {
      return all('button,input[type="submit"],input[type="image"],[role="button"]', form.root).filter((button) => rendered(button) && !isDisabled(button)).filter((button) => {
        const label2 = speechKey(button instanceof HTMLInputElement ? button.value : (button.getAttribute("aria-label") || "") + " " + staticText2(button));
        return /\b(submit|send|finish|complete|submit form|send response)\b/.test(label2) && (nativeSubmit(button) || button.getAttribute("role") === "button");
      });
    }
    invalid(control) {
      const element = control.element;
      if (element.getAttribute("aria-invalid") === "true") return true;
      return (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement || element instanceof HTMLSelectElement) && !element.validity.valid;
    }
    prepareSubmit(inventory) {
      const forms = this.selected(inventory);
      if (forms.length !== 1) {
        if (forms.length > 1) {
          this.remember(inventory, forms.map((form) => ({ kind: "form", formId: form.id })));
          return this.result("Several forms are available. " + forms.map((form, index) => index + 1 + ": " + form.name).join(". ") + ". Say choose followed by the number.");
        }
        return this.result("No supported form was found.", false);
      }
      const buttons = this.submitButtons(forms[0]);
      if (buttons.length !== 1) return this.result(buttons.length ? "Several possible submit buttons were found; I will not guess." : "No safe submit button was found.", false);
      const button = buttons[0];
      this.pending = { formId: forms[0].id, signature: forms[0].signature, button, buttonSignature: this.signature(button), url: location.href, expires: Date.now() + 15e3 };
      const incomplete = forms[0].controls.filter((field2) => field2.required && !field2.completed && field2.sensitivity.status === "safe").length;
      const blocked = forms[0].controls.filter((field2) => field2.required && (!field2.supported || field2.sensitivity.status !== "safe")).length;
      const summary = (incomplete ? incomplete + " required field" + (incomplete === 1 ? " is" : "s are") + " incomplete. " : "All visible safe required fields appear complete. ") + (blocked ? blocked + " protected or unsupported required field" + (blocked === 1 ? " needs" : "s need") + " manual review. " : "");
      return this.result("Ready to submit " + forms[0].name + ". " + summary + "Say confirm within 15 seconds, or cancel.");
    }
    async confirm() {
      const pending = this.pending;
      if (!pending) return null;
      this.pending = null;
      const inventory = this.model.refresh();
      const form = inventory.forms.find((entry) => entry.id === pending.formId);
      if (Date.now() > pending.expires || location.href !== pending.url || !form || form.signature !== pending.signature || !pending.button.isConnected || isDisabled(pending.button) || this.signature(pending.button) !== pending.buttonSignature)
        return this.result("The form changed or confirmation expired. Nothing was submitted.", false);
      pending.button.click();
      await new Promise((resolve) => setTimeout(resolve, 350));
      const submitted = /\b(response (?:has been )?recorded|successfully submitted|thank you for (?:your )?response|your response has been recorded|form submitted)\b/i.test(staticText2(document.body, 2400));
      return this.result(submitted ? "The page indicates the form was submitted." : "The submit action ran once, but I could not verify the result. I will not retry automatically.", submitted);
    }
    async handle(command) {
      if (this.pending && command.type !== "submit") this.pending = null;
      const inventory = this.model.refresh();
      if (this.choices.length && this.choiceSignature !== inventory.signature) this.clearChoices();
      if (command.type === "choose") {
        const choice = this.choices[command.index - 1];
        this.clearChoices();
        if (!choice) return this.result("That form choice expired. List the forms or fields again.", false);
        if (choice.kind === "form") {
          const form = inventory.forms.find((item) => item.id === choice.formId);
          return form ? this.selectForm(form) : this.result("That form is no longer available.", false);
        }
        const field3 = this.currentControl(inventory, choice.controlId);
        if (!field3) return this.result("That field is no longer available or safe to edit.", false);
        if (choice.kind === "option") {
          const option = field3.options.find((item) => item.id === choice.optionId);
          if (!option || option.disabled) return this.result("That option is no longer available.", false);
          const ok = await this.activateOption(field3, option);
          return this.result(ok ? "Selected " + option.label + " for " + field3.name + "." : "That option could not be selected safely.", ok);
        }
        this.selectedFormId = field3.formId;
        return this.result("Selected " + field3.name + ". Repeat the command for this field.");
      }
      if (command.type === "list-forms" || command.type === "select-form") {
        const forms2 = command.type === "list-forms" ? inventory.forms : "index" in command ? [inventory.forms[command.index - 1]].filter((form) => !!form) : this.formsFor(command.query, inventory);
        if (!forms2.length) return this.result("No matching supported form was found.", false);
        if (forms2.length === 1) return this.selectForm(forms2[0]);
        this.remember(inventory, forms2.map((form) => ({ kind: "form", formId: form.id })));
        return this.result("Forms: " + forms2.map((form, index) => index + 1 + ": " + form.name).join(". ") + ". Say choose followed by the number.");
      }
      if (command.type === "submit") return this.prepareSubmit(inventory);
      if (["list-fields", "list-required", "missing", "review"].includes(command.type)) {
        const forms2 = this.selected(inventory);
        if (forms2.length !== 1) return this.result(forms2.length ? "Select one form first." : "No supported form was found. Sensitive and unclear fields are excluded.", false);
        const safe = forms2[0].controls.filter((field3) => field3.supported && field3.sensitivity.status === "safe");
        const list = command.type === "list-required" ? safe.filter((field3) => field3.required) : command.type === "missing" ? safe.filter((field3) => field3.required && !field3.completed || this.invalid(field3)) : safe;
        if (!list.length) return this.result(command.type === "missing" ? "No required fields appear to be missing." : "No matching safe fields were found.");
        this.remember(inventory, list.map((field3) => ({ kind: "field", formId: field3.formId, controlId: field3.id })));
        return this.result((command.type === "missing" ? "Missing or invalid fields: " : command.type === "review" ? "Form review: " : "") + list.map((field3, index) => index + 1 + ": " + field3.name + " (" + field3.type + ")" + (field3.required ? " (required)" : "") + (this.invalid(field3) ? " (invalid)" : field3.completed ? " (filled)" : command.type === "review" ? " (empty)" : command.type === "missing" ? " (missing)" : "")).join(". ") + ".");
      }
      if (command.type === "next-section" || command.type === "previous-section") {
        const forms2 = this.selected(inventory);
        if (forms2.length !== 1) return this.result("Select one form before moving sections.", false);
        const names = command.type === "next-section" ? ["next", "continue", "next section"] : ["previous", "back", "previous section"];
        const buttons = all('button,[role="button"],input[type="button"],input[type="submit"]', forms2[0].root).filter((button) => rendered(button) && !isDisabled(button)).filter((button) => names.includes(speechKey(button instanceof HTMLInputElement ? button.value : (button.getAttribute("aria-label") || "") + " " + staticText2(button))));
        if (buttons.length !== 1) return this.result(buttons.length ? "Several section controls match; I will not guess." : "No matching section control was found.", false);
        buttons[0].click();
        this.clearChoices();
        await new Promise((resolve) => setTimeout(resolve, 150));
        this.model.refresh();
        return this.result("Section control activated. Review the displayed section before continuing.");
      }
      if (!("query" in command)) return this.result("That form command is unsupported.", false);
      const forms = this.selected(inventory);
      if (!forms.length) return this.result("No supported form was found. Sensitive and unclear fields are excluded.", false);
      const fields = this.fieldsFor(forms, command.query);
      if (!fields.length) return this.result("No safe, clearly labelled field matched that name.", false);
      if (fields.length > 1) return this.ambiguousFields(inventory, fields);
      const field2 = this.currentControl(inventory, fields[0].id);
      if (!field2) return this.result("That field is disabled, read-only, sensitive, or unavailable.", false);
      this.clearChoices();
      if (command.type === "dictate") {
        field2.element.focus({ preventScroll: true });
        this.selectedFormId = field2.formId;
        return { ...this.result("Ready to dictate into " + field2.name + ". Say stop typing to finish."), dictationTarget: field2.element, dictating: true };
      }
      if (command.type === "select-option") {
        const matches = field2.options.filter((option) => !option.disabled && speechKey(option.label) === speechKey(command.option));
        if (matches.length > 1) {
          this.remember(inventory, matches.map((option) => ({ kind: "option", formId: field2.formId, controlId: field2.id, optionId: option.id })));
          return this.result("Several options match " + field2.name + ". " + matches.map((option, index) => index + 1 + ": " + option.label).join(". ") + ". Say choose followed by the number.");
        }
        if (!matches.length && field2.type !== "combobox") return this.result("That exact option was not found.", false);
        const ok = await this.selectOption(field2, command.option);
        return this.result(ok ? "Selected " + command.option + " for " + field2.name + "." : "That field type could not select and verify the requested option.", ok);
      }
      if (command.type === "check" || command.type === "uncheck") {
        if (field2.type !== "checkbox") return this.result(field2.name + " is not a checkbox.", false);
        const element = field2.element;
        const desired = command.type === "check";
        const checked = element instanceof HTMLInputElement ? element.checked : element.getAttribute("aria-checked") === "true";
        if (checked !== desired) element.click();
        const result2 = element instanceof HTMLInputElement ? element.checked : element.getAttribute("aria-checked") === "true";
        return this.result(result2 === desired ? (desired ? "Checked " : "Unchecked ") + field2.name + "." : "Could not verify " + field2.name + ".", result2 === desired);
      }
      if (command.type === "fill" || command.type === "change" || command.type === "clear") {
        const ok = this.write(field2, command.type === "clear" ? "" : command.value);
        return this.result(ok ? (command.type === "clear" ? "Cleared " : "Filled ") + field2.name + "." : "Could not safely set " + field2.name + "; check its format and constraints.", ok);
      }
      return this.result("That form command is unsupported.", false);
    }
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/content/runtime.ts
  var ContentRuntime = class {
    constructor(send, clock = () => performance.now(), autoTick = true) {
      this.send = send;
      this.clock = clock;
      this.autoTick = autoTick;
      this.observer = new MutationObserver(() => {
        this.forms.onMutation();
        if (this.pending && (!this.pending.target.isConnected || !this.pending.form.isConnected || sensitive(this.pending.target) || this.formSignature(this.pending.target, this.pending.form) !== this.pending.signature))
          this.cancelPending("The form changed. Submission cancelled.");
        if (this.typingTarget && (!this.typingTarget.isConnected || !editable(this.typingTarget)))
          this.stopTyping("The text field is no longer available.");
      });
      this.observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: [
          "disabled",
          "readonly",
          "type",
          "autocomplete",
          "name",
          "action",
          "method",
          "formaction",
          "formmethod",
          "aria-label",
          "aria-labelledby",
          "aria-describedby",
          "aria-required",
          "aria-readonly",
          "aria-disabled",
          "aria-checked",
          "aria-controls",
          "aria-owns"
        ]
      });
      addEventListener("popstate", this.pageChanged);
      addEventListener("hashchange", this.pageChanged);
      addEventListener("keydown", this.onKey);
      addEventListener("scroll", this.onScroll, { passive: true });
      document.addEventListener("submit", this.onSubmit, true);
      document.addEventListener("focusin", this.onFocus, true);
      document.addEventListener("input", this.onFormEdit, true);
      document.addEventListener("change", this.onFormEdit, true);
      if (this.autoTick) this.frame = requestAnimationFrame(this.loop);
    }
    send;
    clock;
    autoTick;
    targets = new PageTargets();
    overlay = new Overlay();
    gate = new ActivationGate({
      dwellMs: defaults.dwellMs,
      confidenceThreshold: defaults.confidenceThreshold
    });
    settings = { ...defaults };
    running = false;
    paused = false;
    dictating = false;
    sites = new SiteExecutor(void 0, () => Date.now(), () => this.settings.testWriteTargets.some((prefix) => location.href.replace(/\/$/, "") === prefix.replace(/\/$/, "") || location.href.startsWith(prefix.replace(/\/$/, "") + "/")), (site, recipients2) => recipients2.length > 0 && recipients2.every((recipient) => this.settings.testMessageRecipients.includes(`${site}:${recipient}`.toLowerCase())));
    typingTarget = null;
    forms = new FormAssistant();
    target = null;
    pointerTarget = false;
    pending = null;
    choices = [];
    choiceDisposition;
    selectedDisposition;
    choiceSnapshots = /* @__PURE__ */ new Map();
    selectedSnapshot = null;
    preparedLink = null;
    sample = null;
    receivedAt = 0;
    x = 0;
    y = 0;
    edge = null;
    edgeSince = 0;
    edgeLast = 0;
    scrollMotion = new ScrollMotion();
    frame = 0;
    activationTarget = null;
    confirmedSubmission = false;
    destroyed = false;
    observer;
    feedback(text) {
      this.overlay.announce(text);
      void this.send({ type: "SET_STATE", patch: { feedback: text } }).catch(
        () => {
        }
      );
    }
    metric(type, detail) {
      void this.send({
        type: "METRIC",
        event: { type, detail, at: Date.now() }
      }).catch(() => {
      });
    }
    selectionSignature(element) {
      const href = element.getAttribute("href");
      let destination2 = null;
      if (href !== null) {
        try {
          destination2 = new URL(href, document.baseURI).href;
        } catch {
        }
      }
      return [location.href, targetLabel(element), href, destination2, element.getAttribute("role"), element.getAttribute("type")].join("|");
    }
    rememberChoices() {
      this.choiceSnapshots = new Map(this.choices.map((element) => [element, this.selectionSignature(element)]));
    }
    pageChanged = () => {
      this.sites.invalidate();
      this.forms.pageChanged();
      this.scrollMotion.cancel();
      this.edge = null;
      this.cancelPending("The page changed. Submission cancelled.");
      this.select(null);
      this.stopTyping();
      this.choices = [];
      this.choiceDisposition = void 0;
      this.selectedDisposition = void 0;
      this.overlay.options([]);
    };
    onScroll = () => {
      this.overlay.target(this.target);
      this.overlay.options(this.choices);
    };
    onKey = (event) => {
      if (event.key === "Escape" && this.running) {
        this.paused = true;
        this.scrollMotion.cancel();
        this.edge = null;
        this.stopTyping();
        this.cancelPending();
        this.gate.update({
          targetId: this.target ? this.targets.id(this.target) : null,
          confidence: 0,
          tracking: false,
          paused: true,
          now: this.clock()
        });
        void this.send({ type: "PAUSE" }).catch(() => {
        });
        this.feedback("Handsfree paused. Resume from the controller.");
      }
    };
    onFocus = (event) => {
      if (this.dictating && this.typingTarget && event.target instanceof Node && event.target !== this.typingTarget && !this.typingTarget.contains(event.target))
        this.stopTyping("Focus changed. Dictation stopped.");
    };
    onFormEdit = (event) => {
      if (event.target instanceof HTMLElement && event.target.matches('input,textarea,select,[role="combobox"],[role="radio"],[role="checkbox"]')) {
        this.forms.onUserEdit();
        if (this.pending) this.cancelPending("The form changed. Submission cancelled.");
      }
    };
    onSubmit = (event) => {
      if (!this.activationTarget || this.confirmedSubmission || !(event.target instanceof HTMLFormElement))
        return;
      event.preventDefault();
      event.stopImmediatePropagation();
      const target = this.activationTarget;
      this.pending = {
        target,
        form: event.target,
        method: "click",
        expires: this.clock() + 1e4,
        url: location.href,
        signature: this.formSignature(target, event.target)
      };
      this.feedback(
        "This action submits a form. Say confirm within 10 seconds, or cancel."
      );
    };
    loop = () => {
      this.tick();
      if (!this.destroyed) this.frame = requestAnimationFrame(this.loop);
    };
    cancelPending(message) {
      if (this.pending) {
        this.pending = null;
        if (message) this.feedback(message);
      }
    }
    formSignature(element, form) {
      return [
        form.action,
        form.method,
        element.getAttribute("formaction"),
        element.getAttribute("formmethod")
      ].join("|");
    }
    select(element, fromPointer) {
      if (fromPointer) this.selectedDisposition = void 0;
      if (element !== this.target) {
        this.cancelPending("The target changed. Submission cancelled.");
        this.target = element;
        this.pointerTarget = fromPointer ?? false;
      } else if (fromPointer !== void 0) this.pointerTarget = fromPointer;
      this.selectedSnapshot = element && !this.pointerTarget ? this.selectionSignature(element) : null;
      this.preparedLink = null;
      this.overlay.target(element);
    }
    tick() {
      const now = this.clock();
      if (this.pending && (now > this.pending.expires || location.href !== this.pending.url))
        this.cancelPending("Confirmation expired. Ask to submit again.");
      const tracked = !!this.sample && now - this.receivedAt < 650;
      const confident = tracked && this.sample.confidence >= this.settings.confidenceThreshold;
      const blocked = !this.running || this.paused || this.dictating || !!this.pending || this.choices.length > 0;
      const result2 = this.gate.update({
        targetId: this.target && this.pointerTarget ? this.targets.id(this.target) : null,
        confidence: this.sample?.confidence ?? 0,
        paused: blocked,
        tracking: tracked,
        now,
        activate: !this.settings.dwellEnabled && this.sample?.handHold ? "hand" : "dwell",
        handHold: !this.settings.dwellEnabled && (this.sample?.handHold ?? false),
        dwellEnabled: this.settings.dwellEnabled
      });
      this.overlay.pointer(
        this.x,
        this.y,
        this.running && !!this.sample,
        blocked ? 0 : result2.progress
      );
      if (result2.activate && this.target && usable(this.target))
        this.activate(this.target, "pointer");
      if (!blocked && confident && this.settings.edgeScroll && !this.scrollMotion.active && !this.choices.length) {
        const direction = this.y < 38 ? "up" : this.y > innerHeight - 38 ? "down" : null;
        if (direction !== this.edge) {
          this.edge = direction;
          this.edgeSince = now;
          this.edgeLast = now;
        }
        if (direction && now - this.edgeSince >= 900) {
          this.scrollMotion.cancel();
          const elapsed = Math.max(0, Math.min(50, now - Math.max(this.edgeLast, this.edgeSince + 900)));
          const speed = Math.max(200, innerHeight * 0.55) * this.settings.scrollSensitivity;
          scrollPixels((direction === "down" ? 1 : -1) * speed * elapsed / 1e3, document.elementFromPoint(this.x, this.y));
          this.edgeLast = now;
        }
      } else {
        this.edge = null;
        this.edgeSince = now;
      }
      if (blocked) this.scrollMotion.cancel();
      else this.scrollMotion.tick(now);
    }
    scroll(direction) {
      this.edge = null;
      const origin2 = this.target || document.elementFromPoint(this.x, this.y) || document.activeElement;
      if (direction === "top" || direction === "bottom") {
        this.scrollMotion.cancel();
        scrollPixels((direction === "bottom" ? 1 : -1) * Math.max(document.documentElement.scrollHeight, document.body.scrollHeight, 1e7), origin2);
        this.metric("scroll", direction);
        return;
      }
      this.scrollMotion.command(
        (direction === "down" ? 1 : -1) * Math.max(200, innerHeight * 0.65) * this.settings.scrollSensitivity,
        origin2,
        this.clock()
      );
      this.metric("scroll", direction);
    }
    async handle(message) {
      switch (message.type) {
        case "GET_SITE_CONTEXT":
          return this.sites.snapshot();
        case "SITE_DIALOGUE": {
          if (!this.running || this.paused || this.dictating) return null;
          const result2 = await this.sites.dialogue(message.text);
          if (result2) this.feedback(result2.feedback);
          return result2;
        }
        case "PAGE_STATE": {
          const wasRunning = this.running;
          if (this.settings.pointerMode !== message.settings.pointerMode || this.settings.voiceOnly !== message.settings.voiceOnly || JSON.stringify(this.settings.enabledInputs) !== JSON.stringify(message.settings.enabledInputs)) {
            this.gate.reset();
            this.sample = null;
            this.select(null);
            this.edge = null;
            this.scrollMotion.cancel();
            this.cancelPending();
            this.sites.invalidate();
          }
          this.running = message.running;
          this.paused = message.paused;
          if (this.settings.dwellMs !== message.settings.dwellMs || this.settings.confidenceThreshold !== message.settings.confidenceThreshold)
            this.gate.configure({
              dwellMs: message.settings.dwellMs,
              confidenceThreshold: message.settings.confidenceThreshold
            });
          this.settings = message.settings;
          this.overlay.style(this.settings.cursorStyle);
          if (!this.running || this.paused) {
            this.sites.invalidate();
            this.forms.cancel();
            this.cancelPending();
            this.stopTyping();
            this.edge = null;
            this.scrollMotion.cancel();
            if (!this.running) this.gate.reset();
            else
              this.gate.update({
                targetId: this.target ? this.targets.id(this.target) : null,
                confidence: 0,
                tracking: false,
                paused: true,
                now: this.clock()
              });
          } else if (!message.dictating && this.dictating) this.stopTyping();
          if (!this.running) {
            this.select(null);
            this.sample = null;
            this.overlay.pointer(0, 0, false);
            this.overlay.options([]);
            this.choices = [];
            this.choiceDisposition = void 0;
            this.selectedDisposition = void 0;
            this.overlay.announce("");
            this.overlay.transcript("", false, false);
          } else if (!wasRunning)
            this.feedback(
              "Handsfree is ready. Point at a target or say find followed by its name."
            );
          if (this.paused) this.overlay.transcript("", false, false);
          return { ok: true };
        }
        case "POINTER": {
          const sample = message.sample;
          if (!Number.isFinite(sample.x) || !Number.isFinite(sample.y) || !Number.isFinite(sample.confidence))
            return { ok: false };
          this.sample = sample;
          this.receivedAt = this.clock();
          if (this.running && !this.paused && !this.dictating && sample.confidence >= this.settings.confidenceThreshold) {
            this.x = Math.max(0, Math.min(1, sample.x)) * innerWidth;
            this.y = Math.max(0, Math.min(1, sample.y)) * innerHeight;
            if (!this.choices.length)
              this.select(this.targets.snap(this.x, this.y, this.target), true);
          }
          this.tick();
          return { ok: true };
        }
        case "GET_PAGE_CONTEXT":
          return pageContext();
        case "ANSWER":
          if (!this.running || this.paused || typeof message.text !== "string" || message.text.length > 6e3) return { ok: false };
          this.feedback(message.text);
          return { ok: true };
        case "GET_TARGETS":
          return this.targets.scan();
        case "TRANSCRIPT":
          this.overlay.transcript(message.text, message.final, this.running && !this.paused);
          return { ok: true };
        case "FIND_RESULT": {
          if (!this.running || this.paused) return { ok: false };
          const matches = [...new Set(message.ids)].map((id) => this.targets.get(id)).filter((item) => !!item);
          this.cancelPending();
          this.gate.reset();
          if (!matches.length) {
            this.select(null);
            this.choices = [];
            this.choiceDisposition = void 0;
            this.overlay.options([]);
            this.feedback("No matching target found on this page.");
            return { ok: true };
          }
          if (matches.length > 1) {
            this.choiceDisposition = message.disposition;
            this.select(null);
            this.choices = matches.slice(0, 10);
            this.rememberChoices();
            this.choices[0].scrollIntoView({
              block: "center",
              behavior: "instant"
            });
            this.overlay.options(this.choices);
            this.feedback(
              `Several targets match. ${this.choices.map((target, index) => `${index + 1}: ${targetLabel(target)}`).join(". ")}. Say choose followed by the number.`
            );
          } else {
            this.choices = [];
            this.choiceDisposition = void 0;
            this.overlay.options([]);
            matches[0].scrollIntoView({ block: "center", behavior: "instant" });
            this.select(matches[0], false);
            this.feedback(
              `Found ${targetLabel(matches[0])}. Say click this to activate.`
            );
          }
          return { ok: true };
        }
        case "VALIDATE_LINK": {
          const link = this.preparedLink;
          return { ok: !!link && this.running && !this.paused && !this.dictating && message.id === link.id && message.url === link.url && message.pageUrl === location.href && message.pageUrl === link.pageUrl && !!this.target && this.targets.get(link.id) === this.target && this.selectedSnapshot === this.selectionSignature(this.target) && linkUrl(this.target) === message.url && voiceExposed(this.target) };
        }
        case "PAGE_ACTION": {
          if (message.intent.type === "confirm" && this.running && !this.paused && !this.dictating) {
            const result2 = await this.sites.dialogue("confirm");
            if (result2) {
              this.feedback(result2.feedback);
              return result2;
            }
            const formResult = await this.forms.confirm();
            if (formResult) {
              this.feedback(formResult.feedback);
              return formResult;
            }
          }
          if (message.intent.type === "form-command") {
            if (!this.running || this.paused || this.dictating) return { ok: false, error: "Resume Handsfree before using form commands." };
            if (this.sites.snapshot()?.site) {
              const result3 = { ok: false, feedback: "Use the site's dedicated commands here; generic form controls are disabled on supported sites." };
              this.feedback(result3.feedback);
              return result3;
            }
            this.cancelPending("Previous form confirmation cancelled.");
            if (message.intent.command.type === "choose" && !this.forms.ownsChoices) {
              const ok2 = this.action({ type: "choose", index: message.intent.command.index });
              return { ok: ok2, dictating: this.dictating };
            }
            const result2 = await this.forms.handle(message.intent.command);
            if (result2.dictationTarget) {
              const element = result2.dictationTarget;
              if (!element.isConnected || !editable(element)) return { ok: false, error: "That field is no longer available for dictation." };
              this.cancelPending();
              this.typingTarget = element;
              this.dictating = true;
              element.focus({ preventScroll: true });
              this.select(element);
              this.gate.reset();
              void this.send({ type: "SET_STATE", patch: { dictating: true } }).catch(() => {
              });
            }
            this.feedback(result2.feedback);
            return { ...result2, dictating: this.dictating };
          }
          if (message.intent.type === "site-action") {
            if (!this.running || this.paused || this.dictating) return { state: "unavailable", feedback: "Resume Handsfree before using page commands." };
            const result2 = await this.sites.run(message.intent);
            if (result2.focusField) this.action({ type: "start-typing" });
            this.feedback(result2.feedback);
            return { ...result2, dictating: this.dictating };
          }
          if (message.intent.type === "cancel") this.sites.cancel();
          if (message.intent.type.startsWith("media-")) {
            if (!this.running || this.paused || this.dictating) return { ok: false };
            const result2 = await mediaControl(message.intent);
            this.feedback(result2.error || "Player updated.");
            return result2;
          }
          this.preparedLink = null;
          const ok = this.action(message.intent);
          const linkDisposition = this.preparedLink ? this.selectedDisposition : void 0;
          const response = { ok, dictating: this.dictating, ...this.preparedLink ? { link: this.preparedLink } : {}, ...linkDisposition ? { disposition: linkDisposition } : {} };
          if (this.preparedLink && linkDisposition) this.selectedDisposition = void 0;
          return response;
        }
        case "AGENT_ACTION": {
          if (!this.running || this.paused || this.dictating || !this.voiceAllowed())
            return { ok: false, error: "Handsfree is paused or voice control is unavailable." };
          const action = message.action;
          if (action.type === "scroll") {
            this.scroll(action.direction);
            return { ok: true, changed: true };
          }
          if (action.type === "media") {
            const result2 = await mediaControl({ type: action.command === "play" ? "media-play" : "media-pause" });
            return { ok: result2.found, changed: result2.found, error: result2.error };
          }
          const element = this.targets.get(action.targetId);
          if (!element || !voiceExposed(element)) return { ok: false, error: "That page control is no longer visible. I will inspect the page again." };
          if (action.type === "click") {
            if (element.matches('button,[role="button"],input[type="button"]') && /\b(send|post|delete|remove|buy|purchase|pay|checkout|confirm|publish|transfer|place order)\b/i.test(targetLabel(element)))
              return { ok: false, error: "I will not activate a control that may send, publish, delete, or purchase something." };
            const ok = this.activate(element, "voice");
            return { ok, changed: ok, error: ok ? void 0 : "That control could not be activated safely." };
          }
          if (!(element instanceof HTMLInputElement) || !["search", "text"].includes(element.type) && element.getAttribute("role") !== "searchbox")
            return { ok: false, error: "Search can only use a visible search field." };
          const form = formFor(element);
          if (!form || (form.method || "get").toLowerCase() !== "get")
            return { ok: false, error: "That search field does not use a safe GET search form." };
          let destination2;
          try {
            destination2 = new URL(form.action || location.href, location.href);
          } catch {
            return { ok: false, error: "That search form has an invalid destination." };
          }
          if (destination2.origin !== location.origin || !/^https?:$/.test(destination2.protocol))
            return { ok: false, error: "That search form leads outside this site." };
          const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
          setter?.call(element, action.query);
          element.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: action.query }));
          element.dispatchEvent(new Event("change", { bubbles: true }));
          form.requestSubmit();
          return { ok: true, changed: true };
        }
        case "DICTATE": {
          if (!this.running || this.paused || !this.dictating || !this.typingTarget)
            return { ok: false };
          if (document.activeElement !== this.typingTarget && !this.typingTarget.contains(document.activeElement)) {
            this.stopTyping("Focus changed. Dictation stopped.");
            return { ok: false };
          }
          const success = insertText(this.typingTarget, message.text);
          if (!success) this.stopTyping("This field cannot accept dictation.");
          else this.metric("dictation-insert");
          return { ok: success };
        }
        default:
          return { ok: false };
      }
    }
    voiceAllowed() {
      if (!this.running || this.paused) {
        this.feedback("Handsfree is paused. Resume before using page commands.");
        return false;
      }
      const tracking = !this.pointerTarget || !!this.sample && this.clock() - this.receivedAt < 650;
      const confidence = this.pointerTarget ? this.sample?.confidence ?? 0 : 1;
      const voiceGate = new ActivationGate({
        dwellMs: this.settings.dwellMs,
        confidenceThreshold: this.settings.confidenceThreshold
      });
      const result2 = voiceGate.update({
        targetId: this.target ? this.targets.id(this.target) : "voice-page-action",
        confidence,
        paused: false,
        tracking,
        now: this.clock(),
        activate: "voice"
      });
      if (!result2.activate)
        this.feedback(
          "Tracking is uncertain. Move back into view before activating a target."
        );
      return result2.activate;
    }
    action(intent) {
      if (intent.type === "cancel") {
        this.forms.cancel();
        this.cancelPending();
        this.choices = [];
        this.choiceDisposition = void 0;
        this.selectedDisposition = void 0;
        this.overlay.options([]);
        this.feedback("Cancelled.");
        return true;
      }
      if (intent.type === "stop-typing") {
        this.stopTyping("Dictation stopped.");
        return true;
      }
      if (!this.running || this.paused) return false;
      if (this.sites.snapshot()?.site && (intent.type === "submit" || intent.type === "confirm" && this.pending)) {
        this.cancelPending();
        this.feedback("Use a dedicated site submission command. Generic form confirmation cannot publish content on this site.");
        return false;
      }
      if (this.dictating && ["click-link", "click-target", "focus-target", "show-links", "choose"].includes(intent.type)) return false;
      if (intent.type === "confirm") {
        const pending = this.pending;
        if (!pending || this.clock() > pending.expires || location.href !== pending.url || pending.target !== this.target || !pending.target.isConnected || !pending.form.isConnected || !usable(pending.target) || sensitive(pending.target) || this.selectedSnapshot !== null && (this.selectedSnapshot !== this.selectionSignature(pending.target) || !voiceExposed(pending.target)) || this.formSignature(pending.target, pending.form) !== pending.signature) {
          this.cancelPending();
          this.feedback("Nothing is waiting for confirmation.");
          return false;
        }
        if (!this.voiceAllowed()) return false;
        this.pending = null;
        this.stopTyping();
        this.metric("submit-confirmed");
        this.confirmedSubmission = true;
        try {
          if (pending.method === "click") pending.target.click();
          else pending.form.requestSubmit();
        } finally {
          this.confirmedSubmission = false;
        }
        this.feedback("Submission confirmed.");
        return true;
      }
      if (intent.type === "choose") {
        const choice = this.choices[intent.index - 1];
        if (!choice || !choice.isConnected || !voiceUsable(choice) || this.choiceSnapshots.get(choice) !== this.selectionSignature(choice)) {
          this.feedback(
            "That option is not available. Say choose followed by a listed number."
          );
          return false;
        }
        this.choices = [];
        this.selectedDisposition = this.choiceDisposition;
        this.choiceDisposition = void 0;
        this.overlay.options([]);
        choice.scrollIntoView({ block: "center", behavior: "instant" });
        this.select(choice, false);
        this.gate.reset();
        this.feedback(
          `Selected ${targetLabel(choice)}. Say click this to activate.`
        );
        return true;
      }
      if (intent.type === "show-links") {
        this.choiceDisposition = void 0;
        this.selectedDisposition = void 0;
        this.choices = this.targets.links().slice(0, 10).map((id) => this.targets.get(id)).filter((element) => !!element);
        this.select(null);
        this.cancelPending();
        this.rememberChoices();
        this.overlay.options(this.choices);
        this.feedback(this.choices.length ? `Links: ${this.choices.map((element, index) => `${index + 1}: ${targetLabel(element)}`).join(". ")}. Say choose followed by a number, then click this.` : "No links found on this page.");
        return true;
      }
      if (intent.type === "click-target" || intent.type === "click-link" || intent.type === "focus-target") {
        const ids = intent.type === "click-link" ? this.targets.links().slice(intent.index - 1, intent.index) : intent.type === "focus-target" ? this.targets.fields(intent.query) : this.targets.named(intent.query);
        if (ids.length !== 1) {
          void this.handle({ type: "FIND_RESULT", ids, disposition: intent.type === "focus-target" ? void 0 : intent.disposition });
          return true;
        }
        const target = this.targets.get(ids[0]);
        if (!target) return false;
        this.choices = [];
        this.choiceDisposition = void 0;
        this.selectedDisposition = intent.type === "focus-target" ? void 0 : intent.disposition;
        this.overlay.options([]);
        this.select(target, false);
        target.scrollIntoView({ block: "center", behavior: "instant" });
        if (!voiceExposed(target) || !this.voiceAllowed()) {
          this.feedback("That target is covered or unavailable.");
          return false;
        }
        if (intent.type === "focus-target") {
          if (!editable(target)) return false;
          target.focus({ preventScroll: true });
          this.feedback(`Focused ${targetLabel(target)}.`);
          return true;
        }
        if (intent.disposition) {
          const url = linkUrl(target);
          if (!url || !target.matches('a[href],[role="link"]')) {
            this.feedback("Only HTTP or HTTPS links can open in another tab.");
            return false;
          }
          this.preparedLink = { id: this.targets.id(target), url, pageUrl: location.href };
          return true;
        }
        return this.activate(target, "voice");
      }
      if (intent.type === "scroll") {
        this.cancelPending();
        this.scroll(intent.direction);
        return true;
      }
      if (intent.type === "back" || intent.type === "forward") {
        this.pageChanged();
        intent.type === "back" ? history.back() : history.forward();
        return true;
      }
      if (intent.type === "start-typing") {
        const element = this.target ? editable(this.target) ? this.target : null : document.activeElement instanceof HTMLElement && editable(document.activeElement) ? document.activeElement : null;
        if (!element) {
          this.feedback(
            "Point at an editable text field first. Password and payment fields are blocked."
          );
          return false;
        }
        if (!this.voiceAllowed()) return false;
        this.cancelPending();
        this.typingTarget = element;
        element.focus({ preventScroll: true });
        this.select(element);
        this.dictating = true;
        this.gate.reset();
        void this.send({ type: "SET_STATE", patch: { dictating: true } }).catch(
          () => {
          }
        );
        this.feedback(
          "Dictation is on. Say stop typing to finish. Submission always needs a separate confirmation."
        );
        return true;
      }
      if (intent.type === "submit") {
        const element = this.typingTarget || this.target || (document.activeElement instanceof HTMLElement ? document.activeElement : null);
        const form = formFor(element);
        if (!element || !form || sensitive(element)) {
          this.feedback("Select a form field before asking to submit.");
          return false;
        }
        if (!this.voiceAllowed()) return false;
        this.select(element);
        this.pending = {
          target: element,
          form,
          method: "submit",
          expires: this.clock() + 1e4,
          url: location.href,
          signature: this.formSignature(element, form)
        };
        this.stopTyping();
        this.feedback(
          "Ready to submit this form. Say confirm within 10 seconds, or cancel."
        );
        return true;
      }
      if (intent.type === "click" || intent.type === "open") {
        if ((!this.target || this.pointerTarget) && this.sample) {
          if (this.clock() - this.receivedAt >= 650 || this.sample.confidence < this.settings.confidenceThreshold) {
            this.feedback("Tracking is uncertain. Move back into view before clicking.");
            return false;
          }
          let hit = document.elementFromPoint(this.x, this.y);
          let localX = this.x, localY = this.y;
          while (hit) {
            const nested = hit.shadowRoot?.elementFromPoint?.(localX, localY);
            if (nested && nested !== hit) {
              hit = nested;
              continue;
            }
            if (hit instanceof HTMLIFrameElement) {
              try {
                const box = hit.getBoundingClientRect();
                const nestedHit = hit.contentDocument?.elementFromPoint(localX - box.left, localY - box.top);
                if (nestedHit) {
                  localX -= box.left;
                  localY -= box.top;
                  hit = nestedHit;
                  continue;
                }
              } catch {
              }
            }
            break;
          }
          const element = hit?.closest('a[href],button,input,textarea,select,[contenteditable],[role="button"],[role="link"]') || hit;
          if (element instanceof HTMLElement && usable(element)) {
            if (element instanceof HTMLIFrameElement) {
              this.feedback("Use play video, pause video, forward ten seconds or rewind for this embedded player.");
              return false;
            }
            this.select(element, true);
            this.choices = [];
            this.overlay.options([]);
            if (!this.voiceAllowed()) return false;
            return this.activate(element, "voice", { x: localX, y: localY });
          }
          this.feedback("No available click area at the cursor position.");
          return false;
        }
        if (!this.target && document.activeElement instanceof HTMLElement && document.activeElement.matches(
          'a[href],button,input,textarea,[contenteditable="true"]'
        ) && usable(document.activeElement))
          this.select(document.activeElement);
        if (!this.target) {
          this.feedback(
            "No target selected. Point at a link, button, or field, or use find."
          );
          return false;
        }
        if (this.selectedSnapshot && (this.selectedSnapshot !== this.selectionSignature(this.target) || !voiceExposed(this.target))) {
          this.select(null);
          this.feedback("The selected target changed. Select it again.");
          return false;
        }
        if (!this.voiceAllowed()) return false;
        if (this.selectedDisposition) {
          const url = linkUrl(this.target);
          if (!url || !this.target.matches('a[href],[role="link"]')) {
            this.feedback("Only HTTP or HTTPS links can open in another tab.");
            return false;
          }
          this.preparedLink = { id: this.targets.id(this.target), url, pageUrl: location.href };
          return true;
        }
        return this.activate(this.target, "voice");
      }
      return false;
    }
    activate(element, source, point) {
      if (!element.isConnected || !usable(element) || sensitive(element)) {
        this.feedback("That target is unavailable or sensitive.");
        return false;
      }
      const siteGuard = this.sites.guardActivation(element);
      if (siteGuard === "blocked") {
        this.feedback("This account action requires a supported site command and explicit confirmation. It was not activated.");
        return false;
      }
      if (siteGuard) {
        void this.sites.run(siteGuard).then((result2) => this.feedback(result2.feedback));
        return false;
      }
      if (submitControl(element)) {
        const form = formFor(element);
        this.pending = {
          target: element,
          form,
          method: "click",
          expires: this.clock() + 1e4,
          url: location.href,
          signature: this.formSignature(element, form)
        };
        this.feedback(
          "This button submits a form. Say confirm within 10 seconds, or cancel."
        );
        return true;
      }
      if (editable(element)) element.focus({ preventScroll: true });
      else {
        this.activationTarget = element;
        try {
          if (point) {
            const options = { bubbles: true, cancelable: true, composed: true, clientX: point.x, clientY: point.y, button: 0 };
            for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
              const event = type.startsWith("pointer") && typeof PointerEvent !== "undefined" ? new PointerEvent(type, { ...options, pointerId: 1, pointerType: "mouse", isPrimary: true, buttons: type === "pointerdown" ? 1 : 0 }) : new MouseEvent(type, { ...options, buttons: type === "mousedown" ? 1 : 0 });
              element.dispatchEvent(event);
            }
          } else element.click();
        } finally {
          this.activationTarget = null;
        }
      }
      this.metric("activation", source);
      if (!this.pending) this.feedback(`Selected ${targetLabel(element)}.`);
      return true;
    }
    stopTyping(message) {
      if (!this.dictating && !this.typingTarget) return;
      this.dictating = false;
      this.typingTarget = null;
      this.gate.reset();
      void this.send({ type: "SET_STATE", patch: { dictating: false } }).catch(
        () => {
        }
      );
      if (message) this.feedback(message);
    }
    destroy() {
      this.sites.invalidate();
      this.scrollMotion.cancel();
      this.targets.destroy();
      this.destroyed = true;
      cancelAnimationFrame(this.frame);
      this.observer.disconnect();
      this.overlay.destroy();
      removeEventListener("popstate", this.pageChanged);
      removeEventListener("hashchange", this.pageChanged);
      removeEventListener("keydown", this.onKey);
      removeEventListener("scroll", this.onScroll);
      document.removeEventListener("submit", this.onSubmit, true);
      document.removeEventListener("focusin", this.onFocus, true);
      document.removeEventListener("input", this.onFormEdit, true);
      document.removeEventListener("change", this.onFormEdit, true);
    }
  };

  // ../../../../../../tmp/handsfree-downloads-fy1aG9/extension/src/content/index.ts
  var runtimeWindow = window;
  if (!runtimeWindow.__handsfreeContent) {
    const runtime = new ContentRuntime(
      (message) => chrome.runtime.sendMessage(message)
    );
    runtimeWindow.__handsfreeContent = runtime;
    chrome.runtime.onMessage.addListener((message, _sender, respond) => {
      runtime.handle(message).then(respond).catch(
        (error) => respond({
          ok: false,
          error: error instanceof Error ? error.message : "Page action failed."
        })
      );
      return true;
    });
  }
})();
