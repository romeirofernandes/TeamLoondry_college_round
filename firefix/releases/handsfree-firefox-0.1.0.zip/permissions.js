var chrome = globalThis.browser || globalThis.chrome;
"use strict";
(() => {
  // src/capture-check.ts
  async function captureCheck() {
    const port = chrome.runtime.connect({ name: "handsfree-capture-check" });
    let ready = false, disconnected = false;
    let finishRelease = null;
    const finish = () => {
      const callback = finishRelease;
      finishRelease = null;
      callback?.();
    };
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        port.disconnect();
        reject(new Error("Desktop handoff timed out. Capture stayed off."));
      }, 1e4);
      port.onDisconnect.addListener(() => {
        void chrome.runtime.lastError;
        disconnected = true;
        clearTimeout(timer);
        if (!ready) reject(new Error("Capture preparation disconnected."));
        finish();
      });
      port.onMessage.addListener((message) => {
        if (message.released) {
          finish();
          return;
        }
        clearTimeout(timer);
        if (message.ok) {
          ready = true;
          resolve();
        } else {
          port.disconnect();
          reject(new Error(message.error || "Desktop handoff failed. Capture stayed off."));
        }
      });
    });
    let release = null;
    return () => release ??= new Promise((resolve) => {
      if (disconnected) {
        resolve();
        return;
      }
      const timer = setTimeout(() => finish(), 1e4);
      finishRelease = () => {
        clearTimeout(timer);
        port.disconnect();
        resolve();
      };
      try {
        port.postMessage({ release: true });
      } catch {
        finish();
      }
    });
  }

  // src/speech.ts
  function recognizerClass() {
    const global = globalThis;
    const constructor = global.SpeechRecognition ?? global.webkitSpeechRecognition;
    if (!constructor)
      throw new Error(
        /Firefox\//.test(globalThis.navigator?.userAgent || "") ? "Firefox voice commands need a Groq key. Open Voice services from the extension popup. On-device dictation is unavailable in Firefox." : "Speech recognition is unavailable. Use current Google Chrome with microphone access."
      );
    return constructor;
  }
  function speechLanguage(language) {
    const selected = language === "auto" ? globalThis.navigator?.language || "en-US" : language;
    try {
      const canonical = Intl.getCanonicalLocales(selected)[0];
      if (!canonical || !/^[a-z]{2,3}(?:-|$)/i.test(canonical)) throw new Error();
      return canonical;
    } catch {
      throw new Error("Choose a valid speech language, such as en-US or hi-IN.");
    }
  }
  async function installLocalSpeech(language) {
    language = speechLanguage(language);
    const Recognition = recognizerClass();
    if (!Recognition.available || !Recognition.install)
      throw new Error(
        "This Chrome build cannot install local speech. Update Chrome, or choose browser speech after reading its audio notice."
      );
    const state = await Recognition.available({
      langs: [language],
      processLocally: true
    });
    if (state === "available") return;
    if (state === "unavailable")
      throw new Error(
        `No local speech language pack is available for ${language}.`
      );
    if (!await Recognition.install({ langs: [language], processLocally: true }))
      throw new Error(
        "Language pack download failed. Check your connection and retry."
      );
  }

  // src/shared.ts
  async function send(message) {
    const runtime = globalThis.chrome.runtime;
    const result = await runtime.sendMessage(message);
    if (result?.ok === false) throw new Error(result.error || "The action failed. Retry from the popup.");
    return result;
  }

  // src/permissions.ts
  var root = document.querySelector("#permissions");
  var query = new URLSearchParams(location.search);
  var kind = query.get("kind") || "devices";
  var selectedCamera = query.get("camera") !== "false";
  var selectedMicrophone = query.get("microphone") !== "false";
  root.innerHTML = `<section class="permission-setup" aria-labelledby="access-title">
<img src="brand/handsfree-symbol.svg" width="36" height="36" alt="Handsfree">
<p class="permission-eyebrow">A little setup, at your pace</p><h1 id="access-title">Browser access</h1>
<p>Choose the access you need. Your place in setup is saved.</p>
<div class="permission-row" data-kind="pages"><div><label for="pages">Webpage control</label><p>Use Handsfree on websites you visit.</p></div><input type="checkbox" role="switch" id="pages"><span id="pages-state">Checking</span></div>
<div class="permission-row" data-kind="tabs"><div><label for="tabs">Tab commands</label><p>Find and switch tabs by speaking.</p></div><input type="checkbox" role="switch" id="tabs"><span id="tabs-state">Checking</span></div>
<section class="permission-device" data-kind="camera"><h2>Camera</h2><p>Needed for head or hand movement.</p><p id="camera-state">Checking</p><button id="camera">Allow camera</button></section>
<section class="permission-device" data-kind="microphone"><h2>Microphone</h2><p>Needed for voice commands.</p><p id="microphone-state">Checking</p><button id="microphone">Allow microphone</button></section>
<section class="permission-device" data-kind="provider"><h2>Natural language commands</h2><p>Optional access for interpreting commands. Fixed commands work without it.</p><p id="provider-state">Checking</p><button id="providers">Allow command service</button></section>
<section class="permission-device" data-kind="speech"><h2>On-device speech</h2><p>Download your selected language for speech recognition that stays on this device.</p><button id="speech">Install local speech</button></section>
<p class="permission-device-help">Chrome stores device permissions. To revoke access, use Chrome's site settings for this extension.</p>
<p id="status" role="status"></p>
<div class="permission-actions"><button id="read">Read this step aloud</button><button id="quiet">Stop reading</button><button id="return" class="permission-primary">Return to Handsfree</button></div>
</section>`;
  var status = root.querySelector("#status");
  var devices = {};
  var updating = false;
  for (const section of root.querySelectorAll("[data-kind]")) {
    const row = section.dataset.kind;
    section.hidden = kind === "devices" ? !(row === "camera" && selectedCamera || row === "microphone" && selectedMicrophone) : row !== kind;
  }
  function permissionLabel(value) {
    return value === "granted" ? "Allowed" : value === "denied" ? "Blocked. Update access in Chrome, then retry." : value === "prompt" ? "Not requested" : "Permission unknown. Choose Allow to check.";
  }
  async function refresh() {
    const state = await send({ type: "GET_PERMISSIONS" });
    for (const id of ["pages", "tabs"]) {
      root.querySelector(`#${id}`).checked = state[id];
      root.querySelector(`#${id}-state`).textContent = state[id] ? "Allowed" : "Not allowed";
    }
    for (const id of ["camera", "microphone"]) {
      const value = devices[id]?.state ?? "unknown";
      root.querySelector(`#${id}-state`).textContent = permissionLabel(value);
      root.querySelector(`#${id}`).hidden = value === "granted";
    }
    root.querySelector("#provider-state").textContent = state.provider ? "Allowed" : "Not allowed";
    root.querySelector("#providers").hidden = state.provider;
    await send({ type: "MEDIA_PERMISSIONS", camera: devices.camera?.state ?? "unknown", microphone: devices.microphone?.state ?? "unknown" });
  }
  function button(id, action) {
    const element = root.querySelector(`#${id}`);
    element.addEventListener("click", () => {
      element.disabled = true;
      void action().then((text) => {
        status.textContent = text;
      }, (error) => {
        status.textContent = error instanceof Error ? error.message : "Access could not be updated. Retry.";
      }).finally(async () => {
        element.disabled = false;
        await refresh().catch(() => {
        });
      });
    });
  }
  for (const id of ["pages", "tabs"]) {
    const toggle = root.querySelector(`#${id}`);
    toggle.addEventListener("change", () => {
      if (updating) return;
      updating = true;
      toggle.disabled = true;
      const permission = id === "pages" ? { origins: ["http://*/*", "https://*/*"] } : { permissions: ["tabs"] };
      const operation = toggle.checked ? chrome.permissions.request(permission) : chrome.permissions.remove(permission);
      void operation.then((allowed) => {
        status.textContent = allowed ? "Access updated." : "Chrome did not grant access. You can retry.";
      }, () => {
        status.textContent = "Access could not be changed. Retry.";
      }).finally(async () => {
        await refresh().catch(() => {
        });
        updating = false;
        toggle.disabled = false;
      });
    });
  }
  for (const id of ["camera", "microphone"]) button(id, async () => {
    const release = await captureCheck();
    try {
      const stream = await navigator.mediaDevices.getUserMedia(id === "camera" ? { video: true } : { audio: true });
      stream.getTracks().forEach((track) => track.stop());
      return `${id === "camera" ? "Camera" : "Microphone"} allowed. Return to Handsfree when you're ready.`;
    } finally {
      await release();
    }
  });
  button("providers", async () => await chrome.permissions.request({ origins: ["https://api.typesafe.ai/*", "https://openrouter.ai/*"] }) ? "Command service allowed." : "Access was not granted. Fixed commands are still available.");
  button("speech", async () => {
    const settings = await send({ type: "GET_SETTINGS" });
    await installLocalSpeech(settings.language);
    return "Language ready. Return to Handsfree to start listening.";
  });
  button("read", async () => {
    await send({ type: "UI_SPEAK", text: root.querySelector("h1").textContent + ". " + [...root.querySelectorAll("[data-kind]")].filter((row) => !row.hidden).map((row) => row.innerText).join(". ") + ". Choose Return to Handsfree when ready." });
    return "Reading finished.";
  });
  button("quiet", async () => {
    await send({ type: "UI_SPEAK", text: "" });
    return "Reading stopped.";
  });
  button("return", async () => {
    await send({ type: "UI_SPEAK", text: "" });
    await send({ type: "OPEN_DASHBOARD", hash: query.get("return") === "#setup" ? "#setup" : query.get("return") === "#access" ? "#access" : "#preferences" });
    window.close();
    return "Returning to Handsfree.";
  });
  void Promise.all(["camera", "microphone"].map(async (name) => {
    try {
      const permission = await navigator.permissions.query({ name });
      devices[name] = permission;
      permission.addEventListener("change", () => void refresh().catch(() => {
      }));
    } catch {
    }
  })).then(refresh).catch(() => {
    status.textContent = "Could not read Chrome permissions. Reload the extension and retry.";
  });
  chrome.permissions.onAdded.addListener(() => void refresh().catch(() => {
  }));
  chrome.permissions.onRemoved.addListener(() => void refresh().catch(() => {
  }));
  addEventListener("focus", () => void refresh().catch(() => {
  }));
})();
