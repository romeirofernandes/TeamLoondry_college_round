var chrome = globalThis.browser || globalThis.chrome;
"use strict";
(() => {
  // src/dashboard-redirect.ts
  void chrome.runtime.sendMessage({ type: "OPEN_DASHBOARD", hash: location.hash || "#overview" }).then(() => window.close());
})();
